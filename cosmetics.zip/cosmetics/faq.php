<?php include "include/header.php" ?>
<?php include "include/nav.php" ?>


            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="row margin-vert-30">
                        <div class="col-md-12">
                            <h2>F.A.Q.</h2>
                            <p>Cosmetic Regulation.</p>
                            <hr class="margin-vert-40">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="tab-content">
                                        <div class="tab-pane active in fade" id="faq">
                                            <div class="panel-group" id="accordion">
                                                <!-- FAQ Item -->
                                                <div class="panel panel-default panel-faq">
                                                    <div class="panel-heading">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#faq-sub">
                                                            <h4 class="panel-title">
                                                                Are Cosmetics & skin care regulated more strictly in Europe than in the U.S.?
                                                                <span class="pull-right">
                                                                    <i class="glyphicon glyphicon-plus"></i>
                                                                </span>
                                                            </h4>
                                                        </a>
                                                    </div>
                                                    <div id="faq-sub" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                            The United States (US) and European Union (EU) share a common goal of ensuring the safety of Cosmetics & skin care for consumers through rigorous science-based regulation. 

MYTH:  Cosmetics & skin care and personal care products are more strictly regulated in the EU and consumer are better protected.

FACTS:  While there may be minor differences, the manner by which the U.S. and the EU regulate the safety of Cosmetics & skin care and personal care products are very similar.  In the United States, the Cosmetics & skin care industry is regulated by the U.S. Food and Drug Administration (FDA), which has broad regulatory authority under the Food, Drug and Cosmetic Act.  In the EU, each Member State has health authorities which regulate Cosmetics & skin care within their respective national boundaries according to the European Union's Cosmetics & skin care Directive regulation. 
.  
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End FAQ Item -->
                                                <!-- Faq Item -->
                                                <div class="panel panel-default panel-faq">
                                                    <div class="panel-heading">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#faq-sub-2">
                                                            <h4 class="panel-title">
                                                               How are Cosmetics & skin care regulated in Europe?
                                                                <span class="pull-right">
                                                                    <i class="glyphicon glyphicon-plus"></i>
                                                                </span>
                                                            </h4>
                                                        </a>
                                                    </div>
                                                    <div id="faq-sub-2" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                           The European Union's Cosmetics & skin care Directive regulation requires that Cosmetics & skin care products placed on the EU market be safe; that is, they "must not cause damage to human health when applied under normal or reasonably foreseeable conditions of use." As in the U.S., manufacturers are responsible for ensuring that Cosmetics & skin care products comply with the law and are safe for their intended uses before they are marketed. Regulations are enforced at the EU member country level, and each country has an authoritative body that is responsible for ensuring compliance. 
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End FAQ Item -->
                                                <!-- Faq Item -->
                                                <div class="panel panel-default panel-faq">
                                                    <div class="panel-heading">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#faq-sub-3">
                                                            <h4 class="panel-title">
                                                               Does the FDA have the authority to regulate cosmetic safety?
                                                                <span class="pull-right">
                                                                    <i class="glyphicon glyphicon-plus"></i>
                                                                </span>
                                                            </h4>
                                                        </a>
                                                    </div>
                                                    <div id="faq-sub-3" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                           Strong federal safety requirements govern Cosmetics & skin care and personal care products sold in the U.S. It is a crime to market an unsafe Cosmetics & skin care product. The U.S. Food and Drug Administration (FDA) and the U. S. Attorney General can take action against any company that markets an unsafe Cosmetics & skin care product. The law provides severe penalties, including seizures, recalls, fines and bans, for Cosmetics & skin care and personal care products manufacturers that do not meet these strict safety standards.

The FDA has wide-ranging regulatory authority that helps to ensure the safety of Cosmetics & skin care and personal care products. Throughout the years, FDA has infrequently had to exercise this power to limit or prohibit ingredients that it considered to be unsafe. Cosmetics & skin care and personal care products companies are committed to upholding strict FDA regulations.
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End FAQ Item -->
                                                <!-- Faq Item -->
                                                <div class="panel panel-default panel-faq">
                                                    <div class="panel-heading">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#faq-sub-4">
                                                            <h4 class="panel-title">
                                                               Do independent experts research and evaluate cosmetic safety?
                                                                <span class="pull-right">
                                                                    <i class="glyphicon glyphicon-plus"></i>
                                                                </span>
                                                            </h4>
                                                        </a>
                                                    </div>
                                                    <div id="faq-sub-4" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                           The Cosmetic Ingredient Review (CIR) Expert Panel is an independent, non-profit scientific body that was launched in 1976 with support of the U.S. Food & Drug Administration (FDA) and the Consumer Federation of America (CFA) to assess the safety of ingredients used in Cosmetics & skin care in the U.S. The CIR Expert Panel consists of world-renowned scientists and physicians who have been publicly nominated by consumer, scientific and medical groups, government agencies, and industry. Members of the Panel must meet (and actually exceed) the conflict of interest requirements regarding financial interests as special non-government advisory experts to FDA.

The CIR thoroughly reviews and assesses the safety of ingredients used in Cosmetics & skin care in an open, unbiased, and expert manner and publishes the results of its work in peer-reviewed scientific literature. FDA, CFA and the Personal Care Products Council provide non-voting liaisons to the Panel and are actively involved in the comment and discussion process.
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- End FAQ Item -->
                                                <!-- Faq Item -->
                                          
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <h3 class="margin-bottom-10">Could not find the answer?</h3>
                                  
                                  <a  href="contact.php"><button type="button" class="btn btn-primary btn-sm">ASK A QUESTION</button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->

           <?php include "include/footer.php" ?>
