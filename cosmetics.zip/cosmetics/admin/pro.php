<?php include "includes/admin_header.php" ?>
<?php

   if(isset($_SESSION['username'])) {
    
    $username = $_SESSION['username'];
    
    $query = "SELECT * FROM users WHERE username = '{$username}' ";
    
    $select_user_profile_query = mysqli_query($connection, $query);
    
    while($row = mysqli_fetch_array($select_user_profile_query)) {
    
        $user_id = $row['user_id'];
        $username = $row['username'];
        $user_password= $row['user_password'];
        $user_firstname = $row['user_firstname'];
        $user_account_balance= $row['user_account_balance'];
        $user_lastname = $row['user_lastname'];
        $user_dob = $row['user_dob'];
        $user_zipcode = $row['user_zipcode'];
        $user_address = $row['user_address'];
        $user_country = $row['user_country'];
        $user_state = $row['user_state'];
        $user_email = $row['user_email'];
        $user_image = $row['user_image'];
        $user_role= $row['user_role'];
    
    
    
    }
    

}
  
    ?>
    
    

    
    
    

    <div id="wrapper">
        
  

        <!-- Navigation -->
 
        <?php include "includes/admin_navigation.php" ?>
        
        
    
 
        
 <div class="container">
	<div class="row">
		
        
        
       <div class="col-lg-11 ">

<div class="panel panel-default">
  <div class="panel-heading">  <h4 >User Profile</h4></div>
   <div class="panel-body">
       
    <div class="box box-info">
        
            <div class="box-body">
                     <div class="col-sm-6">
                     <div  align="center"> <img alt="User Pic" src="../images/<?php echo $user_image; ?>" width="150px" height="80px" id="profile-image1" class="img-rounded img-responsive"> 
               
                     </div>
              
              <br>
    
              <!-- /input-group -->
            </div>
             
  <h4> ACCOUNT NUMBER :
     <?php 
    global $connection; 
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);
    $select_all= mysqli_fetch_array($result);
    $user_id = $select_all['user_id'];
    echo $select_all['user_account_number'];
 
 ?>
 </h4>
                <hr>
                
                 <h4> ACCOUNT STATUS : DORMANT </h4>        
                
                <hr>
                
                <?php
     
         
    $select_users = mysqli_query($connection,$query);  
    while($row = mysqli_fetch_assoc($select_users)) {
        $user_id             = $row['user_id'];
        $username            = $row['username'];
        $user_password       = $row['user_password'];
        $user_firstname      = $row['user_firstname'];
        $user_lastname       = $row['user_lastname'];
        $user_email          = $row['user_email'];
        $user_image          = $row['user_image'];
        
    }
                
                
    if(is_admin($_SESSION['username'])){
        
       echo "<div class='col-sm-6'>";
       
       echo "<a href='users.php?source=edit_user&edit_user={$user_id}'><div class='form-group'><input class='btn btn-primary' type='submit' value='EDIT PROFILE'></a>";
        echo "</div>";
    }
                else{
         echo "<div class='col-sm-6'>";
       
       echo "<a href='profile.php'><div class='form-group'><input class='btn btn-primary' type='submit' value='EDIT PROFILE'></a>";
        echo "</div>";
    }
                
                ?>
                
                <hr>

               
          <div class="form-group">
         <a href="transfers.php"> <input class="btn btn-success" type="submit" value="TRANSFER"></a>
      </div>
                
                
            <hr>
                  <div class="form-group">
                <a href="../logout.php"><input class="btn btn-danger" type="submit"  value="Logout"></a>
                   </div>      
            </div>
        
        
            <div class="clearfix"></div>
            <hr style="margin:10px 0 10px 0;">
    
              
<div class="col-sm-5 col-xs-6 tital " >First Name:</div><div class="col-sm-7 col-xs-6 "><?php echo $user_firstname; ?></div>
     <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Last Name:</div><div class="col-sm-7"> <?php echo $user_lastname; ?></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Username:</div><div class="col-sm-7"> <?php echo $username; ?></div>
  <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Email:</div><div class="col-sm-7"><?php echo $user_email; ?></div>

  <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Date Of Birth:</div><div class="col-sm-7">11 Jun 1998</div>

  <div class="clearfix"></div>
<div class="bot-border"></div>

  <hr>      
        
<div class="col-sm-5 col-xs-6 tital " >Account balance:</div><div class="col-sm-7"> 
   <?php echo $user_account_balance; ?>
</div>

 <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Address:</div><div class="col-sm-7"><?php echo $user_address; ?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Zip code:</div><div class="col-sm-7"><?php echo $user_zipcode; ?></div>

 <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >Country:</div><div class="col-sm-7"><?php echo $user_country; ?></div>

        
         <div class="clearfix"></div>
<div class="bot-border"></div>
<hr>
<div class="col-sm-5 col-xs-6 tital " >state:</div><div class="col-sm-7"><?php echo $user_state; ?></div>

        

 <div class="clearfix"></div>
<div class="bot-border"></div>

            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>       
        
        
        
        
        

     
        <!-- /#page-wrapper -->
        
    <?php include "includes/admin_footer.php" ?>
