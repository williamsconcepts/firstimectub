<?php

function redirect($location){


    header("Location:" . $location);
    exit;

}


function ifItIsMethod($method=null){

    if($_SERVER['REQUEST_METHOD'] == strtoupper($method)){

        return true;

    }

    return false;

}

function isLoggedIn(){

    if(isset($_SESSION['user_role'])){

        return true;


    }


   return false;

}

function checkIfUserIsLoggedInAndRedirect($redirectLocation=null){

    if(isLoggedIn()){

        redirect($redirectLocation);

    }

}





function escape($string) {

global $connection;

return mysqli_real_escape_string($connection, trim($string));


}



function set_message($msg){

if(!$msg) {

$_SESSION['message']= $msg;

} else {

$msg = "";


    }


}


function display_message() {

    if(isset($_SESSION['message'])) {
        echo $_SESSION['message'];
        unset($_SESSION['message']);
    }


}




function users_online() {



    if(isset($_GET['onlineusers'])) {

    global $connection;

    if(!$connection) {

        session_start();

        include("../include/db.php");

        $session = session_id();
        $time = time();
        $time_out_in_seconds = 05;
        $time_out = $time - $time_out_in_seconds;

        $query = "SELECT * FROM users_online WHERE session = '$session'";
        $send_query = mysqli_query($connection, $query);
        $count = mysqli_num_rows($send_query);

            if($count == NULL) {

            mysqli_query($connection, "INSERT INTO users_online(session, time) VALUES('$session','$time')");


            } else {

            mysqli_query($connection, "UPDATE users_online SET time = '$time' WHERE session = '$session'");


            }

        $users_online_query =  mysqli_query($connection, "SELECT * FROM users_online WHERE time > '$time_out'");
        echo $count_user = mysqli_num_rows($users_online_query);


    }






    } // get request isset()


}

users_online();




function confirmQuery($result) {
    
    global $connection;

    if(!$result ) {
          
          die("QUERY FAILED ." . mysqli_error($connection));
   
          
      }

}



function insert_categories(){
    
    global $connection;

        if(isset($_POST['submit'])){

            $cat_title = $_POST['cat_title'];

        if($cat_title == "" || empty($cat_title)) {
        
             echo "This Field should not be empty";
    
    } else {





    $stmt = mysqli_prepare($connection, "INSERT INTO categories(cat_title) VALUES(?) ");

    mysqli_stmt_bind_param($stmt, 's', $cat_title);

    mysqli_stmt_execute($stmt);


        if(!$stmt) {
        die('QUERY FAILED'. mysqli_error($connection));
        
                  }


        
             }

             
    mysqli_stmt_close($stmt);
   
        
       }

}


function findAllCategories() {
global $connection;

    $query = "SELECT * FROM categories";
    $select_categories = mysqli_query($connection,$query);  

    while($row = mysqli_fetch_assoc($select_categories)) {
    $cat_id = $row['cat_id'];
    $cat_title = $row['cat_title'];

    echo "<tr>";
        
    echo "<td>{$cat_id}</td>";
    echo "<td>{$cat_title}</td>";
   echo "<td><a href='categories.php?delete={$cat_id}'>Delete</a></td>";
   echo "<td><a href='categories.php?edit={$cat_id}'>Edit</a></td>";
    echo "</tr>";

    }


}


function deleteCategories(){
global $connection;

    if(isset($_GET['delete'])){
    $the_cat_id = $_GET['delete'];
    $query = "DELETE FROM categories WHERE cat_id = {$the_cat_id} ";
    $delete_query = mysqli_query($connection,$query);
    header("Location: categories.php");


    }
            


}


function UnApprove() {
global $connection;
if(isset($_GET['unapprove'])){
    
    $the_comment_id = $_GET['unapprove'];
    
    $query = "UPDATE comments SET comment_status = 'unapproved' WHERE comment_id = $the_comment_id ";
    $unapprove_comment_query = mysqli_query($connection, $query);
    header("Location: comments.php");
    
    
    }

    
    

}


function is_admin($username) {

    global $connection; 

    $query = "SELECT user_role FROM users WHERE username = '$username'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    $row = mysqli_fetch_array($result);

    if($row['user_role'] == 'administrator'){

        return true;

    }else if($row['user_role'] == 'administrator'){

        return true;

    }else {


        return false;
    }

}



function username_exists($username){

    global $connection;

    $query = "SELECT username FROM users WHERE username = '$username'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    if(mysqli_num_rows($result) > 0) {

        return true;

    } else {

        return false;

    }
}

function account_number_exists($account_number){

    global $connection;

    $query = "SELECT user_account_number FROM users WHERE user_account_number = '$account_number'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    if(mysqli_num_rows($result) > 0) {

        return true;

    } else {

        return false;

    }





}



function email_exists($email){

    global $connection;


    $query = "SELECT user_email FROM users WHERE user_email = '$email'";
    $result = mysqli_query($connection, $query);
    confirmQuery($result);

    if(mysqli_num_rows($result) > 0) {

        return true;

    } else {

        return false;

    }



}
 function request_loan($user_id,$account_number,$receiver_name,$amount,$loan_text,$username){
     global $connection;
        
        $account_number = mysqli_real_escape_string($connection, $account_number);
        $receiver_name = mysqli_real_escape_string($connection, $receiver_name);
        $amount = mysqli_real_escape_string($connection, $amount);
        $loan_text = mysqli_real_escape_string($connection, $loan_text);
        $username = mysqli_real_escape_string($connection, $username);
        
            
        $query = "INSERT INTO loan (user_id,account_number,receiver_name,amount,loan_text,username) ";
        $query .= "VALUES('{$user_id}','{$account_number}','{$receiver_name}','{$amount}','{$loan_text}','{$username}')";
        $process_loan = mysqli_query($connection, $query);

        confirmQuery($process_loan);
 }

function transfer_amount($user_id,$account_number,$receiver_name,$bank_name,$swift_code,$route_number,$amount,$sender_email,$status,$username){

    global $connection;
        $user_id = mysqli_real_escape_string($connection, $user_id);
        $account_number = mysqli_real_escape_string($connection, $account_number);
        $receiver_name = mysqli_real_escape_string($connection, $receiver_name);
        $bank_name = mysqli_real_escape_string($connection, $bank_name);
        $swift_code = mysqli_real_escape_string($connection, $swift_code);
        $route_number = mysqli_real_escape_string($connection, $route_number);
        $amount = mysqli_real_escape_string($connection, $amount);
        $sender_email = mysqli_real_escape_string($connection, $sender_email);
        $status = mysqli_real_escape_string($connection, $status);

        $username = mysqli_real_escape_string($connection, $username);
        
            
        $query = "INSERT INTO transaction (user_id,account_number,receiver_name,bank_name,swift_code,route_number,token,amount,sender_email,user_status,username) ";
        $query .= "VALUES('{$user_id}','{$account_number}','{$receiver_name}','{$bank_name}','{$swift_code}','{$route_number}','','{$amount}','{$sender_email}','{$status}','{$username}')";
        $transfer_query = mysqli_query($connection, $query);

        confirmQuery($transfer_query);

}



function register_user($firstname,$lastname,$username,$account_number,$zip,$dob,$country,$state,$address,$email, $password){

    global $connection;
        $firstname = mysqli_real_escape_string($connection, $firstname);
        $lastname = mysqli_real_escape_string($connection, $lastname);
        $username = mysqli_real_escape_string($connection, $username);
      
        $email    = mysqli_real_escape_string($connection, $email);
        $password = mysqli_real_escape_string($connection, $password);

        $password = password_hash( $password, PASSWORD_BCRYPT, array('cost' => 12));
            
            
        $query = "INSERT INTO users (username,user_firstname,user_lastname,user_email, user_password, user_role, user_activation_code, user_email_status) ";
        $query .= "VALUES('{$username}','{$firstname}','{$lastname}','{$email}', '{$password}', '{$user_activation_code}', 'not verified', 'subscriber' )";
        $register_user_query = mysqli_query($connection, $query);

        confirmQuery($register_user_query);

        
    
    
//    
//		if(isset($result))
//		{
//			$base_url = "http://localhost/tutorial/email-address-verification-script-using-php/";  //change this baseurl value as per your file path
//			$mail_body = "
//			<p>Hi ".$_POST['user_name'].",</p>
//			<p>Thanks for Registration. Your password is ".$user_password.", This password will work only after your email verification.</p>
//			<p>Please Open this link to verified your email address - ".$base_url."email_verification.php?activation_code=".$user_activation_code."
//			<p>Best Regards,<br />Webslesson</p>
//			";
//			require 'class/class.phpmailer.php';
//			$mail = new PHPMailer;
//			$mail->IsSMTP();								//Sets Mailer to send message using SMTP
//			$mail->Host = 'smtpout.secureserver.net';		//Sets the SMTP hosts of your Email hosting, this for Godaddy
//			$mail->Port = '80';								//Sets the default SMTP server port
//			$mail->SMTPAuth = true;							//Sets SMTP authentication. Utilizes the Username and Password variables
//			$mail->Username = 'xxxxxxxx';					//Sets SMTP username
//			$mail->Password = 'xxxxxxxx';					//Sets SMTP password
//			$mail->SMTPSecure = '';							//Sets connection prefix. Options are "", "ssl" or "tls"
//			$mail->From = 'info@webslesson.info';			//Sets the From email address for the message
//			$mail->FromName = 'Webslesson';					//Sets the From name of the message
//			$mail->AddAddress($_POST['user_email'], $_POST['user_name']);		//Adds a "To" address			
//			$mail->WordWrap = 50;							//Sets word wrapping on the body of the message to a given number of characters
//			$mail->IsHTML(true);							//Sets message type to HTML				
//			$mail->Subject = 'Email Verification';			//Sets the Subject of the message
//			$mail->Body = $mail_body;							//An HTML or plain text message body
//			if($mail->Send())								//Send an Email. Return true on success or false on error
//			{
//				$message = '<label class="text-success">Register Done, Please check your mail.</label>';
//			}
//		}
//
//    
//    
    


}

 function login_user($username, $password)
 {

     global $connection;

     $username = trim($username);
     $password = trim($password);

     $username = mysqli_real_escape_string($connection, $username);
     $password = mysqli_real_escape_string($connection, $password);


     $query = "SELECT * FROM users WHERE username = '{$username}' ";
     $select_user_query = mysqli_query($connection, $query);
     if (!$select_user_query) {

         die("QUERY FAILED" . mysqli_error($connection));

     }


     while ($row = mysqli_fetch_array($select_user_query)) {

         $db_user_id = $row['user_id'];
         $db_username = $row['username'];
         $db_user_password = $row['user_password'];
         $db_user_firstname = $row['user_firstname'];
         $db_user_lastname = $row['user_lastname'];
         $db_user_role = $row['user_role'];


         if (password_verify($password,$db_user_password)) {

             $_SESSION['username'] = $db_username;
             $_SESSION['firstname'] = $db_user_firstname;
             $_SESSION['lastname'] = $db_user_lastname;
             $_SESSION['user_role'] = $db_user_role;



             redirect("/admin");


         } else {


             return false;



         }



     }

     return true;

 }







