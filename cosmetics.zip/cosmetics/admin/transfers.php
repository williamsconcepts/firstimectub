<?php include "includes/admin_header.php" ?>
<?php

   if(isset($_SESSION['username'])) {
    
    $username = $_SESSION['username'];
    
    $query = "SELECT * FROM users WHERE username = '{$username}' ";
    
    $select_user_profile_query = mysqli_query($connection, $query);
    
    while($row = mysqli_fetch_array($select_user_profile_query)) {
    
        $user_id = $row['user_id'];
       
    }
}
    ?>
    
<?php 

if($_SERVER['REQUEST_METHOD'] == "POST") {

    $account_number = trim($_POST['account_number']);
    $receiver_name = trim($_POST['receiver_name']);   
    $bank_name = trim($_POST['bank_name']);
    $swift_code = trim($_POST['swift_code']);
    $route_number = trim($_POST['route_number']); 
    $amount = trim($_POST['amount']);
    $sender_email = trim($_POST['sender_email']);
    //$token = trim($_POST['token']);   
    $status = '';    
 


    $error = [
        'account_number'=>'',
        'receiver_name'=>'',
        'bank_name'=> '',
        'swift_code'=>'',
        'route_number'=>'',
        'amount'=>'',
        'sender_email'=> ''

    ];


    if($account_number ==''){

            $error['account_number'] = 'Account Number cannot be empty';


        }
    if($receiver_name ==''){

        $error['receiver_name'] = 'Receiver Name cannot be empty';


    }

    if($amount ==''){

        $error['amount'] = 'Amount cannot be empty';


    }

    if($amount < 50){

        $error['amount'] = 'Amount should be more than $50';


    }

     if($bank_name ==''){

        $error['bank_name'] = 'Bank Name cannot be empty';


    }

    if($swift_code ==''){

        $error['swift_code'] = 'Swift Code cannot be empty';


    }


    if($route_number == '') {


        $error['route_number'] = 'Route Number cannot be empty';

    }

    if($sender_email ==''){

        $error['sender_email'] = 'Sender Email cannot be empty';


    }



    foreach ($error as $key => $value) {
        
        if(empty($value)){

            unset($error[$key]);

        }



    } // foreach

    if(empty($error)){

        transfer_amount($user_id,$account_number,$receiver_name,$bank_name,$swift_code,$route_number,$amount,$sender_email,$status,$username);

        redirect("/ronald/admin");


    }

    

} 


?>
 

    <div id="wrapper">
        
  

        <!-- Navigation -->
 
        <?php include "includes/admin_navigation.php" ?>
        
        
    

<div id="page-wrapper">

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">
                      <h1 class="page-header">
                            Welcome 
                            
                            
                            <small> <?php 

                            if(isset($_SESSION['firstname'])) {

                            echo $_SESSION['firstname'];




                            }


                            // if(is_admin($_SESSION['username'])){

                            //     echo " -- is admin too";

                            // } else {

                            //     echo " ---is not";

                            // }





                            ?></small>
                        </h1>
            
             <form  role="form" action="transfers.php" method="post" enctype="multipart/form-data">    
     
     
     
      <div class="form-group">
         <label for="account">Account Number</label>
          <input id="account" type="text" class="form-control" name="account_number" autocomplete="on" value="<?php echo isset($account_number) ? $account_number : '' ?>" >
         <p><?php echo isset($error['account_number']) ? $error['account_number'] : '' ?></p>
      </div>
      
    
       <div class="form-group">
         <label for="receiver">Receiver's Name</label>
          <input id="receiver" type="text"  class="form-control" name="receiver_name" autocomplete="on" value="<?php echo isset($receiver_name) ? $receiver_name : '' ?>">
         <p><?php echo isset($error['receiver_name']) ? $error['receiver_name'] : '' ?></p>
      </div>
     


      <div class="form-group">
         <label for="bank">Bank Name</label>
          <input type="text" id="bank" class="form-control" name="bank_name" autocomplete="on" value="<?php echo isset($bank_name) ? $bank_name : '' ?>">
     <p><?php echo isset($error['bank_name']) ? $error['bank_name'] : '' ?></p>
      </div>
      
      <div class="form-group">
         <label for="swift">Swift Code</label>
          <input id="swift" type="text" class="form-control" name="swift_code" autocomplete="on" value="<?php echo isset($swift_code) ? $swift_code : '' ?>">
       <p><?php echo isset($error['swift_code']) ? $error['swift_code'] : '' ?></p>
      </div>
      
      <div class="form-group">
         <label for="route">Routing Number</label>
          <input id="route" type="text" class="form-control" name="route_number" autocomplete="on" value="<?php echo isset($route_number) ? $route_number : '' ?>">
      <p><?php echo isset($error['route_number']) ? $error['route_number'] : '' ?></p>
      </div>

      <div class="form-group">
         <label for="amount">Amount</label>
          <input id="amount" type="text"  class="form-control" name="amount" autocomplete="on" value="<?php echo isset($amount) ? $amount : '' ?>">
       <p><?php echo isset($error['amount']) ? $error['amount'] : '' ?></p>
      </div>

      <!-- <div class="form-group">
         <label for="token">Token</label>
          <input id="tiken" type="amount"  class="form-control" name="token">
      </div> -->

      <div class="form-group">
         <label for="email">Sender Email</label>
          <input id="email" type="email"  class="form-control" name="sender_email" autocomplete="on" value="<?php echo isset($sender_email) ? $sender_email : '' ?>">
      <p><?php echo isset($error['sender_email']) ? $error['sender_email'] : '' ?></p>
      </div>

      
      
      
      

       <div class="form-group">
          <input class="btn btn-primary" type="submit" name="transfer" value="Proceed">
      </div>


</form>
    
            
            
            
      
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>

     
        <!-- /#page-wrapper -->
        
    <?php include "includes/admin_footer.php" ?>
