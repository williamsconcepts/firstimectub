<?php include "includes/admin_header.php" ?>
        
        <?php 

            if(!is_admin($_SESSION['username'])){

                header("Location: index.php");
            }


         ?>







    <div id="wrapper">



        <!-- Navigation -->
 
        <?php include "includes/admin_navigation.php" ?>
        
        
    

<div id="page-wrapper">

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">

  <h1 class="page-header">
                Welcome
                 <small> <?php 

                            if(isset($_SESSION['firstname'])) {

                            echo $_SESSION['firstname'];




                            }


                            // if(is_admin($_SESSION['username'])){

                            //     echo " -- is admin too";

                            // } else {

                            //     echo " ---is not";

                            // }





                            ?></small>
            </h1>
            
                      
          
           <div class="table-responsive">
           <table class="table table-bordered table-hover ">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Username</th>
                        <th>Receiver Name</th>
                        <th>Amount</th>
                        <th>Loan Text</th>
                   
        
                    </tr>
                </thead>
                
                      <tbody>
                      

  <?php 
    
    $query = "SELECT * FROM loan";
    $select_transactions = mysqli_query($connection,$query);  
    while($row = mysqli_fetch_assoc($select_transactions)) {
        $id                  = $row['id'];
        $username            = $row['username'];
        $receiver_name       = $row['receiver_name'];
        $amount              = $row['amount'];
        $loan_text           = $row['loan_text'];
    
        
        echo "<tr>";
        
        echo "<td>$id </td>";
        echo "<td>$username</td>";
        echo "<td>$receiver_name</td>";
        echo "<td>$amount</td>";
        echo "<td>$loan_text</td>";
            
        

         echo "<td><a href='loan_request.php?approve_loan={$id}'>Approve Loan</a></td>";
     
        // echo "<td><a href='users.php?change_to_admin={$user_id}'>Admin</a></td>";
        // echo "<td><a href='users.php?change_to_sub={$user_id}'>Subscriber</a></td>";
       // echo "<td><a href='users.php?source=edit_user&edit_user={$user_id}'>Edit</a></td>";
        //echo "<td><a href='users.php?delete={$user_id}'>Delete</a></td>";
        echo "</tr>";
   
    }




      ?>


   
            </tbody>
            </table>
            </div>
            
            
<?php

if(isset($_GET['approve_loan'])) {
    
    $the_user_id = escape($_GET['approve_loan']);
    
    $query = "UPDATE loan SET loan_status = 'Approved' WHERE id = $the_user_id   ";
    $approve_transaction = mysqli_query($connection, $query);
    header("Location: index.php");
    
    
}

if(isset($_GET['delete'])){

    if(isset($_SESSION['user_role'])) {

        if($_SESSION['user_role'] == 'admin') {

        $the_user_id = escape($_GET['delete']);

        $query = "DELETE FROM users WHERE user_id = {$the_user_id} ";
        $delete_user_query = mysqli_query($connection, $query);
        header("Location: users.php");

            }   


        }
   
    
    }





?>               
            
            
            
            
            
                

            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>

     
        <!-- /#page-wrapper -->
        
    <?php include "includes/admin_footer.php" ?>
