<?php include "includes/admin_header.php" ?>
<?php

   if(isset($_SESSION['username'])) {
    
    $username = $_SESSION['username'];
    
    $query = "SELECT * FROM users WHERE username = '{$username}' ";
    
    $select_user_profile_query = mysqli_query($connection, $query);
    
    while($row = mysqli_fetch_array($select_user_profile_query)) {
    
        $user_id = $row['user_id'];
       
    }
}
    ?>
    
<?php 

if($_SERVER['REQUEST_METHOD'] == "POST") {
    $user_id; $username;
    $account_number = trim($_POST['account_number']);
    $receiver_name = trim($_POST['receiver_name']);   
    $amount = trim($_POST['amount']);
    $loan_text = trim($_POST['loan_text']);
    
 


    $error = [
        'account_number'=>'',
        'receiver_name'=>'',
        'amount'=>'',
        'loan_text'=> ''

    ];


    if($account_number ==''){

            $error['account_number'] = 'Account Number cannot be empty';


        }
    if($receiver_name ==''){

        $error['receiver_name'] = 'Receiver Name cannot be empty';


    }

    if($amount ==''){

        $error['amount'] = 'Amount cannot be empty';


    }

    if($amount < 50){

        $error['amount'] = 'Amount should be less than $50';


    }

    

    if($loan_text ==''){

        $error['loan_text'] = 'This field cannot be empty';


    }



    foreach ($error as $key => $value) {
        
        if(empty($value)){

            unset($error[$key]);

        }



    } // foreach

    if(empty($error)){

        request_loan( $user_id,$account_number,$receiver_name,$amount,$loan_text,$username);

        redirect("/admin");


    }

    

} 


?>
 

    <div id="wrapper">
        
  

        <!-- Navigation -->
 
        <?php include "includes/admin_navigation.php" ?>
        
        
    

<div id="page-wrapper">

<div class="container-fluid">

    <!-- Page Heading -->
    <div class="row">
        <div class="col-lg-12">
                      <h1 class="page-header">
                            Welcome 
                            
                            
                            <small> <?php 

                            if(isset($_SESSION['firstname'])) {

                            echo $_SESSION['firstname'];




                            }


                            // if(is_admin($_SESSION['username'])){

                            //     echo " -- is admin too";

                            // } else {

                            //     echo " ---is not";

                            // }





                            ?></small>
                        </h1>
            
             <form  role="form" action="loan.php" method="post" enctype="multipart/form-data">    
     
     
     
      <div class="form-group">
         <label for="account">Account Number</label>
          <input id="account" type="text" class="form-control" name="account_number" autocomplete="on" value="<?php echo isset($account_number) ? $account_number : '' ?>" >
         <p><?php echo isset($error['account_number']) ? $error['account_number'] : '' ?></p>
      </div>
      
    
       <div class="form-group">
         <label for="receiver">Receiver's Name</label>
          <input id="receiver" type="text"  class="form-control" name="receiver_name" autocomplete="on" value="<?php echo isset($receiver_name) ? $receiver_name : '' ?>">
         <p><?php echo isset($error['receiver_name']) ? $error['receiver_name'] : '' ?></p>
      </div>
     

      <div class="form-group">
         <label for="amount">Amount</label>
          <input id="amount" type="text"  class="form-control" name="amount" autocomplete="on" value="<?php echo isset($amount) ? $amount : '' ?>">
       <p><?php echo isset($error['amount']) ? $error['amount'] : '' ?></p>
      </div>

     <p><?php echo isset($error['loan_text']) ? $error['loan_text'] : '' ?></p>
      <textarea class="form-control" rows="3" name="loan_text" value="<?php echo isset($loan_text) ? $loan_text : '' ?>"> Why do you need a loan ?</textarea>

      
      
      
      <br>
      <br>

       <div class="form-group">
          <input class="btn btn-primary" type="submit" name="loan" value="Proceed">
      </div>


</form>
    
            
            
            
      
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>

     
        <!-- /#page-wrapper -->
        
    <?php include "includes/admin_footer.php" ?>
