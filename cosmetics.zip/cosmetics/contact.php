<?php include "include/header.php" ?>
<?php include "include/nav.php" ?>


            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="row margin-vert-30">
                        <!-- Main Column -->
                        <div class="col-md-9">
                            <!-- Main Content -->
                            <div class="headline">
                                <h2>Contact Form</h2>
                            </div>
                           
                            <br>
                            <!-- Contact Form -->
<!--
                            <form>
                                <label>Name</label>
                                <div class="row margin-bottom-20">
                                    <div class="col-md-6 col-md-offset-0">
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <label>Email
                                    <span class="color-red">*</span>
                                </label>
                                <div class="row margin-bottom-20">
                                    <div class="col-md-6 col-md-offset-0">
                                        <input class="form-control" type="text">
                                    </div>
                                </div>
                                <label>Message</label>
                                <div class="row margin-bottom-20">
                                    <div class="col-md-8 col-md-offset-0">
                                        <textarea rows="8" class="form-control"></textarea>
                                    </div>
                                </div>
                                <p>
                                    <button type="submit" class="btn btn-primary">Send Message</button>
                                </p>
                            </form>
-->
                            <!-- End Contact Form -->
                            <!-- End Main Content -->
                        </div>
                        <!-- End Main Column -->
                        <!-- Side Column -->
                        <div class="col-m-8">
                            <!-- Recent Posts -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h3 class="panel-title">Contact Info</h3>
                                </div>
                                <br>
                                <div class="panel-body">
                                    
                                    <ul class="list-unstyled">
                                        
                                        <li>
                                            <i class="fa-phone color-primary">
                                                PHONE<br></i>+44 1163263869</li>
                                        
                                    
                                        <li>
                                            
                                            <hr>
                                            
                                            <li>
                                            <i class="fa-home color-primary">UK HEAD OFFICE ADDRESS<br></i>20 Charles St, Leicester, LE1 3FG</li>
                                     
                                            
                                            
                                            <hr>
                                        <li>
                                            <i class="fa-envelope color-primary"></i><a href="mailto:info@redolencecare.com">info@redolencecare.com</a></li>
                                        
                                        
                                          <li>
                                            <i class="fa-envelope color-primary"></i><a href="mailto:info@redolencecare.com">support@redolencecare.com</a></li>
                                        <li>
                                            <i class="fa-home color-primary"></i>www.redolencecare.com</li>
                                    </ul>
                                    <ul class="list-unstyled">
                                        <li>
                                            <strong class="color-primary">Monday-Friday:</strong>9am to 6pm</li>
                                        <li>
                                            <strong class="color-primary">Saturday:</strong>10am to 3pm</li>
                                        <li>
                                            <strong class="color-primary">Sunday:</strong>Closed</li>
                                    </ul>
                                </div>
                            </div>
                            <!-- End recent Posts -->
                           
                            <!-- End About -->
                        </div>
                        <!-- End Side Column -->
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->
           <?php include "include/footer.php" ?>
