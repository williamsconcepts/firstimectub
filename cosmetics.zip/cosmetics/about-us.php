<?php include "include/header.php" ?>
<?php include "include/nav.php" ?>



            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="row margin-vert-30">
                        <div class="col-md-12">
                            <h2 class="margin-bottom-10">About Us</h2>
                            <div class="row margin-bottom-30">
                                <div class="col-md-3 animate fadeInLeft">
                                    <p>Based in north Suffolk, redolencecare Cosmetics & skin care has been steadily accumulating industry experience for over two decades. Founded by Nigel Herrmann - Managing Director in 1988, he and wife Sue Herrmann, Finance Director, were joined by son Derek in 2004, who now works as Technical Sales Director.</p>
                                    <p>Himself a qualified Cosmetics & skin care chemist, Derek manages much of the new product development along with a growing team of chemists and research & development staff.</p>
                                </div>
                                <!-- Person Details -->
                                <div class="col-md-3 col-sm-3 col-xs-6 person-details margin-bottom-30">
                                    <figure>
                                        <figcaption>
                                            <h3 class="margin-bottom-10">ken
                                                <small>- STAFF</small>
                                            </h3>
                                            <span>Being only 40 miles from Felixstowe docks (the main UK port) and 100 miles from Heathrow ensures easy export to our entire international customer base.</span>
                                        </figcaption>
                                        <img src="assets/img/theteam/image1.jpg" alt="image1">
                                        <ul class="list-inline person-details-icons">
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-dribbble"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-google-plus"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </figure>
                                </div>
                                <!-- //Portfolio Item// -->
                                <!-- Person Details -->
                                <div class="col-md-3 col-sm-3 col-xs-6 person-details margin-bottom-30">
                                    <figure>
                                        <figcaption>
                                            <h3 class="margin-bottom-10">stella
                                                <small>- Sales Assistant</small>
                                            </h3>
                                            <span> Despite remaining a family business, we are proud to cater to a rapidly expanding export sector. </span>
                                        </figcaption>
                                        <img src="assets/img/theteam/image2.jpg" alt="image2">
                                        <ul class="list-inline person-details-icons">
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-dribbble"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-google-plus"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </figure>
                                </div>
                                <!-- //Portfolio Item// -->
                                <!-- Person Details -->
                                <div class="col-md-3 col-sm-3 col-xs-6 person-details margin-bottom-30">
                                    <figure>
                                        <figcaption>
                                            <h3 class="margin-bottom-10">Derick
                                                <small>- Support</small>
                                            </h3>
                                            <span> In the last three years, we have more than quadrupled our output- in part as the demand for natural and organic products has surged. This has led us to invest in the future growth of the company with production set to step up by sixty per cent in 2012.</span>
                                        </figcaption>
                                        <img src="assets/img/theteam/image3.jpg" alt="image3">
                                        <ul class="list-inline person-details-icons">
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-twitter"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-linkedin"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-facebook"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-dribbble"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#">
                                                    <i class="fa-lg fa-google-plus"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </figure>
                                </div>
                                <!-- //Portfolio Item// -->
                            </div>
                            <hr class="margin-bottom-50">
                            <div class="row">
                                <div class="col-md-6">
                                    <h3 class="margin-bottom-10">AIM</h3>
                                    <p>Our enthusiasm and passion for our bespoke development is evinced by the speed with which we treat visiting clients to a guided tour of the site.</p>
                                </div>
                                <div class="col-md-6">
                                    <!-- Progress Bars -->
                                    <h3 class="progress-label">SALES
                                        <span class="pull-right">92%</span>
                                    </h3>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 90%">
                                        </div>
                                    </div>
                                    <h3 class="progress-label">Marketing
                                        <span class="pull-right">82%</span>
                                    </h3>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 82%">
                                        </div>
                                    </div>
                                    <h3 class="progress-label">SEO
                                        <span class="pull-right">74%</span>
                                    </h3>
                                    <div class="progress progress-xs">
                                        <div class="progress-bar progress-bar-primary" role="progressbar" style="width: 74%">
                                        </div>
                                    </div>
                                    <!-- End Progress Bars -->
                                </div>
                            </div>
                            <hr class="margin-bottom-30">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <span class="fa-stack fa-2x margin-vert-30 margin-horiz-40 hidden-xs animate fadeInLeft">
                                                <i class="fa fa-circle fa-stack-2x color-gray"></i>
                                                <i class="fa fa-cogs fa-stack-1x fa-inverse color-white"></i>
                                            </span>
                                        </div>
                                        <div class="col-sm-8">
                                            <h3 class="margin-vert-10">GROWTH</h3>
                                            <p>Redolencecare Growth is out of this world</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <span class="fa-stack fa-2x margin-vert-30 margin-horiz-40 hidden-xs animate fadeInLeft">
                                                <i class="fa fa-circle fa-stack-2x color-gray"></i>
                                                <i class="fa fa-cloud-download fa-stack-1x fa-inverse color-white"></i>
                                            </span>
                                        </div>
                                        <div class="col-sm-8">
                                            <h3 class="margin-vert-10">TERM</h3>
                                            <p>Thank you Julie for 10 Year of Services!</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="row">
                                        <div class="col-sm-4">
                                            <span class="fa-stack fa-2x margin-vert-30 margin-horiz-40 hidden-xs animate fadeInLeft">
                                                <i class="fa fa-circle fa-stack-2x color-gray"></i>
                                                <i class="fa fa-cogs fa-stack-1x fa-inverse color-white"></i>
                                            </span>
                                        </div>
                                        <div class="col-sm-8">
                                            <h3 class="margin-vert-10">SAFETY</h3>
                                            <p>We take Safety Seriously at redolencecare Cosmetics & skin care!</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr class="margin-top-40">
                        </div>
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->


            <?php include "include/footer.php" ?>
