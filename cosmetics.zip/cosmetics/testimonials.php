<?php include "include/header.php" ?>
<?php include "include/nav.php" ?>



            <!-- === END HEADER === -->
            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="row margin-vert-40">
                        <!-- Begin Sidebar Menu -->
                       
                        <!-- End Sidebar Menu -->
                        <div class="col-md-9">
                            <div class="row">
                                <!-- Testimonials - Default Full Width -->
                                <div class="col-md-12">
                                    <div class="carousel slide testimonials" id="testimonials1">
                                        <ol class="carousel-indicators">
                                            <li class="active" data-slide-to="0" data-target="#testimonials-rotate">
                                            </li>
                                            <li data-slide-to="1" data-target="#testimonials1">
                                            </li>
                                            <li data-slide-to="2" data-target="#testimonials1">
                                            </li>
                                        </ol>
                                        <div class="carousel-inner">
                                            <div class="item active">
                                                <div class="col-md-12">
                                                    <p>
                                                        wow i have all to talk about the redolencecare cosmetics, its so nice and lovely.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/53.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Cristina Hall
                                                            <em>
                                                                product staff Developer, Business Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="col-md-12">
                                                    <p>
                                                        its actually the best i have ever used.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/99.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Anthony Watkins
                                                            <em>
                                                               organic cosmetics,  Designs Ltd.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="col-md-12">
                                                    <p>
                                                       it is very mild and gentle on the skin.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/78.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Jonathan Baker
                                                            <em>
                                                                CEO & Founder, Virtuoso Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonials-arrows pull-right">
                                        <a class="left" href="#testimonials1" data-slide="prev">
                                            <span class="fa fa-arrow-left"></span>
                                        </a>
                                        <a class="right" href="#testimonials1" data-slide="next">
                                            <span class="fa fa-arrow-right"></span>
                                        </a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <!-- End Testimonials - default full width -->
                            </div>
                            <hr class="margin-top-20">
                            <div class="row">
                                <!-- Testimonials - light 1/2 width -->
                                <div class="col-md-6">
                                    <div class="carousel slide testimonials" id="testimonials2">
                                        <ol class="carousel-indicators">
                                            <li class="active" data-slide-to="0" data-target="#testimonials2">
                                            </li>
                                            <li data-slide-to="1" data-target="#testimonials2">
                                            </li>
                                            <li data-slide-to="2" data-target="#testimonials2">
                                            </li>
                                        </ol>
                                        <div class="carousel-inner">
                                            <div class="item active">
                                                <div class="testimonials-bg-light col-md-12">
                                                    <p>
                                                       well i actually recomend it for anybody to use.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/87.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Jessie Rodgers
                                                            <em>
                                                                customer Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="testimonials-bg-light col-md-12">
                                                    <p>
                                                        i love the cucumber salatti extra norish.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/99.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Anthony Watkins
                                                            <em>
                                                               customer Ltd.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="testimonials-bg-light col-md-12">
                                                    <p>
                                                        it actually my first time of trying this product and it really glowing.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/78.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Jonathan Baker
                                                            <em>
                                                                CEO & Founder, Virtuoso Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonials-arrows pull-right">
                                        <a class="left" href="#testimonials2" data-slide="prev">
                                            <span class="fa fa-arrow-left"></span>
                                        </a>
                                        <a class="right" href="#testimonials2" data-slide="next">
                                            <span class="fa fa-arrow-right"></span>
                                        </a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <!-- End Testimonials - light 1/2 width -->
                                <!-- Testimonials - primary 1/2 width -->
                                <div class="col-md-6">
                                    <div class="carousel slide testimonials" id="testimonials3">
                                        <ol class="carousel-indicators">
                                            <li class="active" data-slide-to="0" data-target="#testimonials3">
                                            </li>
                                            <li data-slide-to="1" data-target="#testimonials3">
                                            </li>
                                            <li data-slide-to="2" data-target="#testimonials3">
                                            </li>
                                        </ol>
                                        <div class="carousel-inner">
                                            <div class="item active">
                                                <div class="testimonials-bg-primary col-md-12">
                                                    <p>
                                                       its the best and new.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/99.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Anthony Watkins
                                                            <em>
                                                               Business Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="testimonials-bg-primary col-md-12">
                                                    <p>
                                                        its the best skin care and facial care cream and product i ever used.
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/87.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Cristina Hall
                                                            <em>
                                                                customer Ltd.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="item">
                                                <div class="testimonials-bg-primary col-md-12">
                                                    <p>
                                                        it keeps you fresha nd smooth all day
                                                    </p>
                                                    <div class="testimonial-info">
                                                        <img alt="" src="assets/img/profiles/78.jpg" class="img-circle img-responsive" />
                                                        <span class="testimonial-author">
                                                            Jonathan Baker
                                                            <em>
                                                                CEO & Founder, Virtuoso Inc.
                                                            </em>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="testimonials-arrows pull-right">
                                        <a class="left" href="#testimonials3" data-slide="prev">
                                            <span class="fa fa-arrow-left"></span>
                                        </a>
                                        <a class="right" href="#testimonials3" data-slide="next">
                                            <span class="fa fa-arrow-right"></span>
                                        </a>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <!-- End Testimonials - primary 1/2 width -->
                            </div>
                            <hr class="margin-top-20">
                           
                                <!-- End Testimonials - dark 1/3 width -->
                              
                                <!-- Testimonials - default 2/3 width no image -->
                           
                        </div>
                    </div>
                </div>
            </div>
            <!-- === END CONTENT === -->
            <!-- === BEGIN FOOTER === -->
           <?php include "include/footer.php" ?>

