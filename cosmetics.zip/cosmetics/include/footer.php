 <!-- === BEGIN FOOTER === -->
            <div id="base">
                <div class="container bottom-border padding-vert-30">
                    <div class="row">
                        <!-- Disclaimer -->
<!--
                        <div class="col-md-4">
                            <h3 class="class margin-bottom-10">Disclaimer</h3>
                            <p>All stock products on this template demo are for presentation purposes only, intended to represent a live site and are not included with the template or in any of the Joomla51 club membership plans.</p>
                            <p>Most of the images used here are available from
                                <a href="http://www.shutterstock.com/" target="_blank">shutterstock.com</a>. Links are provided if you wish to purchase them from their copyright owners.</p>
                        </div>
-->
                        <!-- End Disclaimer -->
                        <!-- Contact Details -->
                        <div class="col-md-4 margin-bottom-20">
                            <h3 class="margin-bottom-10">Contact Details</h3>
                            <p>
                                <span class="fa-phone">UK Telephone:</span>+44 1163263869
                                <br>
                                
                                <span class="fa-envelope">Email:</span>
                                 <a href="mailto:info@redolencecare.com">info@redolencecare.com</a>
                                <br>
                                
                                <span class="fa-envelope">Email:</span>
                                <a href="mailto:support@redolencecare.com">support@redolencecare.com</a>
                                <br>
                                <span class="fa-link">Website:</span>
                                <a href="http://www.redolencecare.com">www.redolencecare.com</a>
                            </p>
                            <p>UK HEAD OFFICE ADDRESS : 20 Charles St, Leicester, LE1 3FG</p>
                            
                        </div>
                        <!-- End Contact Details -->
                        <!-- Sample Menu -->
                        <div class="col-md-4 margin-bottom-20">
                            <h3 class="margin-bottom-10">categories</h3>
                            <ul class="menu">
                                <li>
                                    <a class="fa-tasks" href="post.php?p_id=157">DEVELOPMENT</a>
                                </li>
                                <li>
                                    <a class="fa-users" href="post.php?p_id=161">RECRUITMENT</a>
                                </li>
                                <li>
                                    <a class="fa-signal" href="post.php?p_id=158">ORGANICS</a>
                                </li>
                                <li>
                                    <a class="fa-coffee" href="post.php?p_id=159">MANUFACTURERS</a>
                                </li>
                            </ul>
                            <div class="clearfix"></div>
                        </div>
                        <!-- End Sample Menu -->
                    </div>
                </div>
            </div>
            <!-- Footer -->
            <div id="footer" class="background-grey">
                <div class="container">
                    <div class="row">
                        <!-- Footer Menu -->
                        <div id="footermenu" class="col-md-8">
                            <ul class="list-unstyled list-inline">
                                <li>
                                    <a href="index.php" target="_blank">Home</a>
                                </li>
                                <li>
                                    <a href="about-us.php" target="_blank">About us</a>
                                </li>
                                <li>
                                    <a href="services.php" target="_blank">Services</a>
                                </li>
                                <li>
                                    <a href="contact.php" target="_blank">Contact us</a>
                                </li>
                            </ul>
                        </div>
                        <!-- End Footer Menu -->
                        <!-- Copyright -->
                        <div id="copyright" class="col-md-4">
                            <p class="pull-right">(c) 2019 Your Copyright Info</p>
                        </div>
                        <!-- End Copyright -->
                    </div>
                </div>
            </div>
            <!-- End Footer -->
            <!-- JS -->
            <script type="text/javascript" src="assets/js/jquery.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/bootstrap.min.js" type="text/javascript"></script>
            <script type="text/javascript" src="assets/js/scripts.js"></script>
            <!-- Isotope - Portfolio Sorting -->
            <script type="text/javascript" src="assets/js/jquery.isotope.js" type="text/javascript"></script>
            <!-- Mobile Menu - Slicknav -->
            <script type="text/javascript" src="assets/js/jquery.slicknav.js" type="text/javascript"></script>
            <!-- Animate on Scroll-->
            <script type="text/javascript" src="assets/js/jquery.visible.js" charset="utf-8"></script>
            <!-- Sticky Div -->
            <script type="text/javascript" src="assets/js/jquery.sticky.js" charset="utf-8"></script>
            <!-- Slimbox2-->
            <script type="text/javascript" src="assets/js/slimbox2.js" charset="utf-8"></script>
            <!-- Modernizr -->
            <script src="assets/js/modernizr.custom.js" type="text/javascript"></script>
            <!-- End JS -->
    </body>
</html>
<!-- === END FOOTER === -->