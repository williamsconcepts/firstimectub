 <div id="body-bg">
            <!-- Phone/Email -->
            <div id="pre-header" class="background-gray-lighter">
                <div class="container no-padding">
                    <div class="row hidden-xs">
                        <div class="col-sm-6 padding-vert-5">
                            <strong>Phone:</strong>&nbsp;+4401204238766
                        </div>
                        <div class="col-sm-6 text-right padding-vert-5" >
                           <strong>Email:</strong>&nbsp;<a href="mailto:info@redolencecare.com">info@redolencecare.com</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Phone/Email -->
     
            <!-- Header -->
            <div id="header">
                <div class="container">
                    <div class="row">
                        <!-- Logo -->
                        <div class="logo">
                            <a href="index.php" title="">
                                <img src="assets/img/logo.png" alt="Logo" />
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>
                </div>
            </div>
     <br>
     <hr>
            <!-- End Header -->
            <!-- Top Menu -->
            <div id="hornav" class="bottom-border-shadow">
                <div class="container no-padding border-bottom">
                    <div class="row">
                        <div class="col-m-8 no-padding">
                            <div class="visible-lg">
                                <ul id="hornavmenu" class="nav navbar-nav">
                                    <li>
                                        <a href="index.php" class="fa-home active">Home</a>
                                    </li>
                                    <li>
                                        <span class="fa-gears ">Products</span>
                                        <ul>
                                            <li class="parent">
                                                <span>Aromatherapy</span>
                                                <ul>
                                                    <li>
                                                        <a href="post.php?p_id=162">Bath Oils</a>
                                                    </li>
                                                    
                                                    <li>
                                                        <a href="post.php?p_id=167">Cucumber moisturizer</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=162">Salt Scrubs</a>
                                                    </li>
                                                     <li>
                                                        <a href="post.php?p_id=163">Shower Gels</a>
                                                    </li>
                                                     <li>
                                                        <a href="post.php?p_id=163">Rollerball Remidies</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            
                                                <li class="parent">
                                                <span>Cucumber Salads</span>
                                                <ul>
                                                    
                                                    
                                                    <li>
                                                        <a href="post.php?p_id=168">Mauste Kurkku</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=168">Kurkku salaati</a>
                                                    </li>
                                                    
                                                </ul>
                                            </li>
                                            
                                            <li class="parent">
                                                <span>Bath Products</span>
                                                <ul>
                                             <li>
                                                        <a href="post.php?p_id=162">Bath Milks</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=163">bubble bath</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=162">Hair & Body Washes</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=163">Shower Gels</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="parent">
                                                <span>Body Care</span>
                                                <ul>
                                          

                                                    <li>
                                                        <a href="post.php?p_id=164">Hand & Body Creams</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=164">Botanical Oils</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=164">Body Butters</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=164">Sun Protection Factors</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            
                                                <li class="parent">
                                                <span>Facial Care</span>
                                                <ul>

                                                    <li>
                                                        <a href="post.php?p_id=165">Anti-Aging</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=165">Blemish & Spot Solutions</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=165">Night & Day Creams</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=165">Lip Plumpers</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            
                                            <li class="parent">
                                                <span>Hair Care</span>
                                                                                       
                                                <ul>

                                                    <li>
                                                        <a href="post.php?p_id=166">Shampooo</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=166">Conditioners</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=166">Hair Oils</a>
                                                    </li>
                                                    <li>
                                                        <a href="post.php?p_id=166">Treatments</a>
                                                    </li>
                                                </ul>
                                            </li>
                                           
                                        </ul>
                                    </li>
                                    <li>
                                        <span class="fa-copy ">Services</span>
                                        <ul>
                                        
                                          
                                            <li>
                                                <a href="post.php?p_id=157">Developments</a>
                                            </li>
                                            <li>
                                                <a href="post.php?p_id=158">Organics</a>
                                            </li>
                                             <li>
                                                <a href="post.php?p_id=159">Manufacturing</a>
                                            </li>
                                             <li>
                                                <a href="post.php?p_id=160">Quality</a>
                                            </li>
                                             <li>
                                                <a href="post.php?p_id=161">Recruitment</a>
                                            </li>
                                            <li>
                                                <a href="faq.php">F.A.Q.</a>
                                            </li>
                                           
                                        </ul>
                                    </li>
                                    
                                     <li>
                                                <a href="dealers.php">Become a Dealer</a>
                                                
                                            </li>
                                    
                                      <li>
                                                <a href="testimonials.php">Testimonials</a>
                                                
                                            </li>
                                    
                                     <li>
                                                <a href="about-us.php">About Us</a>
                                            </li>
                               
                                      
                                   
                                    <li>
                                        <a href="contact.php" class="fa-comment ">Contact</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
<!--
                        <div class="col-md-4 no-padding">
                            <ul class="social-icons pull-right">
                            
                                <li class="social-googleplus">
                                    <a href="#" target="_blank" title="Google+"></a>
                                </li>
                            </ul>
                        </div>
-->
                    </div>
                </div>
            </div>
            <!-- End Top Menu -->
            <!-- === END HEADER === -->