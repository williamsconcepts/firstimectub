<?php include "include/header.php" ?>
<?php include "include/nav.php" ?>
<?php include "include/db.php" ?>



            <!-- === BEGIN CONTENT === -->
            <div id="content">
                <div class="container background-white">
                    <div class="row margin-vert-30">
                        <div class="col-md-12">
                            <h2 class="margin-bottom-10">BECOME A DEALERS</h2>
                            <div class="row margin-bottom-30">
<!--                                <div class="col-md-3 animate fadeInLeft">-->
                                    <p>Based in north Suffolk, redolencecare Cosmetics & skin care has been steadily accumulating industry experience for over two decades. Founded by Nigel Herrmann - Managing Director in 1988, he and wife Sue Herrmann, Finance Director, were joined by son Derek in 2004, who now works as Technical Sales Director.</p>
                                <p>We recruit to a variety of different roles and we appoint both highly skilled qualified professionals and developmental / entry level at the beginning of the career path to become a dealer. Our teams cover the following specialisms:All applications need to be made with a CV and introduction email or cover letter and sent to <a href="mailto:dealer@redolencecare.com">dealer@redolencecare.com</a></p>
                                    
                                </div>
                                
                                <hr>
                            
                            
                            
  <?php 
    
    $query = "SELECT * FROM users";
    $select_users = mysqli_query($connection,$query);  
    while($row = mysqli_fetch_assoc($select_users)) {
        $user_id             = $row['user_id'];
        $username            = $row['username'];
        $user_role       = $row['user_role'];
        $user_firstname      = $row['user_firstname'];
        $user_lastname       = $row['user_lastname'];
        $user_email          = $row['user_email'];
        $user_image          = $row['user_image'];
    
  
        
                               echo "<div class='col-md-4 col-sm-4 col-sm-6 person-details margin-bottom-30'>";
                                   echo "<figure>";
                                        echo "<figcaption>";
                                            echo "<h3 class='margin-bottom-10'>$username
                                                <small>- $user_role</small>
                                            </h3>";
        
                                    echo "<p>$user_firstname $user_lastname </p>";
                                            
                                            echo "<p>Email : <a href='mailto:$user_email'>$user_email</a></p>";
                            
                                            echo "<p>Position : $user_role</p>";
                                            
                                        echo "</figcaption>";
        
        echo "<img src='assets/img/theteam/$user_image' alt='image'>";
                                        
                                       
                                   echo " </figure>";
                                echo "</div>";
        
   
    }




      ?>
                            
                            
            
                                
                                
                      
                            </div>
                            <hr class="margin-bottom-50">
                           
                        </div>
                    </div>
                </div>

            <!-- === END CONTENT === -->


            <?php include "include/footer.php" ?>
