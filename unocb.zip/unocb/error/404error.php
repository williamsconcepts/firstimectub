<?php
	require_once '../files/head_section3.php';
	require_once '../files/navigation3.php';
?>



<div class="page_width">

	<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>

		<div id="error_404_msg"; class="left_float" width="496px" style="padding-top: 100px;">
			<p>Sorry, the page you are looking for has either expired or been removed.</p>
			<br>
			<p><a href="../client-area/creator.php">Login</a></p>
			<p><a href="../client-area/online-account-opening.php">Open Account</a></p>
			<p><a href="../contact/contact-us.php">Contact Us</a></p>
			<p><a href="../index.php">Home</a></p>
		</div>
		
		<div class="right_float" width="496px">
			<img src="/images/404-image.png">
		</div>
		<div class="clear"></div>

	</div>
	

</div>

<?php
	require_once '../files/footer3.php';
	require_once '../files/jsfiles3.php';
?>