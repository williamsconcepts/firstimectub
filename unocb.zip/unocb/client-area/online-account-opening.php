<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
	require_once '../files/connect.inc.php';

	$feedback = "";
	$feedback1 = "";
	$signature_name = "";
	$feedback_text = "";

	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	if(isset($_POST['reg_firstname']) &&
		isset($_POST['reg_middlename']) &&
	 	isset($_POST['reg_lastname']) &&
	 	isset($_POST['reg_suffix']) &&
	 	isset($_POST['reg_dob']) &&
	 	isset($_POST['reg_src_income']) &&
	 	isset($_POST['reg_address1']) &&
	 	isset($_POST['reg_address2']) &&
	 	isset($_POST['reg_city']) &&
	 	isset($_POST['reg_state']) &&
	 	isset($_POST['reg_zip']) &&
	 	isset($_POST['reg_country']) &&
	 	isset($_POST['reg_phone1']) &&
	 	isset($_POST['reg_phone2']) &&
	 	isset($_POST['reg_email']) &&
	 	isset($_POST['reg_email_rpt']) &&
	 	isset($_POST['reg_phone1_type']) &&
	 	isset($_POST['reg_phone2_type']) &&
	 	isset($_POST['reg_acc_type']) &&
	 	isset($_POST['reg_nos_firstname']) &&
	 	isset($_POST['reg_nos_middlename']) &&
	 	isset($_POST['reg_nos_lastname']) &&
	 	isset($_POST['reg_nos_address']) &&
	 	isset($_POST['reg_nos_phone']) &&
	 	isset($_POST['reg_nos_rel']) &&
	 	isset($_FILES['file_array'])){

		if(empty($_POST['reg_firstname']) ||
		 	empty($_POST['reg_lastname']) ||
		 	empty($_POST['reg_dob']) ||
		 	empty($_POST['reg_src_income']) ||
		 	empty($_POST['reg_address1']) ||
		 	empty($_POST['reg_city']) ||
		 	empty($_POST['reg_state']) ||
		 	empty($_POST['reg_zip']) ||
		 	empty($_POST['reg_country']) ||
		 	empty($_POST['reg_phone1']) ||
		 	empty($_POST['reg_email']) ||
		 	empty($_POST['reg_email_rpt']) ||
		 	empty($_POST['reg_phone1_type']) ||
		 	empty($_POST['reg_phone2_type']) ||
		 	empty($_POST['reg_nos_firstname']) ||
		 	empty($_POST['reg_nos_lastname']) ||
		 	empty($_POST['reg_nos_address']) ||
		 	empty($_POST['reg_nos_phone']) ||
		 	empty($_POST['reg_nos_rel']) ||
		 	empty($_POST['reg_acc_type'])){

			$feedback1 = "Please fill all non-optional fields.";

		}else{

			$regex = "/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i";
			$email = $_POST['reg_email'];
			$bool = preg_match($regex, $email);

			if($bool == false){
				$feedback1 = "Email is invalid. Please enter a valid email.";
				
			}else{

				if($_POST['reg_email'] != $_POST['reg_email_rpt']){
					$feedback1 = "The two emails don't match. Please verify them.";
				}else{

					$name_array = $_FILES['file_array']['name'];
					$size_array = $_FILES['file_array']['size'];
					$error_array = $_FILES['file_array']['error'];
					$type_array = $_FILES['file_array']['type'];
					$tmp_name_array = $_FILES['file_array']['tmp_name'];
					$target_dir = '../acc-images/';


					foreach ($name_array as $key => $value) {

						if($value == "" && $key != 1){
							$feedback1 = "Please attach the required files.";
						
						}else{

							$reg_firstname = sanitize_input($_POST['reg_firstname']);
							$reg_middlename = sanitize_input($_POST['reg_middlename']);
						 	$reg_lastname = sanitize_input($_POST['reg_lastname']);
						 	$reg_suffix = sanitize_input($_POST['reg_suffix']);
						 	$reg_dob = sanitize_input($_POST['reg_dob']);
						 	$reg_src_income = sanitize_input($_POST['reg_src_income']);
						 	$reg_address1 = sanitize_input($_POST['reg_address1']);
						 	$reg_address2 = sanitize_input($_POST['reg_address2']);
						 	$reg_city = sanitize_input($_POST['reg_city']);
						 	$reg_state = sanitize_input($_POST['reg_state']);
						 	$reg_zip = sanitize_input($_POST['reg_zip']);
						 	$reg_country = sanitize_input($_POST['reg_country']);
						 	$reg_phone1 = sanitize_input($_POST['reg_phone1']);
						 	$reg_phone2 = sanitize_input($_POST['reg_phone2']);
						 	$reg_email = sanitize_input($_POST['reg_email']);
						 	$reg_email_rpt = sanitize_input($_POST['reg_email_rpt']);
						 	$reg_phone1_type = sanitize_input($_POST['reg_phone1_type']);
						 	$reg_phone2_type = sanitize_input($_POST['reg_phone2_type']);
							$reg_acc_type = sanitize_input($_POST['reg_acc_type']);

							$reg_nos_firstname = sanitize_input($_POST['reg_nos_firstname']);
						 	$reg_nos_middlename = sanitize_input($_POST['reg_nos_middlename']);
						 	$reg_nos_lastname = sanitize_input($_POST['reg_nos_lastname']);
						 	$reg_nos_address = sanitize_input($_POST['reg_nos_address']);
						 	$reg_nos_phone = sanitize_input($_POST['reg_nos_phone']);
						 	$reg_nos_rel = sanitize_input($_POST['reg_nos_rel']);


							$timestamp = time();
							$time= @date('H:i:s', $timestamp -(60*60));
							$date = @date('d-m-Y', $timestamp - (60*60));
							$date_time = $date." ".$time;

							
							$transfer_code = rand(1111, 9999);
							$acc_number = rand(1111, 9999).rand(1111, 9999).rand(1111, 9999);
							$balance = "";
							$passcode = rand(11111111, 99999999);
							$online_id = $reg_firstname.".".$reg_lastname;
							$transfer_message = "";
							$transfer_acc_no = "";
							$transfer_amount = "";
							$email_token = md5($reg_email);
							$email_status = "Unverified";
							$transaction_id = "";
							$cot_code = rand(1111, 9999);
							$vat_code = rand(1111, 9999);
							$transfer_level = "";

							$query_check_email = "SELECT `email` FROM `boa_acc_clients` WHERE `email`='$reg_email'";
							$query_check_email_run = mysql_query($query_check_email);

							$query_check_phone = "SELECT `phone1`, `phone2` FROM `boa_acc_clients` WHERE `phone1`='$reg_phone1' || `phone2`='$reg_phone2'";
							$query_check_phone_run = mysql_query($query_check_phone);

							if (mysql_num_rows($query_check_email_run)==1){
								$feedback1 = "The email $reg_email has been used to register an account previously.";
							}else{

								if (mysql_num_rows($query_check_phone_run)==1){
									$feedback1 = "Phone number has been used to register an account previously.";
								}else{


									for ($i=0; $i < count($tmp_name_array); $i++) {

										$file_type_array = pathinfo($name_array[$i], PATHINFO_EXTENSION);

										if($file_type_array  == "jpg" ||
											$file_type_array  == "JPG" ||
										 	$file_type_array == "png" || 
										 	$file_type_array == "jpeg" ||
										 	$file_type_array == "gif" ){



												if($size_array[$i] <= 800097152){


													$file_name = $reg_firstname. $reg_lastname.rand(111111, 999999).".".$file_type_array;

													if($i == 0){
														$passport_name = $file_name;
													}

													if($i == 1){
														$signature_name = "";
													}

													if(move_uploaded_file($tmp_name_array[$i], $target_dir . $file_name)){
														$feedback = $name_array[$i]." uploaded successfully"."<br/>";
													}else{
														$feedback1 = $name_array[$i]." failed to upload"."<br/>";
													}

												}else{
													 $feedback1 ="The file" . $name_array[$i] . "is too large. All files must be less than 5mb."."<br/>";
												}


										}else if($i != 1){
											$feedback1 = $name_array[$i]. " file type not allowed. Types allowed include .pdf, .gif, .txt, .doc, .docx, .jpeg, .jpg and .png"."<br/>";
											//$file_type_array = pathinfo($name_array[$i], PATHINFO_EXTENSION)."<br/>";
										}


									}

										$query_register_client = "INSERT INTO `boa_acc_clients` VALUES('',
									 		'".mysql_real_escape_string($reg_firstname)."',
									 		'".mysql_real_escape_string($reg_middlename)."', 
									 		'".mysql_real_escape_string($reg_lastname)."', 
									 		'".mysql_real_escape_string($reg_suffix)."',
											'".mysql_real_escape_string($reg_dob)."',
											'".mysql_real_escape_string($reg_src_income)."',
											'".mysql_real_escape_string($reg_address1)."',
											'".mysql_real_escape_string($reg_address2)."',
											'".mysql_real_escape_string($reg_city)."',
											'".mysql_real_escape_string($reg_state)."',
									 		'".mysql_real_escape_string($reg_zip)."',
									 		'".mysql_real_escape_string($reg_country)."',  
									 		'".mysql_real_escape_string($reg_phone1)."',
									 		'".mysql_real_escape_string($reg_phone1_type)."',
											'".mysql_real_escape_string($reg_phone2)."',
											'".mysql_real_escape_string($reg_phone2_type)."',
											'".mysql_real_escape_string($reg_nos_firstname)."',
											'".mysql_real_escape_string($reg_nos_middlename)."',
											'".mysql_real_escape_string($reg_nos_lastname)."',
											'".mysql_real_escape_string($reg_nos_address)."',
											'".mysql_real_escape_string($reg_nos_phone)."',
											'".mysql_real_escape_string($reg_nos_rel)."',
											'".mysql_real_escape_string($reg_email)."',
											'$online_id',
											'$passcode',
											'$balance',
											'".mysql_real_escape_string($reg_acc_type)."',
											'$acc_number',
											'$date_time',
											'$passport_name',
											'$signature_name',
											'$transfer_code',
											'$transfer_message',
											'$transfer_acc_no',
											'$transfer_amount',
											'$email_status',
											'$email_token',
											'$transaction_id',
											'$cot_code',
											'$vat_code',
											'$transfer_level')";


									
									if($query_register_client_run = mysql_query($query_register_client)){

										$feedback = "Your form submission was successful. We will get back to you through your email and/or phone number.";


                                                                        $msg_num = $reg_phone1;

									$post_data=array(
									'sub_account'=>'3503_unocb',
									'sub_account_pass'=>'kompany',
									'action'=>'send_sms',
									'route'=>'1',
									'sender_id'=>'Unocb',
									'recipients'=>$msg_num,
									'message'=>"Hello $reg_firstname, your account opening form submission was successful. Your account number is $acc_number, online ID is $online_id and passcode is $passcode. Please log into your email and verify your email to be able to log into your new bank account."
									);
									
									$api_url='http://cheapglobalsms.com/api_v1';

									$ch = curl_init();
									curl_setopt($ch, CURLOPT_URL, $api_url);
									curl_setopt($ch, CURLOPT_POST, true);
									curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
									curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
									
									$response = curl_exec($ch);
									$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
									if($response_code != 200)$response=curl_error($ch);
									curl_close($ch);

									if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
									else
									{
										$json=@json_decode($response,true);
										
										if($json===null)$msg="INVALID RESPONSE: $response"; 
										elseif(!empty($json['error']))$msg=$json['error'];
										else
										{
											$msg="SMS sent to ".$json['total']." recipient(s).";
											$sms_batch_id=$json['batch_id'];
										}
									}
									
									$feedback_text = $msg;



										$body = <<<MAIL
<div style="background:#f4f4f4; width:100%; min-height:100%; padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%; text-align:right;">
<h4 style="margin-bottom:15px;">Registration Notification</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">

<div style="color: #333; font-family: arial, sans-serif">	

<br>
<p>Dear $reg_firstname $reg_lastname,</p>

<h3 style="text-align:center; margin:0px auto; margin-top:30px; color:#051f6b;">PLEASE READ THIS EMAIL IN FULL AND PRINT IT FOR YOUR RECORDS</h3>

<p>Your registration was successful. Please click or copy and paste this link in your browser's url to complete your registration.</p> <br>

<a href="http://www.unocb.com/verify/email-verify.php?email-token=$email_token" style="color:#36c; text-align:center;margin:0px auto; display:block;">http://www.unocb.com/verify/email-verify.php?email-token=$email_token</a><br><br><br>

<p>Please note that you must click on the link above to verify your email to be able to log into your new account.</p>

<h4 style="color:#051f6b; margin-bottom:-15px;">Account Details</h4>

<p style="margin-bottom:-15px; font-size:15px;">Account number: $acc_number</p>
<p style="margin-bottom:-15px; font-size:15px;">Online ID: $online_id</p>
<p style="font-size:15px;">Passcode: $passcode</p>

<h4 style="color:#051f6b; margin-bottom:-15px;">Personal Details</h4>

<p style="margin-bottom:-15px; font-size:15px;">First name: $reg_firstname</p>
<p style="margin-bottom:-15px; font-size:15px;">Middle name: $reg_middlename</p> 
<p style="margin-bottom:-15px; font-size:15px;">Last name: $reg_lastname</p>
<p style="margin-bottom:-15px; font-size:15px;">Suffix: $reg_suffix</p>
<p style="margin-bottom:-15px; font-size:15px;">Date of birth: $reg_dob</p>
<p style="font-size:15px;">Source of income: $reg_src_income</p> 

<h4 style="color:#051f6b; margin-bottom:-15px;">Address Details</h4>
<p style="margin-bottom:-15px; font-size:15px;">Address1: $reg_address1</p>
<p style="margin-bottom:-15px; font-size:15px;">Address2: $reg_address2</p>
<p style="margin-bottom:-15px; font-size:15px;">City: $reg_city</p>
<p style="margin-bottom:-15px; font-size:15px;">State: $reg_state</p>
<p style="margin-bottom:-15px; font-size:15px;">Zip Code: $reg_zip</p>
<p style="font-size:15px;">Country: $reg_country</p>

<h4 style="color:#051f6b; margin-bottom:-15px;">Contact Details</h4>
<p style="margin-bottom:-15px; font-size:15px;">Phone 1: $reg_phone1</p>
<p style="margin-bottom:-15px; font-size:15px;">Phone 1 type: $reg_phone1_type</p>
<p style="margin-bottom:-15px; font-size:15px;">Phone 2: $reg_phone2</p>
<p style="margin-bottom:-15px; font-size:15px;">Phone 2 type: $reg_phone2_type</p>
<p style="font-size:15px;">Email: $reg_email</p>

<h4 style="color:#051f6b; margin-bottom:-15px;">Verification Details</h4>
<p style="font-size:15px;">Passport: Attached</p>

</div>


<p style="margin-bottom:-15px; font-size:15px;">Best Regards,</p>
<p style="font-size:15px;">United Overseas Corporation Bank team</p>


<h4 style="border-bottom:1px solid #222; padding-bottom: 40px;">Thank you for banking with United Overseas Corporation Bank</h4>

</div>

<div>
<p>This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>
MAIL;


						
									$subject = 'United Overseas Corporation Bank Account opening';
									$sender = 'United Overseas Corporation Bank <account@unocb.com>';


									$headers = "From: $sender\r\n";
									$headers .= "X-Priority: 3\r\n";
									$headers .= "Reply-to: account@unocb.com\r\n";
									$headers .= "MIME-Version: 1.0\r\n";
									$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
									$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

									$sent = mail($reg_email, $subject, $body, $headers);


									break; //To break out of the loop after registering

								}else{
									$feedback = "Your form failed to submit";
								}

							}
					

						}

					}

				}

			}


		}

	}

}

?>
<div class="page_width">
	<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>

		<div id="register_page">
			<div class="register_page_section">
				<h4 style="text-align:center; color: #e31930;"><?php echo $feedback1; ?></h4>
				<h4 style="text-align:center; color: #006a4d;"><?php echo $feedback; ?></h4>
				<h1>Your Information</h1>
				<h2>Welcome. Apply in just minutes.</h2>
				<h3><img src="../images/info_icon_2x.svg" alt="" id="info"><span>How we identify you</span></h3>
				<p>United Overseas Corporation Bank, like all financial institutions, is required by law to obtain, verify and record information that identifies each customer that opens an account with us. When you open an account with us, we will ask you for your name, address and other information that will allow us to identify you.</p>
				<br>
				<p>The fields marked * are required.</p>
			</div>

			<form action="" method="post" id="online_register" enctype="multipart/form-data">

				<div class="register_page_section">
					<h4>Personal</h4>
					<div class="each_input_wrapper">
						<input name="reg_firstname" id="" type="text" placeholder="First name *" value="<?php if(isset($_POST['reg_firstname'])) {echo $_POST['reg_firstname'];} ?>" >
						<span>Legal name</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_middlename" id="" type="text" placeholder="Middle name" value="<?php if(isset($_POST['reg_middlename'])) {echo $_POST['reg_middlename'];} ?>" >
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_lastname" id="" type="text" placeholder="Last name *" value="<?php if(isset($_POST['reg_lastname'])) {echo $_POST['reg_lastname'];} ?>" >
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<select name="reg_suffix" id="">
							<option value="" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == '') {echo 'selected';} ?> >Suffix</option>
							<option value="Jr" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'Jr') {echo 'selected';} ?> >Jr</option>
							<option value="Sr" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'Sr') {echo 'selected';} ?> >Sr</option>
							<option value="II" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'II') {echo 'selected';} ?> >II</option>
							<option value="III" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'III') {echo 'selected';} ?> >III</option>
							<option value="IV" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'IV') {echo 'selected';} ?> >IV</option>
							<option value="V" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'V') {echo 'selected';} ?> >V</option>
							<option value="None" <?php if(isset($_POST['reg_suffix']) && $_POST['reg_suffix'] == 'None') {echo 'selected';} ?> >None</option>
						</select>
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_dob" id="" type="text" placeholder="Date of birth *" value="<?php if(isset($_POST['reg_dob'])) {echo $_POST['reg_dob'];} ?>" >
						<span>MM/DD/YYY</span>
					</div>

					<div class="each_input_wrapper">
						<select name="reg_src_income" id="">
							<option value="" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Antarctica [672]') {echo 'selected';} ?> >Source of income *</option>
							<option value="Employement income" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Employement income') {echo 'selected';} ?> >Employement income</option>
							<option value="Inheritance or Trust" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Inheritance or Trust') {echo 'selected';} ?> >Inheritance or Trust</option>
							<option value="Investment Income" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Investment Income') {echo 'selected';} ?> >Investment Income</option>
							<option value="Retirement Income" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Retirement Income') {echo 'selected';} ?> >Retirement Income</option>
							<option value="Social Security" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Social Security') {echo 'selected';} ?> >Social Security</option>
							<option value="Self Employed" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Self Employed') {echo 'selected';} ?> >Self Employed</option>
							<option value="Unemployed" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Unemployed') {echo 'selected';} ?> >Unemployed</option>
							<option value="Other" <?php if(isset($_POST['reg_src_income']) && $_POST['reg_src_income'] == 'Other') {echo 'selected';} ?> >Other</option>
						</select>
						<span></span>
					</div>
				</div>


				<div class="register_page_section">
					<h4>Address</h4>
					<div class="each_input_wrapper">
						<input name="reg_address1" id="" type="text" placeholder="Address 1 *" value="<?php if(isset($_POST['reg_address1'])) {echo $_POST['reg_address1'];} ?>" >
						<span>No P.O. Boxes</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_address2" id="" type="text" placeholder="Address 2" value="<?php if(isset($_POST['reg_address2'])) {echo $_POST['reg_address2'];} ?>" >
						<span>If any</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_city" id="" type="text" placeholder="City *" value="<?php if(isset($_POST['reg_city'])) {echo $_POST['reg_city'];} ?>" >
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_state" id="" type="text" placeholder="State *" value="<?php if(isset($_POST['reg_state'])) {echo $_POST['reg_state'];} ?>" >
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_zip" id="" type="text" placeholder="ZIP Code *" value="<?php if(isset($_POST['reg_zip'])) {echo $_POST['reg_zip'];} ?>" >
						<span>First 5 digits required</span>
					</div>

					<div class="each_input_wrapper">
						<select name="reg_country" id="">
							<?php require_once '../files/country_list.php';?>
						</select>
						<span></span>
					</div>
				</div>


				<div class="register_page_section">
					<h4>Contact</h4>
					<div class="each_input_wrapper">
						<input name="reg_phone1" id="" type="text" placeholder="Phone number *" value="<?php if(isset($_POST['reg_phone1'])) {echo $_POST['reg_phone1'];} ?>" >
						<span>In international format eg +123456789</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_phone2" id="" type="text" placeholder="Phone number 2" value="<?php if(isset($_POST['reg_phone2'])) {echo $_POST['reg_phone2'];} ?>" >
						<span>If any</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_email" id="" type="text" placeholder="Email address *" value="<?php if(isset($_POST['reg_email'])) {echo $_POST['reg_email'];} ?>" >
						<span>Verification link and other mails will be sent to this email</span>
					</div>

					<div class="each_input_wrapper">
						<select name="reg_phone1_type" id="">
							<option value="" <?php if(isset($_POST['reg_phone1_type']) && $_POST['reg_phone1_type'] == '') {echo 'selected';} ?> >Phone number type *</option>
							<option value="Home" <?php if(isset($_POST['reg_phone1_type']) && $_POST['reg_phone1_type'] == 'Home') {echo 'selected';} ?> >Home</option>
							<option value="Work" <?php if(isset($_POST['reg_phone1_type']) && $_POST['reg_phone1_type'] == 'Work') {echo 'selected';} ?> >Work</option>
							<option value="Mobile" <?php if(isset($_POST['reg_phone1_type']) && $_POST['reg_phone1_type'] == 'Mobile') {echo 'selected';} ?> >Mobile</option>
						</select>
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<select name="reg_phone2_type" id="">
							<option value="" <?php if(isset($_POST['reg_phone2_type']) && $_POST['reg_phone2_type'] == '') {echo 'selected';} ?> >Phone number 2 type</option>
							<option value="Home" <?php if(isset($_POST['reg_phone2_type']) && $_POST['reg_phone2_type'] == 'Home') {echo 'selected';} ?> >Home</option>
							<option value="Work" <?php if(isset($_POST['reg_phone2_type']) && $_POST['reg_phone2_type'] == 'Work') {echo 'selected';} ?> >Work</option>
							<option value="Mobile" <?php if(isset($_POST['reg_phone2_type']) && $_POST['reg_phone2_type'] == 'Mobile') {echo 'selected';} ?> >Mobile</option>
						</select>
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_email_rpt" id="" type="text" placeholder="Re-enter email address *" value="<?php if(isset($_POST['reg_email_rpt'])) {echo $_POST['reg_email_rpt'];} ?>" >
						<span></span>
					</div>

				</div>

				<div class="register_page_section">
					<h4>Account</h4> 
					<div class="each_input_wrapper">
						<select name="reg_acc_type" id="">
							<option value="" <?php if(isset($_POST['reg_acc_type']) && $_POST['reg_acc_type'] == '') {echo 'selected';} ?> >Account type *</option>
							<option value="Savings" <?php if(isset($_POST['reg_acc_type']) && $_POST['reg_acc_type'] == 'Savings') {echo 'selected';} ?> >Savings</option>
							<option value="Checking" <?php if(isset($_POST['reg_acc_type']) && $_POST['reg_acc_type'] == 'Checking') {echo 'selected';} ?> >Checking</option>
							<option value="Deposit" <?php if(isset($_POST['reg_acc_type']) && $_POST['reg_acc_type'] == 'Deposit') {echo 'selected';} ?> >Deposit</option>
						</select>
						<span>Select type of account you wish to open</span>
					</div>
				</div>

				<div class="register_page_section">
					<h4>Verification</h4> 
					<div class="each_input_wrapper">
						<input name="file_array[]" id="" type="file" class="apply_input" multiple>
						<span>Attach your scanned passport photograph (200px X 200px)</span>
					</div>

					<!-- <div class="each_input_wrapper">
						<input name="file_array[]" id="" type="file" class="apply_input" multiple>
						<span>Attach your scanned signature</span>
					</div> -->

					<!-- <div class="each_input_wrapper">
						<input name="file_array[]" id="" type="file" class="apply_input" multiple>
						<span>Attach scanned Driver's license or International passport or Voter’s ID, etc</span>
					</div> -->

					<p style="margin-left:0px; margin-top:10px;"><strong>Note: </strong>File formats accepted are png, jpg, jpeg and gif.</p>

				</div>


				<div class="register_page_section">
					<h4>Next of Kin</h4>
					<div class="each_input_wrapper">
						<input name="reg_nos_firstname" id="" type="text" placeholder="First name *" value="<?php if(isset($_POST['reg_nos_firstname'])) {echo $_POST['reg_nos_firstname'];} ?>" >
						<span>Legal name</span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_nos_middlename" id="" type="text" placeholder="Middle name" value="<?php if(isset($_POST['reg_nos_middlename'])) {echo $_POST['reg_nos_middlename'];} ?>" >
						<span></span>
					</div>

					<div class="each_input_wrapper">
						<input name="reg_nos_lastname" id="" type="text" placeholder="Last name *" value="<?php if(isset($_POST['reg_nos_lastname'])) {echo $_POST['reg_nos_lastname'];} ?>" >
						<span></span>
					</div>


					<div class="each_input_wrapper">
						<input name="reg_nos_address" id="" type="text" placeholder="Address *" value="<?php if(isset($_POST['reg_nos_address'])) {echo $_POST['reg_nos_address'];} ?>" >
						<span>Next of Kin Address</span>
					</div>


					<div class="each_input_wrapper">
						<input name="reg_nos_phone" id="" type="text" placeholder="Phone Number *" value="<?php if(isset($_POST['reg_nos_phone'])) {echo $_POST['reg_nos_phone'];} ?>" >
						<span>Next of Kin Address</span>
					</div>


					<div class="each_input_wrapper">
						<select name="reg_nos_rel" id="">
							<option value="" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == '') {echo 'selected';} ?> >Relationship *</option>
							<option value="Brother" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Brother') {echo 'selected';} ?> >Brother</option>
							<option value="Sister" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Sister') {echo 'selected';} ?> >Sister</option>
							<option value="Father" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Father') {echo 'selected';} ?> >Father</option>
							<option value="Mother" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Mother') {echo 'selected';} ?> >Mother</option>
							<option value="Aunt" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Aunt') {echo 'selected';} ?> >Aunt</option>
							<option value="Uncle" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Uncle') {echo 'selected';} ?> >Uncle</option>
							<option value="Brother-Inlaw" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Brother-Inlaw') {echo 'selected';} ?> >Brother-Inlaw</option>
							<option value="Sister-Inlaw" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Sister-Inlaw') {echo 'selected';} ?> >Sister-Inlaw</option>
							<option value="Father-Inlaw" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Father-Inlaw') {echo 'selected';} ?> >Father-Inlaw</option>
							<option value="Mother-Inlaw" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Mother-Inlaw') {echo 'selected';} ?> >Mother-Inlaw</option>
							<option value="Husband" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Husband') {echo 'selected';} ?> >Husband</option>
							<option value="Wife" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Wife') {echo 'selected';} ?> >Wife</option>
							<option value="Cousin" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Cousin') {echo 'selected';} ?> >Cousin</option>
							<option value="Other" <?php if(isset($_POST['reg_nos_rel']) && $_POST['reg_nos_rel'] == 'Other') {echo 'selected';} ?> >Other</option>
						</select>
						<span>Your Relationship with your next of kin</span>
					</div>

				</div>
				
				<input type="submit" value="Submit" id="sign_in_submit">
				<br>
			</form>

		</div>


		<div class="clear"></div>
		
	</div>
	
	
</div>
<br>
<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>