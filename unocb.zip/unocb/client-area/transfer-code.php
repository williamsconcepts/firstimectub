<?php
ob_start( );
session_start();
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
	require_once '../files/connect.inc.php';

	$feedback = "";
	$online_id = "";
	$passcode = "";
	$logged_in = "";

	if (isset($_SESSION['online_id_session'])) {
		$online_id = $_SESSION['online_id_session'];
	}

	if (isset($_SESSION['passcode_session'])) {
		$passcode = $_SESSION['passcode_session'];
	}


	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}



	if($online_id != "" && $passcode != "") {


		if($online_id == "" && $passcode == ""){

			header('location: location: creator.php?identifier=empty');
			return false;
		}else{

			if(isset($_POST['passcode'])){
				$online_id = sanitize_input($online_id);
				$passcode = sanitize_input($_POST['passcode']);
			}

			

			$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
			
			$query_run = mysql_query($query);
			if (mysql_num_rows($query_run)>=1) {

				$query_row = mysql_fetch_assoc($query_run);
				$firstname = $query_row['firstname'];
				$middlename = $query_row['middlename'];
				$lastname = $query_row['lastname'];
				$acc_type = $query_row['acc_type'];
				$acc_number = $query_row['acc_number'];
				$balance = $query_row['balance'];
				$phone1 = $query_row['phone1'];
				$online_id = $query_row['online_id'];

				$nos_firstname = $query_row['reg_nos_firstname'];
				$nos_middlename = $query_row['reg_nos_middlename'];
				$nos_lastname = $query_row['reg_nos_lastname'];

				$passport_name = $query_row['passport_name'];
				$signature_name = $query_row['signature_name'];
				$email_status = $query_row['email_status'];

				$transfer_message = $query_row['transfer_message'];

				if($email_status == "Verified"){
					$_SESSION['online_id_session'] = $online_id;
					$_SESSION['passcode_session'] = $passcode;

					if(isset($_POST['sign_in_checkbox'])){
						$cookie_name = "keep_me_signed_in";
						$cookie_value = "true";
						setcookie($cookie_name, $cookie_value, time() + (86400 * 100), "/");
					}

					$cookie_name2 = "is_signed_in";
					$cookie_value2 = "true";
					setcookie($cookie_name2, $cookie_value2, time() + (86400 * 100), "/");

					$logged_in = true;
				}else{
					session_destroy();
					header('location: location: creator.php?email-status=unverified');
					return false;
				}

				

			}else{
				session_destroy();
				header('location: creator.php?identifier=false');
				return false;
			}

		}

	}





?>

<?php
	if($logged_in == true){
?>
<div class="page_width">
	<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>

		<div id="account_area_wrapper">

			<div id="account_area_top" class="right_float">

				
				<div id="account_area_top_detail" class="right_float">
					<p><?php echo "$firstname $middlename $lastname";?></p>
					<p><?php echo "$acc_number";?></p>
					<p><?php echo "$balance";?></p>
				</div>

				<div id="account_area_top_head" class="right_float">
					<p>Client Name: </p>
					<p>Acct No.: </p>
					<p>Current Bal.: </p>
				</div>


				<div class="clear"></div>


			</div>

			<div class="clear"></div>

			<div id="account_area_side_link" class="left_float">

				<ul>
					<li><a href="online-account.php">Client Home</a></li>
					<li class="sub"><a href="">Profile</a>
						<ul>
							<li><a href="profile-details.php">View Profile</a></li>
							<li><a href="edit-details.php">Edit Profile Details</a></li>
						</ul>
					</li>

					<li class="sub"><a href="">Account Cabinet</a>
						<ul>
							<li><a href="account-summary.php">View Account Summary</a></li>
							<li><a href="transfer-fund.php">Transfer Fund Online</a></li>
							<li><a href="account-history.php">View Fund Transfer History</a></li>
							<li><a href="account-history.php">Transaction History</a></li>
							<li><a href="bill-payment-status.php">Bill Payments Status</a></li>
							<li><a href="send-echeque.php">Send eCheque</a></li>
						</ul>
					</li>

					<li><a href="password-change.php">Change Password</a></li>
					<li><form action='../files/sign_out.php' method='post'> <input type='submit' id='sign_out' name='sign_out' value='Sign out'></form></li>
				</ul>

			</div>

			<div class="activities_panel left_float" id="transfer_authorization_panel">
				<h3>Transfer Authorization Code</h3>
				<!-- <div class="panel_close">Close</div> -->

				<div id="complete_transfer_feebk" class="transfer_fdbk"></div>

				<form action="" method="post" id="authorization_form">
					<label for="transfer_code">Transfer authorization code</label>
					<input type="text" class="local_transfer_input" id="transfer_code">

					<div id="transfer_authorization_submit">Authorize</div>
					<!-- <input type="submit" value="Pay now" id="transfer_submit"> -->

					<div id="authorization_wu">
						<h3 id="authorization_head">Don't have authorization code?</h3>
						<p>contact <a href="mailto:info@unocb.com" target="_blank">info@unocb.com</a></p>
						<p>Authorization code helps us to keep your account safe.</p>
						<p>Take note that authorization code is a one-time passcode.</p>
					</div>
				</form>

				<?php
					if (isset($_GET['transfer-code']) && $_GET['transfer-code'] == 'requested' ){

						echo " <script>
								document.getElementById('transfer_authorization_panel').style.display = 'block'; 
							</script>";
					}
				?>

			</div>

			<div class="clear"></div>



		</div>

	</div>

</div>
<br>
<?php
}else{
	header('location: location: creator.php?session=false');
}
?>
<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>