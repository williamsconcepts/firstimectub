<?php
ob_start( );
session_start();

	if (file_exists($_SESSION["login_page"])) {
		unlink($_SESSION["login_page"]);
		unset($_SESSION["login_page"]);
	}

	if (file_exists($_SESSION["password_page"])) {
		unlink($_SESSION["password_page"]);
		unset($_SESSION["password_page"]);
	}

	if (file_exists($_SESSION["account_page"])) {
		unlink($_SESSION["account_page"]);
		unset($_SESSION["account_page"]);
	}

	$timestamp = time();
	$page_name = "login-id-".md5($timestamp).".php";
	$page_cotent = '<?php
ob_start( );
session_start();
	require_once "../files/head_section2.php";
	require_once "../files/navigation2.php";
	require_once "../files/connect.inc.php";

	$feedback = "";
	$feedback1 = "";

	if (isset($_SESSION["online_id_session"]) && isset($_SESSION["passcode_session"])) {
		header("location: account-creator.php");
	}

	if (isset($_GET["identifier"]) && $_GET["identifier"] == "empty"){
		$feedback = "Online ID/Passcode empty";
	}else if(isset($_GET["identifier"]) && $_GET["identifier"] == "false"){
		$feedback = "Online ID/Passcode do not match";
	}else if(isset($_GET["login-id"]) && $_GET["login-id"] == "false"){
		$feedback = "Online ID does not exist";
	}else if(isset($_GET["login-id"]) && $_GET["login-id"] == "empty"){
		$feedback = "Online ID does ot exist";
	}else if(isset($_GET["session"]) && $_GET["session"] == "false"){
		$feedback = "You do not have an existing session";
	}else if(isset($_GET["email-status"]) && $_GET["email-status"] == "unverified"){
		$feedback = "Your email address is unverified. Please log into your email and verify your email.";
		$feedback1 = "Without verifying your email you cannot log into your account.";
	}



	if(isset($_POST["online_id"])){

		if(!empty($_POST["online_id"])){

			$online_id = $_POST["online_id"];

			$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`=\"$online_id\" ";
				
				$query_run = mysql_query($query);
				if (mysql_num_rows($query_run)>=1) {
					$query_row = mysql_fetch_assoc($query_run);
					$firstname = $query_row["firstname"];

					$online_id = $_POST["online_id"];
					$_SESSION["online_id_session"] = $online_id;

					$_SESSION["login_page"] = basename($_SERVER["PHP_SELF"]);

					if (file_exists($_SESSION["login_page"])) {
						unlink($_SESSION["login_page"]);
						unset($_SESSION["login_page"]);
					}


					header("location: pass-creator.php");
					return false;
				}else{
					$feedback = "Online ID does not exist";

					$_SESSION["login_page"] = basename($_SERVER["PHP_SELF"]);
					if (file_exists($_SESSION["login_page"])) {
						unlink($_SESSION["login_page"]);
						unset($_SESSION["login_page"]);
					}

					header("location: creator.php?login-id=false");
				}

			

		}else{
			$feedback = "Online ID is empty";
			$_SESSION["login_page"] = basename($_SERVER["PHP_SELF"]);
			if (file_exists($_SESSION["login_page"])) {
				unlink($_SESSION["login_page"]);
				unset($_SESSION["login_page"]);
			}
			
			header("location: creator.php?login-id=false");
		}

			

	}else{

	}


?>
<div class="page_width">
	
	<div id="hidden_login_preloader" class=""><img src="../images/loading.gif"></div>

	<div id="personal_sub" class="sub_pages hidden_login">

		<div id="login_wrap" class="left_float">

			<div class="strip"></div>
			<h4 id="login_feedback"><?php echo $feedback;?></h4>
			<h4 id="login_feedback"><?php echo $feedback1;?></h4>

			<div id="loading"><img src="../images/loading.gif"></div>
			<br>
			<br>
			<form action="" method="post" id="online_login" class="left_float">
				<label for="online_id">Online ID</label>
				<input type="text" name="online_id" class="sign_in_input" id="online_id" placeholder="Online ID"  value="<?php if(isset($_POST["online_id"])) {echo $_POST["online_id"];} ?>" >
				<br>
				<input type="checkbox" name="sign_in_checkbox" id="sign_in_checkbox" class="left_float">
				<label for="sign_in_checkbox" class="left_float" id="sign_in_checkbox_label">Save Online ID</label>
				<div class="clear"></div>
				
				<br>
				<!-- <label for="passcode">Passcode</label>
				<input type="text" name="passcode" class="sign_in_input left_float" id="passcode" placeholder="Passcode">
				<a href="#" id="forgot_passcode" class="sign_in_sfont left_float">Forgot Passcode</a> -->
				<div class="clear"></div>
				<input type="submit" value="Sign In" id="sign_in_submit">
				<br>
			</form>

			<div id="online_login_aside">
				<h3>Sign-in help</h3>
				<a href="#">Forgot your Online ID?</a>
				<a href="#">Forgot your Passcode?</a>

				<h3>Not using Online Banking?</h3>
				<a href="online-account-opening.php" class="">Enroll now</a>
			</div>


		</div>


		<div id="instruction_wrap" class="left_float">
			<img src="../images/login_img.jpg" width="100%">
		</div>
		
		<div class="clear"></div>

	</div>
</div>
<br>
<?php
	require_once "../files/footer2.php";
	require_once "../files/jsfiles2.php";
?>';


	if (file_exists($page_name)) {
		
		sleep(2);
		header('location: '.basename($_SERVER['PHP_SELF']));
	}else{

		$handle = fopen($page_name, 'w');

		fwrite($handle, $page_cotent);
		fclose($handle);
		
		$_SESSION["login_page"] = $page_name;
		

		if(isset($_GET['identifier']) && $_GET['identifier'] == 'false'){
			header('location: '.$page_name.'?identifier=false');
		}else if(isset($_GET['identifier']) && $_GET['identifier'] == 'empty'){
			header('location: '.$page_name.'?identifier=empty');
		}else if(isset($_GET['login-id']) && $_GET['login-id'] == 'false'){
			header('location: '.$page_name.'?login-id=false');
		}else if(isset($_GET['login-id']) && $_GET['login-id'] == 'empty'){
			header('location: '.$page_name.'?login-id=empty');
		}else if(isset($_GET['session']) && $_GET['session'] == 'false'){
			header('location: '.$page_name.'?session=false');
		}else{
			header('location: '.$page_name);
		}


	}



	

?>