
    <?php
	require_once 'files/head_section.php';
	require_once 'files/navigation.php';
?>

		<!-- slider area start -->
		<section class="slider-area">
			<div class="slider-active2 slider-next-prev-style">
				<div class="slider-items">
					<img src="assets/images/slider/4.jpg" alt="" class="slider">
					<div class="slider-content text-center">
						<div class="table">
							<div class="table-cell">
								<div class="container">
									<div class="row">
										<div class="col-xs-12 col-md-8 col-md-offset-2">
											<h2>Welcome to United Overseas Corporation Bank </h2>
											<p>Deals & Discounts
                                            Discover the many free perks of membership in United Overseas Corporation Bank.</p>
											<ul>
												<li><a href="client-area/creator.php">Read More</a></li>
												<li><a href="about.php">Secure Login</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="slider-items">
					<img src="assets/images/slider/3.jpg" alt="" class="slider">
					<div class="slider-content text-center">
						<div class="table">
							<div class="table-cell">
								<div class="container">
									<div class="row">
										<div class="col-xs-12 col-md-8 col-md-offset-2">
											<h2>Send And Receive Guaranteed Funds To Companies Or Individuals Around The World</h2>
											<p>Log in to online banking and notify United Overseas Corporation Bank of your upcoming travel plans.</p>
											<ul>
												<li><a href="client-area/creator.php">Secure Login</a></li>
												<li><a href="about.php">Read More</a></li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- slider area end -->

		<!-- about-area start -->
		<section class="about-area ptb-140">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-xs-12 wow fadeInLeft">
						<div class="about-img black-opacity">
							<img src="assets/images/about.jpg" alt="" />
						</div>
					</div>
					<div class="col-md-6 col-xs-12 wow fadeInRight">
						<div class="about-wrap">
							<h2>who we are</h2>
							<p>Feel at home with a mortgage that fits your needs.
Whether you're buying a new home or refinancing, get guidance on calculating the
costs, choosing the right loan, and understanding the next steps.</p>
							<p>We help you grow, protect and transition your wealth with award-winning
wealth management services like investment management and wealthplanning.</p>
							<ul>
								<li>Online Banking</li>
								<li>Loan Requests.</li>
								<li>Mortgages</li>
								<li>Open an Account with us</li>
								<li>Swift and reliable</li>
								<li>Secure Transfer Interface</li>
								<li>Western union and moneygram accepted.</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- about-area end -->

		<!-- .service-area start -->
		<section class="service-area pb-140">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
						<div class="section-title text-center">
							<h2>Our Special Service</h2>
							<p>Transactions are processed in a timely manner,
Incoming wire transfers are immediately credited to your account.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".1s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/1.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>Performance</h3>
								<p>Annualized return for United Overseas Corporation Bank® Balanced Portfolio Series A: since inception 7.65%; 1-year 4.6%; 3-year 7.61%. Series A as at October 12th, 2016.</p>
								<a href="mortgages/mortgage-rates-fixed.php">Read More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".2s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/2.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>Wire Transfers</h3>
                                <p>How To Send A Wire Transfer</p><br>
<p>To send a wire transfer, either visit an an United Overseas Corporation branch location or call us at 1-800-999-3961.

There is a fee for outgoing wire transfers. For details, please see the Bank to Bank Transfer fees in our Truth-in-Savings Rate and Fee Schedule.</p>

<p>How To Receive A Wire Transfer<br>
To receive a wire transfer, please provide the following information to the business or individual sending the wire.
<br>
Wire Routing and Transit Number: 324377516
Financial Institution Name: United Overseas Corporation Bank® Federal Credit Union
City, State: Ogden, Utah
Your United Overseas Corporation Bank Account Number
Type of Account: Savings, Money Market, Checking, etc.</p>
								<a href="bank-accounts/banking-services.php">Read More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".3s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/3.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>investments</h3>
								<p>Commissions, trailing commissions, management fees and expenses may be associated with mutual fund investments. Please read the fund facts or prospectus before investing.</p>
								<a href="loans/rrsp-and-investments.php">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- .service-area end -->

		<!-- fanfact-area start -->
		<section class="fanfact-area parallax black-opacity"  data-speed="5" data-bg-image="assets/images/bg/1.jpg">
			<div class="table">
				<div class="table-cell">
					<div class="container">
						<div class="row">
							<div class="col-md-3 col-sm-3 col-xs-6 wow fadeInUp"  data-wow-delay=".1s">
								<div class="fanfact-wrap">
									<h2 class="counter">2157</h2>
									<p>Loans</p>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 col-xs-6 wow fadeInUp"  data-wow-delay=".2s">
								<div class="fanfact-wrap">
									<h2 class="counter">15445</h2>
									<p>Clients</p>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 col-xs-6 wow fadeInUp"  data-wow-delay=".3s">
								<div class="fanfact-wrap">
									<h2 class="counter">145</h2>
									<p>Staffs</p>
								</div>
							</div>
							<div class="col-md-3 col-sm-3 col-xs-6 wow fadeInUp"  data-wow-delay=".4s">
								<div class="fanfact-wrap">
									<h2 class="counter">49</h2>
									<p>Countries and Locations</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- fanfact-area end -->

		<!-- porftolio-area start -->
		<section class="porftolio-area ptb-70">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
						<div class="section-title text-center">
							<h2>Our Best Work areas</h2>
							<p>Our fast and most reliable area.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12">
						<div class="portfolio-menu text-center">
							<button class="active" data-filter="*">Loans</button>
							<button data-filter=".website">Mortgages</button>
							<button data-filter=".responsiv">Secure business account</button>
							<button data-filter=".minimal">Swift Transfer</button>
							<button data-filter=".clean">Credit Cards</button>
							<button data-filter=".clean">Customer Care and quick Response</button>
						</div>
					</div>
				</div>
				<div class="row grid">
					<div class="col-md-4 portfolio clean col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".1s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="assets/images/portfolio/1.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>banking coroperation</h3>
								
							</div>
							<div class="portfolio-img">
								<img src="assets/images/portfolio/1.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio website col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".2s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="assets/images/portfolio/2.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>Security field</h3>
<!--								<p>The majority have suffered alteration in some form</p>-->
							</div>
							<div class="portfolio-img">
								<img src="assets/images/portfolio/2.jpg" alt="" />
							</div>
						</div>
					</div>
					<div class="col-md-4 portfolio minimal col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".3s">
						<div class="portfolio-wrap">
							<div class="overlay">
								<a class="popup" href="assets/images/portfolio/3.jpg">
									<i class="fa fa-link"></i>
								</a>
								<h3>Automated Banking Hall</h3>
<!--								<p>The majority have suffered alteration in some form</p>-->
							</div>
							<div class="portfolio-img">
								<img src="assets/images/portfolio/3.jpg" alt="" />
							</div>
						</div>
					</div>
					
					
				</div>
			</div>
		</section>
		<!-- porftolio-area end -->

		<!-- featured-area start -->
		<div class="featured-area pb-140">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
						<div class="section-title text-center">
							<h2>Our Special features & Progects</h2>
<!--							<p>the majority have suffered alteration in some form, by injected humour, or randomised. by injected humour, or randomised.</p>-->
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12">
						<div class="featured-wrap">
							<ul>
								<li class="wow fadeInLeft" data-wow-delay=".1s">
									<h3>2013</h3>
									<div class="featured-content">
										<div class="featured-img">
											<img src="assets/images/featured/1.jpg" alt="" />
										</div>
										<div class="featured-info">
											<h4>Application of Loan</h4>
											<p>we altered the application of loan request.</p>
										</div>
									</div>
								</li>
								<li class="wow fadeInRight" data-wow-delay=".2s">
									<h3>2014</h3>
									<div class="featured-content">
										<div class="featured-img">
											<img src="assets/images/featured/2.jpg" alt="" />
										</div>
										<div class="featured-info">
											<h4>Credit cards</h4>
											<p>Alteration in some forms, by introduction of card online transfer.</p>
										</div>
									</div>
								</li>
								<li class="wow fadeInLeft" data-wow-delay=".3s">
									<h3>2015</h3>
									<div class="featured-content">
										<div class="featured-img">
											<img src="assets/images/featured/3.jpg" alt="" />
										</div>
										<div class="featured-info">
											<h4>Mortgages </h4>
											<p>Alteration in some forms, by introduction of Mortgages.</p>
										</div>
									</div>
								</li>
								<li class="wow fadeInRight" data-wow-delay=".4s">
									<h3>2016</h3>
									<div class="featured-content">
										<div class="featured-img">
											<img src="assets/images/featured/4.jpg" alt="" />
										</div>
										<div class="featured-info">
											<h4>mobile App Development</h4>
											<p>Alteration in some form, by introduction of mobile App Development and software improvement.</p>
										</div>
									</div>
								</li>
								<li class="wow fadeInLeft" data-wow-delay=".5s">
									<h3>2017</h3>
									<div class="featured-content">
										<div class="featured-img">
											<img src="assets/images/featured/5.jpg" alt="" />
										</div>
										<div class="featured-info">
											<h4>Wire Transfers</h4>
											<p>Alteration in some form, by implementing wire transfers to all countries.</p>
										</div>
									</div>
								</li>
							
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- featured-area end -->


		
		<!-- faq-area start -->
		<div class="faq-area">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12  wow fadeInUp">
						<div class="section-title text-center">
							<h2>Frequently Asked Questions</h2>
<!--							<p>The majority have suffered alteration in some form, by injected humour, or randomised. by injected humour, or randomised.</p>-->
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 col-xs-12  wow fadeInLeft">
						<div class="faq-wrap">
							<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
								<div class="panel panel-default">
									<div class="panel-heading" id="headingOne">
										<h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
												Which browsers can I use to access your site?
											</a>
										</h4>
									</div>
									<div id="collapseOne" class="panel-collapse collapse in">
										<div class="panel-body">
											<p>We recommend using the latest version of your favorite browser - Internet Explorer, Firefox, Safari, Opera, or Chrome. Internet Explorer Browser versions below 9 do not support established web standards, and may have difficulty in displaying content as intended. If you are using an older version, click any of the links below to download a free browser upgrade:
                                       <br>
                                            Firefox
                                            Internet Explorer
                                            Safari
                                            Chrome
                                            Opera.</p>
                                            
                                                    </div>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading"   id="headingTwo">
										<h4 class="panel-title">
											<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
												Is my information secure over the Internet?
											</a>
										</h4>
									</div>
									<div id="collapseTwo" class="panel-collapse collapse">
										<div class="panel-body">
											<p>United Overseas corperation bank retains privacy on our site by using a secure environment. We maintain electronic and procedural safeguards that comply with federal standards to guard your personal information. See our Security Information page or view our Privacy Policy for additional information.</p>
										</div>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading"   id="headingThree">
										<h4 class="panel-title">
											<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
												
Why is United Overseas Corporation Bank merging with Altier credit union?
											</a>
										</h4>
									</div>
									<div id="collapseThree" class="panel-collapse collapse">
										<div class="panel-body">
											<p>Since United Overseas Corporation Bank entry into the Arizona market in 2016, we have been looking for a potential partner in the area. Altier had also been considering a possible merger. After contacting Altier in June of last year, we found each other's culture and business strategies to be a good match. After several months of exploration by representatives of both credit unions, the respective boards of directors decided that it would be in the be interest of both groups of members to merge. The merger will give United Overseas Corporation Bank members five locations in Arizona, and Altier members will gain access to United Overseas Corporation Bank world-class variety of products and services. 
 </p>
										</div>
									</div>
								</div>
								<div class="panel panel-default">
									<div class="panel-heading"   id="headingfour">
										<h4 class="panel-title">
											<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
												How do I contact United Overseas Corporation Bank for technical assistance?
											</a>
										</h4>
									</div>
									<div id="collapsefour" class="panel-collapse collapse">
										<div class="panel-body">
											<p>If you are experiencing technical difficulties while banking through Online Banking or visiting our web site, please feel free to contact us at 1-800-999-3961. Our e-Support department is available Monday – Friday 8:00 a.m. to 7:00 p.m. and Saturday 8:00 a.m. to 5:00 p.m., closed Sunday.</p>
										</div>
									</div>
								</div>
							
								
							</div>
						</div>
					</div>
			
				</div>
			</div>
		</div>
		<!-- faq-area end -->

		

		<!-- praller-area start -->
		<section class="prallex-area black-opacity parallax ptb-180 wow fadeInUp"  data-speed="3" data-bg-image="assets/images/bg/3.jpg">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-xs-12">
						<div class="prallex-wrap text-center">
							<h2><i class="fa fa-quote-left"></i>Keep away from people who try to belittle your ambitions. Small peol always do that.<i class="fa fa-quote-right"></i></h2>
							<span><i class="fa fa-long-arrow-left"></i>  Brayden Shar <i class="fa fa-long-arrow-right"></i></span>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- praller-area end -->

		


    <?php
	require_once 'files/footers.php';
	
?>
