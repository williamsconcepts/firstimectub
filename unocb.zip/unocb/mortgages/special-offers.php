<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="mort_img">
		<img src="../images/banner-MortgageSpecialRate.jpg">
	</div>
	<h2 class="header">Special Offers</h2>

		


		<div id="special_offers" class="">

			<div class="special_offers_wrap left_float">
				<h4>BMO Smart Fixed Mortgage</h4>
				<div class="each_special_offers left_float">
					<h1>2.890%</h1>
					<hr>
					<h1>2.91% APR</h1>
					<h4>5-years</h4>
					<p>(fixed rate closed mortgage)</p>
				</div>

				<div class="each_special_offers left_float">
					<h1>3.940%</h1>
					<hr>
					<h1>3.95% APR</h1>
					<h4>10-years</h4>
					<p>(fixed rate closed mortgage)</p>
				</div>

				<div class="clear"></div>

				<p class="top_margin">With an amortization of 25 years or less, you’ll pay your mortgage off faster and save on interest.</p>

			</div>

			<div class="special_offers_wrap left_float">

				<div class="each_special_offers left_float">
					<h4>Celebrate your first home with a cash reward</h4>
					<p class="top_margin">Celebrate becoming a first-time home buyer with a little extra cash from BMO. Get up to $1,000 in cash when you get a BMO mortgage requiring mortgage default insurance and use your chequing account to make your mortgage payments</p>
				</div>

				<div class="each_special_offers left_float">
					<img src="../images/circle-image.jpg">
				</div>

				<div class="clear"></div>

			</div>

			<div class="clear"></div>


		</div>


	<div id="smart_fixed_sec" class="section_half2 special_offer">

		<div class="section left_float" id="section_wt_border">

			<div class="inner_section img right_float">
				<img src="../images/circle-switch-offers.jpg">
			</div>

			<div class="clear"></div>
		</div>

		<div class="section left_float" id="">

			<div class="inner_section left_float">
				<h4>Move your mortgage to BMO. Earn up to $1,000</h4>
				<p>Switch your existing mortgage to BMO, use a BMO Chequing Account to make your</p>
				<p>mortgage payments, and earn up to $1,000. Roof repairs, a weekend away,</p>
				<p>savings for a rainy day – we’re sure the money will come in handy!</p>
			</div>
		</div>

		<div class="clear"></div>
	</div>


	<div id="why_us">

		<h2 class="header">Why choose a mortgage with BMO?</h2>

		<div class="each_why_us left_float">
			<img src="../images/why_us_img1.JPG">
			<h4>Personalized, expert advice</h4>
			<p>A BMO Mortgage Specialist is your guide through the mortgage process. Working with your finances and goals, they’ll provide you with a customized home financing plan.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/why_us_img2.JPG">
			<h4>Dependable pre-approval</h4>
			<p>House hunt with confidence. Your pre-approval is valid for 90 days. Count on it to make a quick offer when you find the perfect home.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/why_us_img3.JPG">
			<h4>Competitive rates</h4>
			<p>Whether you need a short- or long-term mortgage, open or closed, variable or fixed, we offer competitive mortgage rates to match your needs and budget.</p>
		</div>

		<div class="clear"></div>

	</div>


	
</div>





<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>