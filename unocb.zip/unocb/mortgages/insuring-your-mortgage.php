<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="mort_img">
		<img src="../images/mortgages-renew.jpg">
	</div>
	<h2 class="header">Insuring your Mortgage</h2>

		


		<div id="top_rate_section_half2" class="section_half2">

			<div id="top_rate" class="top_header">
				<h2 class="header">Mortgage Balance Protection balance</h2>
				<p>Designed to pay off or reduce your mortgage </p>
				<p>in the event of death or a covered critical illness.</p>
			</div>

			<div class="section left_float" id="section_wt_border">
				<h4>Life Insurance</h4>
				<p>Pays off or reduces your mortgage if the unexpected occurs, giving you and your family some security.</p>

				<h4>Eligibility</h4>
				<p>You can apply for Life Insurance when you first apply for a mortgage or anytime after if you are:</p>
				<ul>
	                <li>The borrower or co-borrower on a mortgage </li>
	                <li>A Canadian resident between 18 and 65 years</li>
	            </ul>

	            <h4>Benefits</h4>
	            <p>Pays a percentage of your unpaid mortgage balance if you pass away. This insurance can cover 50% or 100% of the balance up to the maximum insurable limit of $600,000. Sun Life pays insurance claims directly to United Overseas Corporation Bank.</p>

	            <h4>Underwriting</h4>
	            <p>You're automatically approved if you meet eligibility requirements and the amount of requested coverage is $50,000 or less. If you are applying for coverage greater than $50,000, you'll need to answer a health status question.</p>
	            <ul>
                    <li>If you answer "No," you're approved</li>
                    <li>If you answer "Yes," Sun Life will do a confidential interview to see if you're eligible</li>
                </ul>

                <h4>Terms &amp; Conditions</h4>
                <p>The complete terms and conditions, including exclusions and limitations of this coverage are outlined in the Certificate of Insurance that you will receive when you apply.</p>

                <h4>Premiums</h4>
                <p>Your insurance premium, plus any applicable provincial sales tax is charged in arrears and collected by United Overseas Corporation Bank with your mortgage payment. Life Insurance premiums are based on your age when you apply and do not change for the duration of your coverage.</p>

                <h4>Cancellation</h4>
                <p>You can cancel your insurance at any time. If you cancel within the first thirty (30) days of being covered, any premiums you have paid will be refunded.</p>
			</div>






			<div class="section left_float" id="">
				<h2>Critical Illness Insurance</h2>
				<p>Pays off or lowers your mortgage if you become very ill or need surgery covered by this plan.</p>


				<h4>Eligibility</h4>
				<p>You can apply for Critical Illness Insurance when you first apply for a mortgage or anytime after if you are:</p>
				<ul>
                    <li>The borrower or co-borrower on a Mortgage</li>
                    <li>A Canadian resident between 18 and 55 years old</li>
                    <li>Have also applied for Life Insurance</li>
                </ul>

                <h4>Benefits</h4>
                <p>Covers 50% or 100% of the mortgage balance up to $450,000. The amount of Critical Illness insurance coverage cannot exceed the amount of your life insurance coverage. The covered illnesses are:</p>
                <ul>
                    <li>Heart attack</li>
                    <li>Stroke</li>
                    <li>Cancer</li>
                    <li>Coronary artery bypass surgery</li>
                </ul>

                <p>Sun Life will pay United Overseas Corporation Bank 50% of the unpaid balance of your mortgage—if you select 50% coverage. Only one Critical Insurance benefit is paid per insured. For more details, see the Certificate of Insurance section "What Happens if a Balance Protection benefit doesn't fully pay out your Mortgage."</p>

                <h4>Underwriting</h4>
                <p>You're automatically approved if you meet eligibility requirements and the amount of requested coverage is $50,000 or less. If you are applying for coverage greater than $50,000 you'll need to answer one health status question.</p>
                <ul>
                    <li>If you answer "No," you're approved</li>
                    <li>If you answer "Yes," Sun Life will do a confidential interview to see if you're eligible</li>
                </ul>

                <h4>Terms &amp; Conditions</h4>
                <p>The complete terms and conditions, including exclusions and limitations of this coverage are outlined in the Certificate of Insurance that you will receive when you apply.</p>

                <h4>Premiums</h4>
                <p>Your insurance premium, plus any applicable provincial sales tax is charged in arrears and collected by United Overseas Corporation Bank with your mortgage payment. Critical Illness Insurance premiums are based on your age when you apply and do not change for the duration of your coverage.</p>

                <h4>Cancellation</h4>
                <p>You can cancel your insurance at any time. If you cancel within the first thirty (30) days of being covered, any premiums you have paid will be refunded.</p>

			</div>

			<div class="clear"></div>



			<div id="top_rate" class="top_header">
				<h2 class="header">Mortgage Payment Protection</h2>
				<p>Designed to pay or reduce your regular mortgage</p>
				<p>payments in the event of disability or job loss.</p>
			</div>


			<div class="section left_float" id="section_wt_border">
				<h4>Disability Insurance</h4>
				<p>Pays or reduces your mortgage payment should you become disabled, so you can focus on recovery.</p>

				<h4>Eligibility</h4>
				<p>You can apply for Disability Insurance when you first apply for a mortgage or anytime after if you are:</p>
				<ul>
                    <li>The borrower or co-borrower on a Mortgage</li>
                    <li>A Canadian resident between 18 and 65 years</li>
                    <li>Actively working*</li>
                </ul>

	            <h4>Benefits</h4>
	            <p>Covers 50% or 100% of the monthly payment up to a maximum insurable limit of $3000. Disability benefits are paid for up to 24 months per disability. There is a 30–day qualifying period during which time no benefits will be paid.</p>

	            <h4>Underwriting</h4>
	            <p>You're automatically approved if you meet eligibility requirements and the amount of requested coverage is $50,000 or less. If you are applying for coverage greater than $50,000, you'll need to answer one health status question.</p>
	            <ul>
                    <li>If you answer "No," you're approved</li>
                    <li>If you answer "Yes," Sun Life will do a confidential interview to see if you're eligible</li>
                </ul>

                <h4>Terms &amp; Conditions</h4>
                <p>The complete terms and conditions, including exclusions and limitations of this coverage are outlined in the Certificate of Insurance that you will receive when you apply.</p>

                <h4>Premiums</h4>
                <p>Your insurance premium, plus any applicable provincial sales tax is charged in arrears and collected by United Overseas Corporation Bank with your mortgage payment. Life Insurance premiums are based on your age when you apply and do not change for the duration of your coverage.</p>

                <h4>Cancellation</h4>
                <p>You can cancel your insurance at any time. If you cancel within the first thirty (30) days of being covered, any premiums you have paid will be refunded.</p>
			</div>






			<div class="section left_float" id="">
				<h2>Job Loss Insurance</h2>
				<p>Pays or reduces your mortgage payment should you become unemployed. Taking care of your biggest liability and safeguarding your credit rating will give you peace of mind while you job search.</p>


				<h4>Eligibility</h4>
				<p>You can apply for Job Loss Insurance when you first apply for a mortgage or anytime after if you:</p>
				<ul>
                    <li>Are the borrower or co-borrower on a Mortgage</li>
                    <li>Are a Canadian resident between 18 and 55 years old</li>
                    <li>Have applied for Disability Insurance</li>
                    <li>Have been continuously employed for 6 months with the same employer and are eligible to receive Employment Insurance benefits</li>
                </ul>

                <p>You are not eligible to enroll if</p>

                <ul>
                    <li>You are self-employed, an independent contractor or working for a family business or a business in which you have a controlling interest</li>
                    <li>You have been advised of your pending unemployment</li>
                </ul>

                <h4>Benefits</h4>
                <p>Covers 50% or 100% of your monthly payment up to the maximum insurable limit of $3,000 per month. Sun Life pays insurance claims directly to United Overseas Corporation Bank.</p>
                <ul>
                    <li>The amount of Job Loss coverage cannot exceed the amount of Disability Insurance coverage</li>
                </ul>

                <p>You get Job Loss Benefits for the same period you receive Employment Insurance Benefits, up to a maximum of 6 months per job loss. There is a qualifying period of 60 days when you cannot receive benefits.</p>

                <h4>Underwriting</h4>
                <p>There are no health status questions to answer for Job Loss. You are automatically approved if you meet the eligibility criteria.</p>


                <h4>Terms &amp; Conditions</h4>
                <p>The complete terms and conditions, including exclusions and limitations of this coverage are outlined in the Certificate of Insurance that you will receive when you apply.</p>

                <h4>Premiums</h4>
                <p>Your insurance premium, plus any applicable provincial sales tax is charged in arrears and collected by United Overseas Corporation Bank with your mortgage payment. Job Loss Insurance premiums are based on your age when you apply and do not change for the duration of your coverage.</p>

                <h4>Cancellation</h4>
                <p>You can cancel your insurance at any time. If you cancel within the first thirty (30) days of being covered, any premiums you have paid will be refunded.</p>

			</div>

			<div class="clear"></div





		</div>





	<div id="explore">

		<h2 class="header">Ready to explore options?</h2>

		
			<div class="each_explore left_float">
				<h>Start Pre-approval</h4>
				<p>We'll respond within 24 hours of receiving your request to start your online mortgage pre-approval.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Make an Appointment</h4>
				<p>Choose the date, time and branch to book an appointment that works with your schedule.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Apply Online</h4>
				<p>Complete your application online and we will contact you within two business days to follow-up.</p>
			</div>

		<div class="clear"></div>
	</div>

</div>





<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>