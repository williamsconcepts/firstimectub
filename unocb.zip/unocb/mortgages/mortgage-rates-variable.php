<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="mort_img">
		<img src="../images/banner-MortgageSpecialRate.jpg">
	</div>
	<h2 class="header">Variable Rates</h2>

		


		<div id="top_rate_section_half2" class="section_half2">

			<div id="top_rate" class="top_header">
				<h2 class="header">Variable Rate</h2>
				<p>While the interest rate changes with United Overseas Corporation Bank's prime rate your mortgage payments remain the same throughout the</p>
				<p>term . The amount applied to the principal versus interest may change with fluctuations in United Overseas Corporation Bank's prime rate. </p>
				<p>Your amortization period (number of years to repay the mortgage) may vary and be longer if rates have risen or </p>
				<p>be shorter if rates have fallen since the start of the term.</p>
			</div>

			<div class="section full_section left_float" id="section_wt_border">
				<h4>Residential Variable Rate Mortgages</h4>

				<table>
	              <thead>
	                <tr class="tr-first">
	                  <td>Rate for residential mortgages</td>
	                  <td class="">Posted rates</td>
	                  <td>Special rates</td>
	                  <td>APR</td>
	                </tr>
	              </thead>

	              <tbody>
	                <tr>
	                	<td>3 year (open mortgage)</td>
	                  	<td class="">3.900%</td>
	                  	<td></td>
	                  	<td></td>
	                </tr>
	                <tr>
	                    <td>5 year (closed mortgage)</td>
	                    <td class="">2.850%</td>
	                    <td>2.60%</td>
	                  	<td>2.62%</td>
	                </tr>
	              </tbody>
	            </table>



			</div>

			<div class="clear"></div>
		</div>





	<div id="explore">

		<h2 class="header">Ready to explore options?</h2>

		
			<div class="each_explore left_float">
				<h>Start Pre-approval</h4>
				<p>We'll respond within 24 hours of receiving your request to start your online mortgage pre-approval.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Make an Appointment</h4>
				<p>Choose the date, time and branch to book an appointment that works with your schedule.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Apply Online</h4>
				<p>Complete your application online and we will contact you within two business days to follow-up.</p>
			</div>

		<div class="clear"></div>
	</div>

</div>





<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>