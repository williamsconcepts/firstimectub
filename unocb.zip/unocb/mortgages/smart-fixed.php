<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="mort_img">
		<img src="../images/banner-MortgageSpecialRate.jpg">
	</div>
	<h2 class="header">Smart Fixed Mortgage</h2>

		


		<div id="smart_fixed" class="">

			<div class="each_smart_fixed left_float">
				<h1>2.890%</h1>
				<hr>
				<h1>2.91% APR</h1>
				<h4>5-years</h4>
				<p>(fixed rate closed mortgage)</p>
			</div>

			<div class="each_smart_fixed left_float">
				<h1>3.940%</h1>
				<hr>
				<h1>3.95% APR</h1>
				<h4>10-years</h4>
				<p>(fixed rate closed mortgage)</p>
			</div>

			<div class="clear"></div>


			<ul>
              <li>Get a great 5 or 10-year rate which won’t rise during the term.</li>
              <li>Increase your payments by 10% and make a lump sum payment of 10% each year to get to the finish line sooner.</li>
              <li>Pay your mortgage off faster and save on interest with an amortization of 25 years or less.</li>
              <li>Available for new United Overseas Corporation Bank owner-occupied mortgages only. Refinances are not eligible.</li>
              <li>At least one borrower (or guarantor) must have a minimum credit score of 600.</li>
              <li>Your Gross Debt Service Ratio must be less than 39% and your Total Debt Service Ratio cannot be higher than 44%.</li>
            </ul>

		</div>


	<div id="smart_fixed_sec" class="section_half2">

		<h2 class="header">Special Offers</h2>
		<h4>Are You:</h4>

		<div class="section left_float" id="section_wt_border">
			<div class="inner_section left_float">
				<img src="../images/circle-young-couple-dancing.jpg">
			</div>

			<div class="inner_section left_float">
				<h2>Buying your first home?</h2>
				<p>Celebrate with up to $1,000 when you get a United Overseas Corporation Bank mortgage</p>
			</div>

			<div class="clear"></div>
		</div>

		<div class="section left_float" id="">
			<div class="inner_section left_float">
				<img src="../images/circle-switch-offers.jpg">
			</div>

			<div class="inner_section left_float">
				<h2>Renewing your mortgage?</h2>
				<p>Get up to $1,000 when you switch your mortgage to United Overseas Corporation Bank</p>
			</div>
		</div>

		<div class="clear"></div>
	</div>


	<div id="smart_single_section">

		<h2 class="header">Popular mortgage rates</h2>
		<p>Take a look at our range of popular mortgage rates and options, and find one that works for you.</p>


		<table>
	        <thead>
		        <tr>
		            <th>Term</th>
		        	 <th>Type</th>
		            <th>Interest Rate</th>
		            <th>APR</th>
		        </tr>
	        </thead>

	        <tbody>
	          <tr>
	            <td>2</td>
	            <td>Fixed/Closed</td>
	            <td>3.190%</td>
	            <td></td>
	          </tr>
	          <tr>
	            <td>3</td>
	            <td>Fixed/Closed</td>
	            <td>3.590%</td>
	            <td></td>
	          </tr>
	          <tr>
	            <td>3</td>
	            <td>Variable/Open</td>
	            <td>3.900%</td>
	            <td></td>
	          </tr>
	          <tr>
	            <td>5</td>
	            <td>Fixed/Closed</td>
	            <td>2.890<span>%</td>
	            <td>2.91%</tr>
	          <tr>
	            <td>5</td>
	            <td>Variable/Closed</td>
	            <td>2.850%</td>
	            <td></td>
	          </tr>
	        </tbody>
      </table>


	</div>


	
</div>





<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>