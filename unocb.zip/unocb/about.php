
    <?php
	require_once 'files/head_section.php';
	require_once 'files/navigation.php';
?>


        <!-- breadcumb-area start -->
        <div class="breadcumb-area black-opacity bg-img-3">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcumb-wrap">
                            <h2>About Us</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcumb-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li>/</li>
                                <li>About us</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcumb-area end -->

        <!-- about-area start -->
       <section class="about-area ptb-140">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-xs-12 wow fadeInLeft">
						<div class="about-img black-opacity">
							<img src="assets/images/about.jpg" alt="" />
						</div>
					</div>
					<div class="col-md-6 col-xs-12 wow fadeInRight">
						<div class="about-wrap">
							<h2>who we are</h2>
							<p>Feel at home with a mortgage that fits your needs.
Whether you're buying a new home or refinancing, get guidance on calculating the
costs, choosing the right loan, and understanding the next steps.</p>
							<p>We help you grow, protect and transition your wealth with award-winning
wealth management services like investment management and wealthplanning.</p>
							<ul>
								<li>Online Banking</li>
								<li>Loan Requests.</li>
								<li>Mortgages</li>
								<li>Open an Account with us</li>
								<li>Swift and reliable</li>
								<li>Secure Transfer Interface</li>
								<li>Western union and moneygram accepted.</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!-- about-area end -->

        <!-- .service-area start -->
       <section class="service-area pb-140">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12 wow fadeInUp">
						<div class="section-title text-center">
							<h2>Our Special Service</h2>
							<p>Transactions are processed in a timely manner,
Incoming wire transfers are immediately credited to your account.</p>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".1s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/1.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>Performance</h3>
								<p>Annualized return for United Overseas Corporation Bank® Balanced Portfolio Series A: since inception 7.65%; 1-year 4.6%; 3-year 7.61%. Series A as at October 12th, 2016.</p>
								<a href="mortgages/mortgage-rates-fixed.php">Read More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".2s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/2.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>Wire Transfers</h3>
                                <p>How To Send A Wire Transfer</p><br>
<p>To send a wire transfer, either visit an an United Overseas Corporation branch location or call us at 1-800-999-3961.

There is a fee for outgoing wire transfers. For details, please see the Bank to Bank Transfer fees in our Truth-in-Savings Rate and Fee Schedule.</p>

<p>How To Receive A Wire Transfer<br>
To receive a wire transfer, please provide the following information to the business or individual sending the wire.
<br>
Wire Routing and Transit Number: 324377516
Financial Institution Name: United Overseas Corporation Bank® Federal Credit Union
City, State: Ogden, Utah
Your United Overseas Corporation Bank Account Number
Type of Account: Savings, Money Market, Checking, etc.</p>
								<a href="bank-accounts/banking-services.php">Read More</a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12 col wow fadeInUp"  data-wow-delay=".3s">
						<div class="service-wrap">
							<div class="service-img">
								<img src="assets/images/service/3.jpg" alt="" />
							</div>
							<div class="service-content">
								<h3>investments</h3>
								<p>Commissions, trailing commissions, management fees and expenses may be associated with mutual fund investments. Please read the fund facts or prospectus before investing.</p>
								<a href="loans/rrsp-and-investments.php">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
        <!-- .service-area end -->

        <!-- company-details-area start -->
        <div class="company-details-area bg-2">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <div class="company-details-wrap">
                            <h2>Helping Small Businesses just like yours in giving out loans</h2>
                            <p>At Unocb, the financial safety of the membership is our highest priority. We offer best in free security features, including:
<br>
High-grade network traffic encryption
Chip-enabled (EMV) cards
Two-factor authentication
Advanced fraud detection systems
Card Guard® mobile protection
Identity theft recovery services
And more
However, perhaps the best tool we can provide for your protection is education. Below are some links to beneficial government sites, where you can learn about the latest frauds, scams and what to do if you ever become a victim.

Review these alerts regularly to guard against cyberattacks that affect millions every year.</p>
<!--                            <a href="service.html">our service</a>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- company-details-area end -->

       
        <!-- quote-area start -->
        <div class="quote-area bg-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9 col-xs-12">
                        <div class="quote-wrap">
                            <h2>Over 14 years of experience we’ll ensure you get the best guidance.</h2>
                        </div>
                    </div>
                    <div class="col-sm-3 col-xs-12">
                        <div class="quote-wrap text-right">
                            <a href="contact/contact-us.php">Request Quote</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- quote-area end -->

           <?php
	require_once 'files/footers.php';
	
?>