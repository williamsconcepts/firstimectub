<?php
	

	$feedback = "";
	$feedback1 = "";


	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}



	if(isset($_POST['contact_name'])&&
	 	isset($_POST['contact_email'])&&
	 	isset($_POST['contact_message'])&&
	 	isset($_POST['contact_telephone'])){


		if(empty($_POST['contact_name']) ||
			empty($_POST['contact_email']) ||
			empty($_POST['contact_telephone'])){

			$feedback = "Please fill all fields";

		}else{

			$contact_name = sanitize_input($_POST['contact_name']);
			$contact_email = sanitize_input($_POST['contact_email']);
			$contact_telephone = sanitize_input($_POST['contact_telephone']);
			$contact_message = sanitize_input($_POST['contact_message']);

			$body = <<<MAIL
<br><hr><br>
Firstname: $contact_name <br>
Email: $contact_email <br>
Phone: $contact_telephone <br>
Message: $contact_message <br>
MAIL;


	
		$subject = 'Comment received from unocb';
		$recieverEmail = 'info@unocb.com';


		$headers = "From: support@unocb.com\r\n";
		$headers .= "Reply-to: support@unocb.com\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html charset=ISO-8859-1\r\n";

		$sent = mail($recieverEmail, $subject, $body, $headers);


		$feedback1 = "Message sent";

		}


		
	}else{
		$feedback = "";
	}




	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>
	<div class="page_width">

		<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>

			<div id="contact_page" class="">
				<div class="left_float" style="width: 50%;">
					<h3>To contact us, please fill out the form.</h3> 
					<h3>A bank representative will reply you within a short time.</h3><br>
					
					<form action="contact-us.php" method="post">

						<div style="color:#e31930; margin-top:20px;"><?php echo $feedback;?></div>
						<div style="color:#006a4d; margin-top:20px;"><?php echo $feedback1;?></div>

						<label for="contact_name">Enter your name (required)</label>
						<input type="text" name="contact_name" id="contact_name" class="page_inputs">

						<label for="contact_email">Enter your email (required)</label>
						<input type="text" name="contact_email" id="contact_email" class="page_inputs">

						<label for="contact_telephone">Enter your telephone (required)</label>
						<input type="text" name="contact_telephone" id="contact_telephone" class="page_inputs">

						<label for="contact_message">Enter your message</label>
						<textarea name="contact_message" id="contact_message" class="page_inputs"></textarea>
						<input type="submit" id="contact_submit" value="Send">
					</form>
			</div>

			<div id="contact_time" class="left_float" style="width: 50%;">
				<br>
				<div class="each_address left_float" style="width: 50%;">
					<h4 style="">Address</h4>
					<p>United Overseas Corporation Bank,</p>
					<p>Jl KH Mas Mansyur,</p>
					<p> 12-A Wisma Bisnis Indonesia,</p>
					<p>Lt 9 Tanah Aban, Jakarta.</p>
					<br>
				</div>

				<!-- <div class="each_address left_float" style="width: 50%;">
					<h4>UK Address</h4>
					<p>222 224 Breck Road Everton,</p>
					<p>Liverpool L5 6PX, United Kingdom.</p>
					<br>
				</div>

				

				<div class="each_address left_float" style="width: 50%;">
					<h4>Malaysia Address</h4>
					<p>Bangunan Unikeb,</p>
					<p>Selangor 43600, Malaysia.</p>
					<br>
				</div>

				<div class="each_address left_float" style="width: 50%;">
					<h4>South Africa Address</h4>
					<p>St George S Arcade,</p>
					<p>477 Smith Street Durban.</p>
					<br>
				</div>

				<div class="clear"></div>


				<div class="each_address left_float" style="width: 50%;">
					<h4>James H. Herbert, II</h4>
					<p>Chairman/Chief Executive Officer</p>
					<br>
					<h4>Katherine August-deWilde</h4>
					<p>Vice Chair and Board Member</p>
					<br>
					<h4>Thomas J. Barrack Jr.</h4>
					<p>Board Member</p>
					<br>
				</div>

				<div class="each_address left_float" style="width: 50%;">
					<h4>China Address</h4>
					<p>No 72 South Xinhua Street,</p>
					<p>Xicheng Dist, Beijing China.</p>
					<br>
				</div> -->

				<div class="clear"></div>

				<div class="each_address left_float" style="width: 50%;">
					<h4>Contact hours</h4>
					<p>Monday–Friday 8 a.m.–4 p.m</p>
					<p>Email: <a href="mailto:info@unocb.com">info@unocb.com</a></p>
					<br>
				</div>
				

					
				<script>
					function initMap() {
				  			var myLatLng = {lat: 55.632688,  lng: 13.075617};

				  			var map = new google.maps.Map(document.getElementById('map'), {
						    zoom: 17,
						    center: myLatLng
				  			});

				  			var marker = new google.maps.Marker({
						    position: myLatLng,
						    map: map,
						    title: 'Advanced Cargo Delivery and Services.'
				  			});
						}


			   	</script>

			   	<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAEyKaOC9bmZmxLOfqHFwKxoIsT88Nc9cQ&signed_in=true&callback=initMap"></script>


				<div id="map" class="col-s-12 col-m-12 col-11">
					
				</div>
			</div>


			<div class="clear"></div>
		</div>
	</div>





</div>

<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>