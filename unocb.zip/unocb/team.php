
    <?php
	require_once 'files/head_section.php';
	require_once 'files/navigation.php';
?>
        <!-- breadcumb-area start -->
        <div class="breadcumb-area black-opacity bg-img-5">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="breadcumb-wrap">
                            <h2>Our Team</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="breadcumb-menu">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12">
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li>/</li>
                                <li>Team</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- breadcumb-area end -->

        <!-- team-area start -->
		<section class="team-area ptb-100">
			<div class="container">
				<div class="row">
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap mb-30">
							<div class="team-img">
								<img src="assets/images/team/1.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Alex Jeson</h3>
									<p>Marketing</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap mb-30">
							<div class="team-img">
								<img src="assets/images/team/2.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Connor Charles</h3>
									<p>Founder</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap mb-30">
							<div class="team-img">
								<img src="assets/images/team/3.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Robert Kyle</h3>
									<p>Account Auditors</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap mb-30">
							<div class="team-img">
								<img src="assets/images/team/4.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Brayden Shar</h3>
									<p>Loan Finance</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
                    <div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap">
							<div class="team-img">
								<img src="assets/images/team/5.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Jon Smit</h3>
									<p>Marketing</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap">
							<div class="team-img">
								<img src="assets/images/team/6.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Alak Jandar</h3>
									<p>Mortgage staff</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap">
							<div class="team-img">
								<img src="assets/images/team/7.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Kyle Jon</h3>
									<p>co-insurance staff</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-3 col-lg-3 col-sm-6 col-xs-12 col">
						<div class="team-wrap">
							<div class="team-img">
								<img src="assets/images/team/8.jpg" alt="" />
							</div>
							<div class="team-content">
								<div class="team-info">
									<h3>Shar Brayden</h3>
									<p>credit card activator</p>
									<ul>
										<li><a href="#"><i class="fa fa-facebook"></i></a></li>
										<li><a href="#"><i class="fa fa-twitter"></i></a></li>
										<li><a href="#"><i class="fa fa-linkedin"></i></a></li>
										<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- team-area end -->

        <!-- quote-area start -->
        <div class="quote-area bg-1">
            <div class="container">
                <div class="row">
                    <div class="col-sm-9 col-xs-12">
                        <div class="quote-wrap">
                            <h2>Over 14 years of experience we’ll ensure you get the best guidance.</h2>
                        </div>
                    </div>
                    <div class="col-sm-3 col-xs-12">
                        <div class="quote-wrap text-right">
                            <a href="contact/contact-us.php">Request Quote</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- quote-area end -->

          <?php
	require_once 'files/footers.php';
	
?>