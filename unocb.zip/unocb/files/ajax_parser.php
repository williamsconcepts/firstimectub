<?php
session_start();
	require_once 'connect.inc.php';

	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}


if(isset($_POST['sign_in_email']) && isset($_POST['sign_in_password'])){

	$sign_in_email = sanitize_input($_POST['sign_in_email']);
	$sign_in_password = sanitize_input($_POST['sign_in_password']);



	$query_sign_in = "SELECT * FROM `acc_customers` WHERE `acc_username`='$sign_in_email' AND `acc_password`='$sign_in_password'";
	$query_sign_in_run = mysql_query($query_sign_in);

	if(mysql_num_rows($query_sign_in_run) == 1){

			$_SESSION['client_username'] = $sign_in_email;
			$_SESSION['client_password'] = $sign_in_password;
			echo "Successfully signed in";
			return false;
	}else{
		echo "Invalid username/password";
		return false;
	}
}

?>