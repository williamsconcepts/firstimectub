<body>
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- preloder-wrap -->
        <div id="cssLoader3" class="preloder-wrap">
            <div class="loader">
                <div class="child-common child4"></div>
                <div class="child-common child3"></div>
                <div class="child-common child2"></div>
                <div class="child-common child1"></div>
            </div>
        </div>
        <!-- preloder-wrap -->
        <!-- search-area -->
        <div class="search-area">
            <span class="closs-btn">Close</span>
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="search-form">
                            <form action="#">
                                <input type="text" name="search" placeholder="Search Here">
                                <button type="button" name="button" class="btn-style">Search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- search-area -->
		<!-- heared area start -->
		<header class="header-area">
            <div class="header-top bg-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6 col-sm-8 col-xs-12">
                            <div class="header-top-left">
                                <p>We give you the best and secure transcations.</p>
                            </div>
                        </div>
                        <div class="col-md-6 col-sm-4 col-xs-12">
                            <div class="header-top-right text-right">
                                <ul>
                                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-middle bg-2">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3 hidden-sm hidden-xs">
    						<div class="logo">
    							<h1><a href="index.php"><img src="images/uno.png"></a></h1>
    						</div>
    					</div>
                        <div class="col-md-9 col-xs-12">
                            <div class="header-middle-right">
                                <ul>
                                    <li>
                                        <div class="contact-icon">
                                            <i class="fa fa-clock-o"></i>
                                        </div>
                                        <div class="contact-info">
                                            <p>MON - SAT (9AM - 5PM)</p>
                                            <span>Sunday colsed</span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="contact-icon">
                                            <i class="fa fa-envelope"></i>
                                        </div>
                                        <div class="contact-info">
                                            <p>MAIL US</p>
                                            <span><a href="mailto:info@unocb.com">info@unocb.com</a></span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="contact-icon">
                                            <i class="fa fa-phone"></i>
                                        </div>
                                        <div class="contact-info">
                                            <p>PHONE US</p>
                                            <span> (+1) 1144-1254</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<div class="header-bottom"  id="sticky-header">
                <div class="container">
    				<div class="row">
                        <div class="hidden-md hidden-lg col-sm-8 col-xs-6">
    						<div class="logo">
    							<h1><a href="index.php"><img src="images/uno.png"></a></h1>
    						</div>
    					</div>
    					<div class="col-md-11 hidden-sm hidden-xs">
    						<div class="mainmenu">
    							<ul id="navigation">
    								<li class="active"><a href="index.php">Home </a>
    									
    								</li>
    								
    								<li><a href="service.html">Online Banking <i class="fa fa-angle-down"></i></a>
    									<ul class="submenu">
    										<li><a href="client-area/creator.php">personal account</a></li>
    										<li><a href="client-area/online-account-opening.php">open an account with us</a></li>
    										<li><a href="client-area/creator.php">business account</a></li>
    										
    									</ul>
    								</li>
                                    
                                    <li><a href="about.php">About </a>
    									
                                    </li>
                                    
                                    	
                                    
    								<li><a href="team.php">team</a>
                                        
                                        <li><a href="#">Bank Accounts<i class="fa fa-angle-down"></i></a>
    									<ul class="submenu">
    								<li><a href="bank-accounts/banking-services.php">banking-services</a></li>
    								<li><a href="bank-accounts/compare-bank-plan.php">compare-bank-plan</a></li>
    								<li><a href="bank-accounts/savings.php">savings</a></li>
    								<li><a href="bank-accounts/why-us.php">why-us</a></li>
    								
    										
    										
    									</ul>
    								</li>
                                        
                                <li><a href="#">Services <i class="fa fa-angle-down"></i></a>
                                <ul class="megamenu">
                                    <li>
                                        <a class="mega-title" href="#">Mortgages</a>
                                        <ul>
                                            <li><a href="mortgages/insuring-your-mortgage.php">insuring-your-mortgage</a></li>
                                            <li><a href="mortgages/mortgage-rates-fixed.php">mortgage-rates-fixed</a></li>
                                            <li><a href="mortgages/mortgage-rates-variable.php">mortgage-rates-variable</a></li>
                                            <li><a href="mortgages/smart-fixed.php">smart-fixed</a></li>
                                            <li><a href="mortgages/special-offers.php">special-offers</a></li>
                                        </ul>
                                    </li>
                                   

                                    <li>
                                        <a class="mega-title"  href="#">Loans</a>
                                        <ul>
                                            <li><a href="loans/car-or-larger-purchase.php">car-or-larger-purchase</a></li>
                                            <li><a href="loans/debt-consolidation.php">debt-consolidation</a></li>
                                            <li><a href="loans/home-and-family.php">home-and-family</a></li>
                                            <li><a href="loans/rrsp-and-investments.php">rrsp-and-investments</a></li>
                                            <li><a href="loans/student-life-and-tuition.php">student-life-and-tuition</a></li>
                                            <li><a href="loans/travel-or-wedding.php">travel-or-wedding</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="mega-title"  href="#">Credit cards</a>
                                        <ul>
                                            <li><a href="credit-cards/air-miles-credit-cards.php">air-miles-credit-cards</a></li>
                                            <li><a href="credit-cards/bmo-rewards-travel-credit-cards.php">bmo-rewards-travel-credit-cards</a></li>
                                            <li><a href="credit-cards/cashback-credit-cards.php">cashback-credit-cards</a></li>
                                            <li><a href="credit-cards/no-annual-fee-credit-cards.php">no-annual-fee-credit-cards</a></li>
                                            <li><a href="credit-cards/premium-credit-cards.php">premium-credit-cards</a></li>
                                            <li><a href="credit-cards/special-offers-credit-cards.php">special-offers-credit-cards</a></li>
                                            
                                        </ul>
                                    </li>
                                </ul>
                            </li>

    								
    								<li><a href="contact/contact-us.php">Contact Us</a></li>
    							
    							</ul>
    						</div>
    					</div>
    					<div class="col-md-1 col-sm-2 col-xs-3">
    						<div class="search-wrap text-right">
    							<ul>
    								<li>
    									<a href="javascript:void(0);">
    										<i class="fa fa-search"></i>
    									</a>
    								</li>
    							</ul>
    						</div>
    					</div>
    					<div class="col-sm-2 clear col-xs-3 hidden-md hidden-lg">
    						<div class="responsive-menu-wrap floatright"></div>
    					</div>
    				</div>
    			</div>
			</div>
		</header>
		<!-- heared area end -->