<?php
session_start();

	$online_id = "";
	$passcode = "";
	$feedback_text = "";

	require_once 'connect.inc.php';
	//require_once 'textlocal.class.php';

	if (isset($_SESSION['online_id_session']) && isset($_SESSION['passcode_session'])) {
		$online_id = $_SESSION['online_id_session'];
		$passcode = $_SESSION['passcode_session'];
	}

	$timestamp = time();
	$time= @date('H:i:s', $timestamp -(60*60));
	$date = @date('d-m-Y', $timestamp - (60*60));
	$date_time = $date." ".$time;


	if ($online_id != "" && $passcode != "") {

		$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
		$query_run = mysql_query($query);

		if (mysql_num_rows($query_run)==1) {

			$query_row = mysql_fetch_assoc($query_run);
			$firstname = $query_row['firstname'];
			$middlename = $query_row['middlename'];
			$lastname = $query_row['lastname'];
			$phone1 = $query_row['phone1'];
			$email = $query_row['email'];
			$balance = $query_row['balance'];


			
			$balance = str_replace(",", "" ,$balance);
			$balance = str_replace("$", "" ,$balance);

			$int_transfer_acc_no = $_POST['int_transfer_acc_no'];

			$int_transfer_amount = $_POST['int_transfer_amount'];
			$int_transfer_amount_sanitized = str_replace(",", "" ,$int_transfer_amount);
			$int_transfer_amount_sanitized = str_replace("$", "" ,$int_transfer_amount_sanitized);

			if(!is_numeric($int_transfer_amount_sanitized)){
				echo "Please enter correct amount value.Eg $5,045.91";
				return false;
			}

			$transfer_balance = $balance - $int_transfer_amount_sanitized;


			if($transfer_balance < 0){
				echo "Amount too large. Please try a lesser amount.";
				return false;
			}

			$query_update = "UPDATE `boa_acc_clients` SET 

			`transfer_acc_no`= '".mysql_real_escape_string($int_transfer_acc_no)."',
			`transfer_amount`='".mysql_real_escape_string($int_transfer_amount)."' 

			WHERE `online_id`='$online_id' && `passcode`='$passcode'";

			$query_update_run = mysql_query($query_update);



			


			$body = <<<MAIL
<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%;text-align:right;">
<h4 style="margin-bottom:15px;">Transaction Notification</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname $middlename $lastname, </p>
<h4 style="margin-bottom:10px;">United Overseas Corporation Bank Transaction Alert</h4>

<p>Hello $firstname $middlename $lastname,  you are transfering the sum of $int_transfer_amount to $int_transfer_acc_no. To complete this transaction please enter you Transfer Authorization Code.</p>

<h4>Thank you for banking with United Overseas Corporation Bank</h4>

<p>Best Regards,</p>
<p style="padding-bottom:40px; border-bottom:1px solid #222;">United Overseas Corporation Bank team</p>

</div>

<div>
<p  style="border-top:1px solid #222; padding-top: 40px;">This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>
MAIL;

	
		$subject = 'Transfer notification';


		$headers = "From: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Return-Path: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

		$sent = mail($email, $subject, $body, $headers, '-fsupport@unocb.com');

		
			
			// Message details
			$text_message = "you are transfering the sum of $int_transfer_amount to the account number $int_transfer_acc_no. To complete this transaction please enter your Transfer Authorization Code.";
			$post_data=array(
			'sub_account'=>'3503_unocb',
			'sub_account_pass'=>'kompany',
			'action'=>'send_sms',
			'route'=>'1',
			'sender_id'=>'Unocb',
			'recipients'=>$phone1,
			'message'=>"Hello $firstname, $text_message"
			);
			
			$api_url='http://cheapglobalsms.com/api_v1';

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $api_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			
			$response = curl_exec($ch);
			$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($response_code != 200)$response=curl_error($ch);
			curl_close($ch);

			if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
			else
			{
				$json=@json_decode($response,true);
				
				if($json===null)$msg="INVALID RESPONSE: $response"; 
				elseif(!empty($json['error']))$msg=$json['error'];
				else
				{
					$msg="SMS sent to ".$json['total']." recipient(s).";
					$sms_batch_id=$json['batch_id'];
				}
			}
			
			$feedback_text = $msg;

			 echo "Transfer in progress";
		}else {
	
		}

	}else {
	
}

?>