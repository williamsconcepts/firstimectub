<?php
ob_start( );
session_start();

	if(isset($_SESSION['online_id_session']) && isset($_SESSION['passcode_session'])){

		setcookie("is_signed_in", "", time() - 3600, "/");
		setcookie("keep_me_signed_in", "", time() - 3600, "/");

		if (file_exists("../client-area/".$_SESSION["account_page"])) {
			unlink("../client-area/".$_SESSION["account_page"]);
			unset($_SESSION["account_page"]);
		}

		if(session_destroy()){		
			header('location: ../index.php');
		}else{
			header('location: ../index.php');
		}
		

	}else {

	if(isset($_COOKIE['is_signed_in'])){

		setcookie("is_signed_in", "", time() - 3600, "/");
		setcookie("keep_me_signed_in", "", time() - 3600, "/");
		header('location: ../index.php');
	}else{
		header('location: ../index.php');
	}
	
}
	

?>