<?php
session_start();

	$sign_in_email = "";
	$sign_in_password = "";
	$transfered = "";
	$tranfer_completed = "";

	require_once 'connect.inc.php';
	

	if (isset($_SESSION['online_id_session']) && isset($_SESSION['passcode_session'])) {
		$online_id = $_SESSION['online_id_session'];
		$passcode = $_SESSION['passcode_session'];
	}

	$loc_amount = $_POST['loc_amount'];
	$loc_acc = $_POST['loc_acc'];
	$loc_bank = $_POST['loc_bank'];

	$timestamp = time();
	$time= @date('H:i:s', $timestamp -(60*60));
	$date = @date('d-m-Y', $timestamp - (60*60));
	$date_time = $date." ".$time;

	$transaction_type = "Local transfer";



		$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
		$query_run = mysql_query($query);

	if (mysql_num_rows($query_run)==1) {

		$query_row = mysql_fetch_assoc($query_run);
		$balance_check = $query_row['balance'];

		$balance_check = str_replace("," ,"" , $balance_check);
		$balance_check = str_replace("$" ,"" , $balance_check);

		$loc_amount_sanitized = str_replace("," ,"" , $loc_amount);
		$loc_amount_sanitized = str_replace("$" ,"" , $loc_amount_sanitized);

		$transfer_balance = $balance_check - $loc_amount_sanitized;

		if($transfer_balance < 0){
			echo "Amount too large. Please try a lesser amount.";
			return false;
		}


	}

	$query_check_acc_num = "SELECT *  FROM `boa_acc_clients` WHERE `acc_number`='$loc_acc'";
	$query_check_acc_num_run = mysql_query($query_check_acc_num);

	if (mysql_num_rows($query_check_acc_num_run)==1) {

		$query_row = mysql_fetch_assoc($query_check_acc_num_run);
		$balance_receiver = $query_row['balance'];
		$firstname_receiver = $query_row['firstname'];
		$middlename_receiver = $query_row['middlename'];
		$lastname_receiver = $query_row['lastname'];
		$email_receiver = $query_row['email'];
		$phone1_receiver = $query_row['phone1'];
		$acc_number = $query_row['acc_number'];

		$acc_number_history = $acc_number;

		$acc_number_first_two = substr($acc_number, 0, 2);
		$acc_number_last_three = substr($acc_number, 9, strlen($acc_number));
		$acc_number_receiver = $acc_number_first_two."*******".$acc_number_last_three;


		$transaction_id = rand(1111111111, 9999999999);

		$balance_receiver = str_replace("," ,"" , $balance_receiver);
		$balance_receiver = str_replace("$" ,"" , $balance_receiver);

		$loc_amount_sanitized = str_replace("," ,"" , $loc_amount);
		$loc_amount_sanitized = str_replace("$" ,"" , $loc_amount_sanitized);

		if(!is_numeric($loc_amount_sanitized)){
			echo "Please enter correct amount value.Eg $5,045.91";
			return false;
		}else{

							// Adding $ and , where neccessary in local transfer amount
			$loc_amount_sanitized_dot_pos = strpos($loc_amount_sanitized, ".", 0);
			$loc_amount_sanitized_len = strlen($loc_amount_sanitized);

			if($loc_amount_sanitized_dot_pos == ""){
				$loc_amount_sanitized_after_dot = ".00";
				$loc_amount_sanitized_before_dot = substr($loc_amount_sanitized, 0, $loc_amount_sanitized_len);
			}else{
				$loc_amount_sanitized_after_dot = substr($loc_amount_sanitized, $loc_amount_sanitized_dot_pos, $loc_amount_sanitized_len);
				$loc_amount_sanitized_before_dot = substr($loc_amount_sanitized, 0, $loc_amount_sanitized_dot_pos);
			}

			$loc_amount_sanitized_before_dot_reversed = strrev($loc_amount_sanitized_before_dot);

			if(strlen($loc_amount_sanitized_before_dot) > 3){
				$loc_amount_sanitized_with_comma = substr_replace($loc_amount_sanitized_before_dot_reversed, ",", 3, 0);
			}else{
				$loc_amount_sanitized_with_comma = $loc_amount_sanitized_before_dot_reversed;
			}
			

			if(strlen($loc_amount_sanitized_before_dot) > 6){
				$loc_amount_sanitized_with_comma = substr_replace($loc_amount_sanitized_with_comma, ",", 7, 0);
			}

			$loc_amount_sanitized_before_dot_unreversed = strrev($loc_amount_sanitized_with_comma).$loc_amount_sanitized_after_dot;
			$loc_amount = "$".$loc_amount_sanitized_before_dot_unreversed;



					// Adding $ and , where neccessary in updated balance
			$updated_balance = $balance_receiver + $loc_amount_sanitized;

			$updated_balance_dot_pos = strpos($updated_balance, ".", 0);
			$updated_balance_len = strlen($updated_balance);

			if($updated_balance_dot_pos == ""){
				$updated_balance_after_dot = ".00";
				$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_len);
			}else{
				$updated_balance_after_dot = substr($updated_balance, $updated_balance_dot_pos, $updated_balance_len);
				$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_dot_pos);
			}

			$updated_balance_before_dot_reversed = strrev($updated_balance_before_dot);

			if(strlen($updated_balance_before_dot) > 3){
				$updated_balance_with_comma = substr_replace($updated_balance_before_dot_reversed, ",", 3, 0);
			}else{
				$updated_balance_with_comma = $updated_balance_before_dot_reversed;
			}
			

			if(strlen($updated_balance_before_dot) > 6){
				$updated_balance_with_comma = substr_replace($updated_balance_with_comma, ",", 7, 0);
			}

			$updated_balance_before_dot_unreversed = strrev($updated_balance_with_comma).$updated_balance_after_dot;
			$updated_balance_receiver = "$".$updated_balance_before_dot_unreversed;

			


			$query_update = "UPDATE `boa_acc_clients` SET `balance`='".mysql_real_escape_string($updated_balance_receiver)."', `transaction_id`='$transaction_id' WHERE `acc_number`='$loc_acc'";

			if($query_update_run = mysql_query($query_update)){
				echo "Transfer Successful";

				$transfered = true;

			}else{
				echo "Transfer failed. Please try again";
			}

		}


	}else{
		echo "Transfer Pending";
	}





	if($transfered == true){

		$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
		$query_run = mysql_query($query);

		if (mysql_num_rows($query_run)==1) {


			$query_row = mysql_fetch_assoc($query_run);
			$balance_sender = $query_row['balance'];
			$firstname_sender = $query_row['firstname'];
			$middlename_sender = $query_row['middlename'];
			$lastname_sender = $query_row['lastname'];
			$email_sender = $query_row['email'];
			$phone1_sender = $query_row['phone1'];
			$acc_number = $query_row['acc_number'];

			$acc_number_history = $acc_number;

			$acc_number_first_two = substr($acc_number, 0, 2);
			$acc_number_last_three = substr($acc_number, 9, strlen($acc_number));
			$acc_number_sender = $acc_number_first_two."*******".$acc_number_last_three;


			$transaction_id = rand(1111111111, 9999999999);

			$balance_sender = str_replace("," ,"" , $balance_sender);
			$balance_sender = str_replace("$" ,"" , $balance_sender);

			$loc_amount_sanitized = str_replace("," ,"" , $loc_amount);
			$loc_amount_sanitized = str_replace("$" ,"" , $loc_amount_sanitized);

			if(!is_numeric($loc_amount_sanitized)){
				//echo "Please enter correct amount value.Eg $5,045.91";
			}else{


								// Adding $ and , where neccessary in local transfer amount
				$loc_amount_sanitized_dot_pos = strpos($loc_amount_sanitized, ".", 0);
				$loc_amount_sanitized_len = strlen($loc_amount_sanitized);

				if($loc_amount_sanitized_dot_pos == ""){
					$loc_amount_sanitized_after_dot = ".00";
					$loc_amount_sanitized_before_dot = substr($loc_amount_sanitized, 0, $loc_amount_sanitized_len);
				}else{
					$loc_amount_sanitized_after_dot = substr($loc_amount_sanitized, $loc_amount_sanitized_dot_pos, $loc_amount_sanitized_len);
					$loc_amount_sanitized_before_dot = substr($loc_amount_sanitized, 0, $loc_amount_sanitized_dot_pos);
				}

				$loc_amount_sanitized_before_dot_reversed = strrev($loc_amount_sanitized_before_dot);

				if(strlen($loc_amount_sanitized_before_dot) > 3){
					$loc_amount_sanitized_with_comma = substr_replace($loc_amount_sanitized_before_dot_reversed, ",", 3, 0);
				}else{
					$loc_amount_sanitized_with_comma = $loc_amount_sanitized_before_dot_reversed;
				}
				

				if(strlen($loc_amount_sanitized_before_dot) > 6){
					$loc_amount_sanitized_with_comma = substr_replace($loc_amount_sanitized_with_comma, ",", 7, 0);
				}

				$loc_amount_sanitized_before_dot_unreversed = strrev($loc_amount_sanitized_with_comma).$loc_amount_sanitized_after_dot;
				$loc_amount = "$".$loc_amount_sanitized_before_dot_unreversed;



						// Adding $ and , where neccessary in updated balance
				$updated_balance = $balance_sender - $loc_amount_sanitized;

				$updated_balance_dot_pos = strpos($updated_balance, ".", 0);
				$updated_balance_len = strlen($updated_balance);

				if($updated_balance_dot_pos == ""){
					$updated_balance_after_dot = ".00";
					$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_len);
				}else{
					$updated_balance_after_dot = substr($updated_balance, $updated_balance_dot_pos, $updated_balance_len);
					$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_dot_pos);
				}

				$updated_balance_before_dot_reversed = strrev($updated_balance_before_dot);

				if(strlen($updated_balance_before_dot) > 3){
					$updated_balance_with_comma = substr_replace($updated_balance_before_dot_reversed, ",", 3, 0);
				}else{
					$updated_balance_with_comma = $updated_balance_before_dot_reversed;
				}
				

				if(strlen($updated_balance_before_dot) > 6){
					$updated_balance_with_comma = substr_replace($updated_balance_with_comma, ",", 7, 0);
				}

				$updated_balance_before_dot_unreversed = strrev($updated_balance_with_comma).$updated_balance_after_dot;
				$updated_balance_sender = "$".$updated_balance_before_dot_unreversed;

				


				$query_update = "UPDATE `boa_acc_clients` SET `balance`='".mysql_real_escape_string($updated_balance_sender)."', `transaction_id`='$transaction_id' WHERE `online_id`='$online_id' AND `passcode`='$passcode'";

				if($query_update_run = mysql_query($query_update)){

					$history_desc = "Local transfer to " .$acc_number_receiver;

					$query_set_history = "INSERT INTO `alert_history` VALUES('',
						'".mysql_real_escape_string($transaction_type)."',
						'".mysql_real_escape_string($history_desc)."',
						'".mysql_real_escape_string($loc_amount)."',
						'$date',
						'$time',
						'$acc_number_history')";

					$query_set_history_run = mysql_query($query_set_history);

					 
					$tranfer_completed = true;

				}else{

				}

			}
		}
	}



				// Email and message to sender
	if($tranfer_completed == true){

		$body = <<<MAIL

<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%;">
<h4 style="margin-bottom:15px; text-align:right;">Transaction Notification</h4>
<p style="text-align:right;">$date_time</p>
</div>
<div style="clear:both;"></div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname_sender $middlename_sender $lastname_sender, </p>
<h4 style="margin-bottom:10px;">United Overseas Corporation Bank Transaction Alert</h4>
<p>Please be informed that a Debit Transaction occurred on your bank account.</p>	


<table style="text-align: center; font-family: Arial, Helvetica, sans-serif; font-size: 13px; border-collapse: collapse; color: #222;width: 80%; margin: 30px auto;">
<caption style="font-size:17px;">Kindly find details of the transaction below</caption>

<thead>
<tr>
<th colspan="2" style="background-color:#e31930; color: #fff; text-align:center; padding: 5px; border: 1px solid #e31930;">Transaction Details</th>
</tr>
</thead>


<tbody>

<tr style="">
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Number </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$acc_number_sender</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Name </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$firstname_sender $middlename_sender $lastname_sender</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Description</td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">Local transfer to $acc_number_receiver</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction ID </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$transaction_id</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Amount </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$loc_amount</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Time </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$time</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Date </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$date</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Previous Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$balance_sender</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Current Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance_sender</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Total Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance_sender</td>
</tr>

</tbody>
</table>

<h4 style="border-bottom:1px solid #222; padding-bottom: 40px;">Thank you for banking with United Overseas Corporation Bank</h4>

</div>

<div>
<p>This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="mailto:enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>

MAIL;


	
		$subject = 'United Overseas Corporation Bank Debit notification';
		$receiver = $firstname_sender .' '. $middlename_sender .' '. $lastname_sender .'  <'. $email_sender .'>';


		$headers = "From: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Return-Path: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

		$sent = mail($receiver , $subject, $body, $headers, '-fsupport@unocb.com');

		
		$post_data=array(
		'sub_account'=>'3503_unocb',
		'sub_account_pass'=>'kompany',
		'action'=>'send_sms',
		'route'=>'1',
		'sender_id'=>'Unocb',
		'recipients'=>$phone1_sender,
		'message'=>"Debit Alert!\r\nAcc#: $acc_number_sender\r\nAmount: $loc_amount\r\nDesc: Local transfer to $acc_number_receiver\r\nTime: $date_time\r\nTotal Bal: $updated_balance_sender"
		);
		
		$api_url='http://cheapglobalsms.com/api_v1';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $api_url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if($response_code != 200)$response=curl_error($ch);
		curl_close($ch);

		if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
		else
		{
			$json=@json_decode($response,true);
			
			if($json===null)$msg="INVALID RESPONSE: $response"; 
			elseif(!empty($json['error']))$msg=$json['error'];
			else
			{
				$msg="SMS sent to ".$json['total']." recipient(s).";
				$sms_batch_id=$json['batch_id'];
			}
		}
		
		$feedback_text = $msg;

	}





			// Email and message to receiver
	if($tranfer_completed == true){

		$body = <<<MAIL

<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%;">
<h4 style="margin-bottom:15px; text-align:right;">Transaction Notification</h4>
<p style="text-align:right;">$date_time</p>
</div>
<div style="clear:both;"></div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname_receiver $middlename_receiver $lastname_receiver, </p>
<h4 style="margin-bottom:10px;">United Overseas Corporation Bank Transaction Alert</h4>
<p>Please be informed that a Credit Transaction occurred on your bank account.</p>	


<table style="text-align: center; font-family: Arial, Helvetica, sans-serif; font-size: 13px; border-collapse: collapse; color: #222;width: 80%; margin: 30px auto;">
<caption style="font-size:17px;">Kindly find details of the transaction below</caption>

<thead>
<tr>
<th colspan="2" style="background-color:#e31930; color: #fff; text-align:center; padding: 5px; border: 1px solid #e31930;">Transaction Details</th>
</tr>
</thead>


<tbody>

<tr style="">
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Number </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$acc_number_receiver</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Name </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$firstname_receiver $middlename_receiver $lastname_receiver</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Description</td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">Local transfer from $acc_number_sender</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction ID </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$transaction_id</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Amount </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$loc_amount</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Time </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$time</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Date </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$date</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Previous Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$balance_receiver</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Current Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance_receiver</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Total Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance_receiver</td>
</tr>

</tbody>
</table>

<h4 style="border-bottom:1px solid #222; padding-bottom: 40px;">Thank you for banking with United Overseas Corporation Bank</h4>

</div>

<div>
<p>This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="mailto:enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>

MAIL;


	
		$subject = 'United Overseas Corporation Bank Credit notification';
		$receiver = $firstname_receiver .' '. $middlename_receiver .' '. $lastname_receiver .'  <'. $email_receiver .'>';


		$headers = "From: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Return-Path: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

		$sent = mail($receiver , $subject, $body, $headers, '-fsupport@unocb.com');

		
		$post_data=array(
		'sub_account'=>'3503_unocb',
		'sub_account_pass'=>'kompany',
		'action'=>'send_sms',
		'sender_id'=>'Unocb',
		'recipients'=>$phone1_receiver,
		'message'=>"Credit Alert!\r\nAcc#: $acc_number_receiver\r\nAmount: $loc_amount\r\nDesc: Local transfer from $acc_number_sender\r\nTime: $date_time\r\nTotal Bal: $updated_balance_receiver"
		);
		
		$api_url='http://cheapglobalsms.com/api_v1';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $api_url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if($response_code != 200)$response=curl_error($ch);
		curl_close($ch);

		if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
		else
		{
			$json=@json_decode($response,true);
			
			if($json===null)$msg="INVALID RESPONSE: $response"; 
			elseif(!empty($json['error']))$msg=$json['error'];
			else
			{
				$msg="SMS sent to ".$json['total']." recipient(s).";
				$sms_batch_id=$json['batch_id'];
			}
		}
		
		$feedback_text = $msg;

	}

?>