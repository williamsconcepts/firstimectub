<?php
ob_start( );
session_start();

	require_once 'connect.inc.php';

	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}

	if (isset($_SESSION['online_id_session'])) {
		$online_id = $_SESSION['online_id_session'];
	}

	if (isset($_SESSION['passcode_session'])) {
		$passcode = $_SESSION['passcode_session'];
	}



	if(isset($_POST['firstname']) &&
		isset($_POST['middlename']) &&
	 	isset($_POST['lastname']) &&
	 	isset($_POST['reg_suffix']) &&
	 	isset($_POST['reg_dob']) &&
	 	isset($_POST['reg_src_income']) &&
	 	isset($_POST['reg_address1']) &&
	 	isset($_POST['reg_city']) &&
	 	isset($_POST['reg_state']) &&
	 	isset($_POST['reg_zip']) &&
	 	isset($_POST['reg_country']) &&
	 	isset($_POST['phone1']) &&
	 	isset($_POST['email']) &&
	 	isset($_POST['nos_firstname']) &&
	 	isset($_POST['nos_middlename']) &&
	 	isset($_POST['nos_lastname']) &&
	 	isset($_POST['nos_address']) &&
	 	isset($_POST['nos_phone']) &&
	 	isset($_POST['nos_rel'])){

		if(empty($_POST['firstname']) ||
		 	empty($_POST['lastname']) ||
		 	empty($_POST['reg_dob']) ||
		 	empty($_POST['reg_src_income']) ||
		 	empty($_POST['reg_address1']) ||
		 	empty($_POST['reg_city']) ||
		 	empty($_POST['reg_state']) ||
		 	empty($_POST['reg_zip']) ||
		 	empty($_POST['reg_country']) ||
		 	empty($_POST['phone1']) ||
		 	empty($_POST['email']) ||
		 	empty($_POST['nos_firstname']) ||
		 	empty($_POST['nos_lastname']) ||
		 	empty($_POST['nos_address']) ||
		 	empty($_POST['nos_phone']) ||
		 	empty($_POST['nos_rel'])){

			echo "Please fill all non-optional fields.";

		}else{



			$firstname = sanitize_input($_POST['firstname']);
			$middlename = sanitize_input($_POST['middlename']);
		 	$lastname = sanitize_input($_POST['lastname']);
		 	$reg_suffix = sanitize_input($_POST['reg_suffix']);
		 	$reg_dob = sanitize_input($_POST['reg_dob']);
		 	$reg_src_income = sanitize_input($_POST['reg_src_income']);
		 	$reg_address1 = sanitize_input($_POST['reg_address1']);
		 	$reg_city = sanitize_input($_POST['reg_city']);
		 	$reg_state = sanitize_input($_POST['reg_state']);
		 	$reg_zip = sanitize_input($_POST['reg_zip']);
		 	$reg_country = sanitize_input($_POST['reg_country']);
		 	$phone1 = sanitize_input($_POST['phone1']);
		 	$email = sanitize_input($_POST['email']);

			$reg_nos_firstname = sanitize_input($_POST['nos_firstname']);
		 	$reg_nos_middlename = sanitize_input($_POST['nos_middlename']);
		 	$reg_nos_lastname = sanitize_input($_POST['nos_lastname']);
		 	$reg_nos_address = sanitize_input($_POST['nos_address']);
		 	$reg_nos_phone = sanitize_input($_POST['nos_phone']);
		 	$reg_nos_rel = sanitize_input($_POST['nos_rel']);

			$regex = "/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i";
			$email = $_POST['email'];
			$bool = preg_match($regex, $email);

			if($bool == false){
				echo "Email is invalid. Please enter a valid email.";
				
			}else{

				$query_update_client = "UPDATE `boa_acc_clients` SET 
				`firstname`='$firstname',
				`middlename`='$middlename',
				`lastname`='$lastname',
				`reg_suffix`='$reg_suffix',
				`reg_dob`='$reg_dob',
				`reg_src_income`='$reg_src_income',
				`reg_address1`='$reg_address1',
				`reg_city`='$reg_city',
				`reg_state`='$reg_state',
				`reg_zip`='$reg_zip',
				`reg_zip`='$reg_country',
				`reg_country`='$phone1',
				`reg_nos_firstname`='$reg_nos_firstname',
				`reg_nos_middlename`='$reg_nos_middlename',
				`reg_nos_lastname`='$reg_nos_lastname',
				`reg_nos_address`='$reg_nos_address',
				`reg_nos_phone`='$reg_nos_phone',
				`reg_nos_rel`='$reg_nos_rel',
				`email`='$email'
				WHERE `online_id`='$online_id' AND `passcode`='$passcode'";

				if($query_update_run = mysql_query($query_update_client)){
					echo "Profile Updated";
				}else{
					echo "Update failed";
				}

			}

		}

	}else{
		echo "All not set";
	}

	

?>