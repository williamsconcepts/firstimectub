<?php
ob_start( );
session_start();

	if(isset($_POST['passcode'])){
		$passcode = $_POST['passcode'];
		$_SESSION['passcode_session'] = $passcode;
		echo "Successful";
	}
	

?>