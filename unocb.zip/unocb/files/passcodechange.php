<?php
ob_start( );
session_start();
	
	require_once '../files/connect.inc.php';

	$online_id = "";


	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}


	$timestamp = time();
	$time = @date('H:i:s', $timestamp -(60*60));
	$date = @date('d-m-Y', $timestamp - (60*60));
	$date_time = $date." ".$time;
	

	if(isset($_POST['passcode'])&&
	 	isset($_POST['new_passcode'])&&
	 	isset($_POST['rpt_passcode'])){


		if(empty($_POST['passcode']) ||
			empty($_POST['new_passcode']) ||
			empty($_POST['rpt_passcode'])){

			 echo "Fill all fileds!";

		}else{

			$passcode = sanitize_input($_POST['passcode']);
			$new_passcode = sanitize_input($_POST['new_passcode']);
			$rpt_passcode = sanitize_input($_POST['rpt_passcode']);

			if($new_passcode != $rpt_passcode){
				echo "Passcode mismatch!";
				return false;
			}

			if(isset($_SESSION["online_id_session"])) {
				$online_id = $_SESSION["online_id_session"];
				
			}else{
				echo "No session!";
				return false;
			}

			$query_check_passcode = "SELECT * FROM `boa_acc_clients` WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
			$query_check_passcode_run = mysql_query($query_check_passcode);

			if (mysql_num_rows($query_check_passcode_run)==1){

				$query_row = mysql_fetch_assoc($query_check_passcode_run);
				$firstname = $query_row['firstname'];
				$middlename = $query_row['middlename'];
				$lastname = $query_row['lastname'];
				$email = $query_row['email'];
				$phone1 = $query_row['phone1'];

			}else{
				echo "Incorrect passcode!";
				return false;
			}


			$query_update = "UPDATE `boa_acc_clients` SET `passcode`='".mysql_real_escape_string($new_passcode)."' WHERE `online_id`='$online_id'";

			if($query_update_run = mysql_query($query_update)){

				echo "Successful!";


				$post_data=array(
				'sub_account'=>'3503_unocb',
				'sub_account_pass'=>'kompany',
				'action'=>'send_sms',
				'sender_id'=>'Unocb',
				'recipients'=>$phone1,
				'message'=>"Hello $firstname, you have successfullly changed your passcode."
				);
				
				$api_url='http://cheapglobalsms.com/api_v1';

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $api_url);
				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				
				$response = curl_exec($ch);
				$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
				if($response_code != 200)$response=curl_error($ch);
				curl_close($ch);

				if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
				else
				{
					$json=@json_decode($response,true);
					
					if($json===null)$msg="INVALID RESPONSE: $response"; 
					elseif(!empty($json['error']))$msg=$json['error'];
					else
					{
						$msg="SMS sent to ".$json['total']." recipient(s).";
						$sms_batch_id=$json['batch_id'];
					}
				}
				
				// $feedback_text = $msg;



				$body = <<<MAIL
<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="ECIB Logo"></a>
</div>

<div style="float:right; display:block; width:50%;text-align:right;">
<h4 style="margin-bottom:15px;">Transfer Authorisation Code</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname $middlename $lastname, </p>


<p>You have successfullly changed your passcode.</p>

<h4>Thank you for banking with United Overseas Corporation Bank</h4>

<p>Best Regards,</p>
<p style="padding-bottom:40px; border-bottom:1px solid #222;">United Overseas Corporation Bank team</p>

</div>

<div>
<p  style="border-top:1px solid #222; padding-top: 40px;">This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>


MAIL;


	
		$subject = 'United Overseas Corporation Bank Passcode Change Notification';
		$receiver = $firstname .' '. $middlename .' '. $lastname .'  <'. $email .'>';


		$headers = "From: United Overseas Corporation Bank support@unocb.com\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank support@unocb.com\r\n";
		$headers .= "Content-type: text/html\r\n";

		$sent = mail($receiver , $subject, $body, $headers, '-fsupport@unocb.com');





			}else{
				echo "Failed!";
			}


		}




	}else{
		echo "Failed!";
	}
	
?>