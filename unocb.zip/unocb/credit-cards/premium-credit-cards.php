<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="top_img">
		<h4>Welcome Offer:</h4>
		<div class="left_float">
			<p>Get up to 4% cash back on every purchase</p>
			<p>in your first 4 months! No annual fee.</p>
		</div>

		<div class="right_float">
			<img src="../images/bmo-cashback-mastercard.png">
		</div>

		<div class="clear"></div>
		
	</div>
	<h2 class="header">Explore United Overseas Corporation Bank MasterCard Credit Cards</h2>

	<div id="each_card_wrap">
		<div class="each_card left_float"><a href="special-offers-credit-cards.php">Special Offers</a></div>
		<div class="each_card left_float"><a href="cashback-credit-cards.php">CashBack</a></div>
		<div class="each_card left_float"><a href="bmo-rewards-travel-credit-cards.php">Rewards/Travel</a></div>
		<div class="each_card left_float"><a href="air-miles-credit-cards.php">AIR MILES</a></div>
		<div class="each_card left_float"><a href="no-annual-fee-credit-cards.php">No Annual Fee</a></div>
		<div class="each_card left_float"><a class="current" href="premium-credit-cards.php">Premium</a></div>

		<div class="clear"></div>
	</div>

	<div id="card_types">
		<div class="card_type_each side left_float">
			<img src="../images/bmo-air-miles-world-elite-mastercard.png">
			<h2>United Overseas Corporation Bank AIR MILES World Elite MasterCard</h2>
			<p><span class="red">Limited time: </span>Get 2,000 AIR MILES Bonus Miles.</p>
			<p>Get 1 reward mile/$10 on card purchases</p>
			<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>
		</div>

		<div class="card_type_each center left_float">
			<p class="featured_offer">Featured Offer</p>
			<img src="../images/bmo-cashback-world-elite-mastercard.png">
			<h2>United Overseas Corporation Bank CashBack World Elite MasterCard</h2>
			<p><span class="red">Welcome offer: </span>Get up to 4% cash back on every purchase in your first 4 months.</p>
			<p>Then earn 1.75% cash back on all other card purchases</p>
			<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>
		</div>

		<div class="card_type_each side left_float">
			<img src="../images/bmo-rewards-world-elite-mastercard.png">
			<h2>United Overseas Corporation Bank World Elite MasterCard</h2>
			<p><span class="red">Limited time: </span>Get 20,000 United Overseas Corporation Bank Rewards points.</p>
			<p>Earn $2 for every $100 in card purchases.</p>
			<p>United Overseas Corporation Bank Rewards points do not expire.</p>
			<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>
		</div>

		<div class="clear"></div>
	</div>


	<div class="section_half2">

		<div class="section left_float" id="section_wt_border">
			<div id="section1"></div>
			<h2>Can’t find what you’re looking for?</h2>
			<div class="bordered_btn">
				<a href="../contact/contact-us.php">Contact us</a>
			</div>
		</div>

		<div class="section left_float" id="">
			<div id="section2"></div>
			<h2>Have questions?</h2>
			<div class="bordered_btn">
				<a href="../contact/contact-us.php">Contact us</a>
			</div>
		</div>

		<div class="clear"></div>
	</div>


</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>