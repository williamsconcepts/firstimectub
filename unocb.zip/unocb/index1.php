<?php
	require_once 'files/head_section.php';
	require_once 'files/navigation.php';
?>

<div class="page_width">

	<div id="home_wrapper">
		<div id="slider_img" class="">
			<div id="maj_slider_control_prev" class="maj_slider_control"></div>
			<div id="maj_slider_control_next" class="maj_slider_control"></div>
			<div id="slide_bottom"></div>
		</div>


		<div id="sample_service">

			<div class="each_sample_service left_float">

				<h2>Chequing &amp; Savings Accounts</h2>
				<img src="images/debit-card-en.jpg">

				<h3>Plus</h3>
				<p>Great value for moderate banking needs</p>
				<p>$10.95 Monthly fee</p>
				<p>$3,000 Minimum balance to waive fee</p>
				<div class="more"><a href="bank-accounts/index.php">Learn more</a></div>
				<div class="open_now"><a href="client-area/online-account-opening.php">Open now</a></div>
			</div>

			<div class="each_sample_service left_float">

				<h2>Credit Cards</h2>
				<img src="images/bmo-cashback-mastercard.png">

				<h3>United Overseas Corporation Bank CashBack MasterCard</h3>
				<p><span>Welcome Offer:</span> Get up to 4% cash back on</p>
				<p>every purchase in your first 4 months!</p>
				<p>Get 1% CashBack on all other card purchases</p>
				<p>No annual fee</p>
				<div class="more"><a href="credit-cards/premium-credit-cards.php">Learn more</a></div>
				<div class="open_now"><a href="contact/contact-us.php">Apply now</a></div>
			</div>

			<div class="each_sample_service left_float">

				<h2>Meet with an expert</h2>
				<p>Choose the date, time, and branch</p>
				<p>location using our easy online tool.</p>
				<br>
				<div class="open_now red_bg"><a href="contact/contact-us.php">Book an appointment</a></div>
				<br>
				<p>Or, email us at</p>
				<p class="more"><a href="mailto:info@unocb.com">info@unocb.com</a></p>


			</div>

			<div class="clear"></div>

		</div>


		<div id="home_mortgage">

			<h2>Feel at home with a mortgage that fits your needs.</h2>
			<p>Whether you're buying a new home or refinancing, get guidance on calculating the</p>
			<p>costs, choosing the right loan, and understanding the next steps.</p>

			<div id="home_mortgage_part_wrap">
				<h2>Mortgage Rates</h2>

				<div class="each_mort left_float">
					<h3>2.890<sup>%</sup></h3>
					<h3><hr></h3>
					<h3>2.91<sup>%</sup> APR<sup>*</sup> </h3>
					<br>
					<p>5-year United Overseas Corporation Bank Smart Fixed Mortgage (fixed rate, closed mortgage)</p>
				</div>

				<div class="each_mort left_float">
					<br>
					<br>
					<h3>3.190<sup>%</sup></h3>
					<br>
					<br>
					<br>
					<p style="margin-top: 7px;">2-year fixed mortgage (fixed rate, closed mortgage)</p>
				</div>

				<div class="each_mort left_float">
					<br>
					<br>
					<h3>2.850<sup>%</sup></h3>
					<br>
					<br>
					<br>
					<p style="margin-top: 7px;">5-year variable mortgage (variable rate, closed mortgage)</p>
				</div>

				<div id="get_approved" class="left_float">
					<h3>Get pre-approved</h3>
					<p>Fill out our quick online form.</p>
					<div class="open_now red_bg"><a href="contact/contact-us.php">Start now</a></div>
				</div>

				<div class="clear"></div>

				<div class="bordered_btn">
					<a href="mortgages/mortgage-rates-fixed.php">View all rates</a>
				</div>

			</div>

		</div>



		<div id="home_wealth_mgt">

			<div class="home_wealth_mgt_parts left_float">
				<h2>Responding to your wealth management needs</h2>
				<p>We help you grow, protect and transition your wealth with award-winning</p>
				<p>wealth management services like investment management and wealth</p>
				<p>planning.</p>

				<div class="bordered_btn">
					<a href="">Explore</a>
				</div>
			</div>

			<div class="home_wealth_mgt_parts left_float">
				<h2>Make your money work for you</h2>
				<p>Prepare for the future with the right investment solution, from building a nest</p>
				<p>egg to saving for your child's education.</p>

				<div class="bordered_btn">
					<a href="">Get started</a>
				</div>
			</div>

			<div class="clear"></div>

		</div>




		<div id="sample_service" class="bottom_sample">

			<div class="each_sample_service left_float">

				<h2>New to United Overseas Corporation Bank?</h2>

				<p>Prepare for a successful future with</p>
				<p>the United Overseas Corporation Bank NewStart<sup>&trade;</sup> Program.</p>
				<div class="more"><a href="loans/rrsp-and-investments.php">Learn more</a></div>
			</div>

			<div class="each_sample_service left_float">

				<h2>Have other loan needs?</h2>

				<p>Need a line of credit? Ready to buy a new car?</p>
				<p>Find out more about our other borrowing</p>
				<p>solutions.</p>
				<div class="more"><a href="loans/home-and-family.php">Lines of credit</a></div>
				<div class="more"><a href="loans/home-and-family.php">Loans</a></div>
			</div>

			<div class="each_sample_service left_float">

				<h2>Planning a trip?</h2>
				<p>Be ready for anything with all of our travel</p>
				<p>services:</p>
				<div class="more"><a href="loans/rrsp-and-investments.php">Travel Insurance</a></div>
				<div class="more"><a href="loans/travel-or-wedding.php">Traveler's Cheques</a></div>
				<div class="more"><a href="loans/travel-or-wedding.php">Foreign Currency</a></div>
			</div>

			<div class="clear"></div>

			

		</div>


		<p>Annualized return for United Overseas Corporation Bank SelectTrust® Balanced Portfolio Series A: since inception 7.65%; 1-year 4.6%; 3-year 7.61%. Series A as at October 12th, 2016. Commissions, trailing commissions, management fees and expenses may be associated with mutual fund investments. Please read the fund facts or prospectus before investing. The indicated rates of return are the historical annual compounded total returns including changes in unit value and reinvestment of all distributions and do not take into account sales, redemptions, distribution or optional charges or income taxes payable by any unit holder that would have reduced returns. United Overseas Corporation Bank Mutual Funds are offered by United Overseas Corporation Bank Investments Inc., a financial services firm and separate entity from Bank of Montreal. Mutual funds are not guaranteed, their values change frequently and past performance may not be repeated.</p>



	</div>

</div>

<?php
	require_once 'files/footer.php';
	require_once 'files/jsfiles.php';
?>