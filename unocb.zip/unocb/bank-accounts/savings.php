<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">
	<h2 class="header">Let's find you the right bank account</h2>

	<div id="bnk_acc">

		<div class="each_bnk_acc savings_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img1"></div>
				</div>
				
				<h4 class="bnk_acc_header">Smart Saver</h4>

				<p class="desc">Enjoy a high interest rate regardless of your account balance</p>

				<div class="amount"> 
					<h3>0.400%</h3>
					<h5>Interest rate</h5>
				</div>

				<div class="other_wu">
					<p>$0</p>
					<h5>Monthly savings requirement</h5>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>




		<div class="each_bnk_acc savings_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img2"></div>
				</div>
				<h4 class="bnk_acc_header">Savings Builder</h4>

				<p class="desc">Rewards you with bonus interest for growing your savings monthly</p>

				<div class="amount"> 
					<h3>1.200%</h3>
					<h5>Interest rate</h5>
				</div>

				<div class="other_wu">
					<p>$200</p>
					<h5>Monthly savings requirement</h5>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc savings_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img3"></div>
				</div>
				<h4 class="bnk_acc_header">Premium Rate Savings</h4>

				<p class="desc">Earn daily interest, access your funds whenever you need them</p>

				<div class="amount"> 
					<h3>0.050%</h3>
					<h5>Interest rate</h5>
				</div>

				<div class="other_wu">
					<p>$0</p>
					<h5>Monthly savings requirement</h5>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc savings_acc left_float">
			<div class="each_bnk_acc_wrap">
				
				<div class="top_img_wrap">
					<div class="top_img" id="top_img4"></div>
				</div>
				<h4 class="bnk_acc_header">U.S. Dollar Premium</h4>

				<p class="desc">Save in U.S. dollars, access your funds whenever you need them</p>

				<div class="amount"> 
					<h3>0.050%</h3>
					<h5>Interest rate</h5>
				</div>

				<div class="other_wu">
					<p>$0</p>
					<h5>Monthly savings requirement</h5>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>


		<div class="clear"></div>

	</div>

	<div class="section_half">
		<div class="section left_float" id="section1">
			<img src="../images/d-everyday-banking.savings.png">
		</div>

		<div class="section left_float" id="section2">
			<h2>Your Savings Account</h2>
			<p>Your savings account helps you set aside money for short-term goals like vacations, or establishing an emergency fund in case you need it.</p>
			<p>Plus, your money is set aside from your chequing account, earning interest, so you won’t have the temptation to spend it.</p>
			<p>Earn. Save. Repeat. Make saving a habit and get rewarded.</p>
		</div>

		<div class="clear"></div>
	</div>
</div>

<div id="blue_wrapper" class="three_items">
	<div id="blue_pre_footer" class="page_width">
		<h2>The United Overseas Corporation Bank difference</h2>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img1"></div>
				<p>You can open a new United Overseas Corporation Bank chequing account on your smartphone from wherever you are. As long as we’re able to verify your ID with the info you provide, there’s no need to visit a branch!</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img2"></div>
				<p>Enjoy tailored banking advice that fits your unique life needs</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img3"></div>
				<p>Open multiple accounts for you and your spouse/partner for one monthly feeLink will open in new window1 with PlanShare</p>
			</div>

			<div class="clear"></div>

			<div class="white_bordered_btn">
				<a href="">Learn more about switching to us</a>
			</div>
	
	</div>
</div>


<div id="page_body" class="page_width">

	<div class="section_half2">

		<div class="section left_float" id="section_wt_border">
			<div id="section1"></div>
			<h2>Not sure which bank account is right for you?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="section left_float" id="">
			<div id="section2"></div>
			<h2>Have questions?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="clear"></div>
	</div>

</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>