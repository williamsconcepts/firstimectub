<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">
	<h2 class="header">Banking Services</h2>

	<div id="bankn_serv">
		<div class="each_bnk_serv left_float">
			<a href="#24-7-banking">24/7 Banking</a>
		</div>

		<div class="each_bnk_serv left_float">
			<a href="#managing-money">Managing Money</a>
		</div>

		<div class="each_bnk_serv left_float">
			<a href="#account-services">Account Services</a>
		</div>

		<div class="each_bnk_serv left_float">
			<a href="#travel-services">Travel Services</a>
		</div>

		<div class="clear"></div>
	</div>

	<div class="each_bankn_serv odd">
		<h1 id="24-7-banking">24/7 Banking</h1>
		<h2>How to set up United Overseas Corporation Bank Online Banking</h2>
		<p>Setting up Online Banking allows for secure, 24/7 access to check your balances, pay bills, transfer money and more. You’re protected with our 100% Electronic Banking Guarantee.</p>

		<h2>How to sign in to United Overseas Corporation Bank Online Banking</h2>

		<h4>United Overseas Corporation Bank Mobile Banking</h4>
		<p>Quickly and easily manage your money with our United Overseas Corporation Bank Mobile Banking app.</p>

		<ul>
           	<li>Quickly view balances and transactions on any of your accounts with a swipe of a finger</li>
            <li>Transfer funds between eligible accounts and send and receive an <i>Interac</i> e-transfer to anyone on your recipient list</li>
            <li>Pay bills now or later through future dated bill payment</li>
            <li>View credit card, recent transactions, eStatements, due dates and minimum payments</li>
            <li>Make a branch appointment in real time</li>
            <li>Set up travel notifications to ensure you'll have uninterrupted access to your United Overseas Corporation Bank credit card and we'll know to expect out-of-country charges</li>
            <li>Assign nicknames to your most used debit or credit cards to sign in quickly and securely</li>
            <li>Search for nearby United Overseas Corporation Bank branches and ATMs</li>
            <li>Touch ID access to the United Overseas Corporation Bank Mobile Banking App on iPhone* 5S, 6 or 6 Plus.</li>
        </ul>

        <p>Simply download the app from your app store to use United Overseas Corporation Bank Mobile Banking. For other touch devices that do not have an app, you can access the United Overseas Corporation Bank Mobile Banking through your browser.</p>


        <h2>United Overseas Corporation Bank Banking &amp; InvestorLine App</h2>
        <p>Now, experience United Overseas Corporation Bank's tablet app for iPad to help you easily manage both your banking and self-directed investing needs – all with one app.</p>

        <h4>Banking</h4>
        <ul>
            <li>Pay multiple bills at one time and set up future-dated bill payments</li>
            <li>Transfer funds between accounts, make cross-currency transfers, and send an <i>Interac</i> e-transfer</li>
            <li>View account balances and transaction history </li>
            <li>Access your eStatements and view cheque images</li>
            <li>Set up a travel notification for your United Overseas Corporation Bank MasterCard card</li>
            <li>Book in-branch appointments in real time </li>
            <li>Our smart money management tool to set budgets and savings goals and track how you’re doing.</li>
        </ul>

        <h4>United Overseas Corporation Bank InvestorLine</h4>

        <ul>
            <li>View your self-directed investing account information</li>
            <li>Access real-time quotes and interactive charts</li>
            <li>Trade equities, ETFs, options, mutual funds and GICs </li>
        </ul>

        <p>Want to do your self-directed investing in addition to banking with United Overseas Corporation Bank? It’s easy. Open an account today. </p>

	</div>

	<div class="section_half each_bankn_serv odd">
		<div class="section left_float" id="section1">
			<img src="../images/my-home-image.jpg">

			<h2>United Overseas Corporation Bank My Home App</h2>
			<p>Calculate your home ownership costs as well as track and compare the homes you have visited to make your purchase decision easier.</p>
			<ul>
	            <li>Quickly calculate your borrowing needs using the Mortgage Calculator</li>
	            <li>Create handy home profiles, upload photos, compile checklists, and take notes while you house hunt</li>
	            <li>Manage, track, and compare your favourite properties based on mortgage costs and email detailed comparisons to ease decision making</li>
	            <li>Contact a United Overseas Corporation Bank Mortgage Specialist to discuss financing or start the pre-approval process</li>
	        </ul>
		</div>

		<div class="section left_float" id="section2">
			<h2>United Overseas Corporation Bank Mobile PayPas Tag</h2>
			<p>How it Works</p>
			<ul>
                <li>Stick the Mobile <i>PayPass</i> Tag to the back of your mobile phone and you're ready to make purchases anywhere <i>PayPass</i> is accepted</li>
            </ul>

            <p>It's Convenient</p>

            <ul>
	            <li>Making small purchases is fast and hassle-free. Simply Tap &amp; Go and you're on your way. The United Overseas Corporation Bank Mobile <i>PayPass</i> Tag communicates wirelessly with the <i>PayPass</i> terminal</li>
	            <li>Register to have detailed email transaction notifications sent to you when a United Overseas Corporation Bank Mobile <i>PayPass</i> Tag transaction has been completed</li>
	        </ul>

	        <p>It's Rewarding</p>

	        <ul>
	            <li>If you earn rewards on your United Overseas Corporation Bank MasterCard credit card, you'll continue to earn rewards with your United Overseas Corporation Bank Mobile <i>PayPass</i> purchases</li>
	        </ul>

	        <p>It's Secure</p>
	        <ul>
            	<li>Secure encryption technology makes your United Overseas Corporation Bank Mobile <i>PayPass</i> Tag as safe as your United Overseas Corporation Bank credit card. Plus your smartphone never leaves your hand when making a purchase. And, you'll continue to receive the same level of security with Zero Liability on unauthorized purchases, lost or stolen card replacement, Extended Warranty Insurance, Purchase Protection and iDefence - your protection against identity theft</li>
	        </ul>

		</div>

		<div class="clear"></div>
	</div>

	<div class="each_bankn_serv">

		<h2>United Overseas Corporation Bank Branch Banking</h2>
		<p>With over 900 branches, we offer a full range of financial services.</p>
		<h4>Product Services</h4>
		<ul>
            <li>Open new bank accounts, add or change Bank Plans</li>
            <li>Access to on-site full service ATMs to handle everyday banking transactions</li>
            <li>Apply for United Overseas Corporation Bank MasterCard credit cards</li>
            <li>Find information on and apply for loans, mortgages &amp; lines of credit</li>
            <li>Access to mutual fund investment advice available through partner referral</li>
        </ul>

	</div>

	<div class="each_bankn_serv odd">
		<h2>United Overseas Corporation Bank Telephone Banking</h2>
		<p>Access a wide range of financial services and products from anywhere you have access to a telephone, 24 hours a day, 7 days a week by calling us. In addition to your day-to-day banking, such as paying bills, transferring funds, obtaining account balances, and a listing of recent transactions, use telephone banking to:</p>
		<ul>
	        <li>Open new bank accounts</li>
	        <li>Change your contact information</li>
	        <li>Request a stop payment</li>
	        <li>Re-order cheques</li>
	        <li>Set up consolidated paper statements</li>
	        <li>Purchase travellers cheques and foreign currency</li>
	    </ul>
	</div>

	<div class="each_bankn_serv">
		<h2>United Overseas Corporation Bank ATM Banking</h2>
		<p>United Overseas Corporation Bank ATMs give you convenient access to cash withdrawals, up-to-the-minute account balances, deposits, transfers, electronic bill payments, and you can also get a printout of your most recent transactions.</p>
		<p>You can use your United Overseas Corporation Bank Debit Card to withdraw cash at United Overseas Corporation Bank Cash ATMs, any ATM with the Intera symbol and throughout the world at any ATM with the Maestro or Cirrus.</p>
		<p>All of our United Overseas Corporation Bank ATMs have audio capability to help customers with vision loss complete their banking transactions.</p>
		<p>Find the nearest one with the Branch/ATM Locator in our United Overseas Corporation Bank Mobile Banking app.</p>
	</div>

	<div class="each_bankn_serv odd">
		<h1 id="managing-money">Managing Money</h1>
		<h2>Direct Deposit</h2>
		<p>Save yourself a trip to the branch or ATM and get immediate access to your money with direct deposit. Enjoy automatic deposits of funds (e.g. your payroll deposit and government payments) into your personal bank accounts. To set up direct deposits for payroll, download the United Overseas Corporation Bank Direct Deposit form and follow the instructions.</p>

		<h4>Please Note:</h4>
		<p>All Federal Government payments by cheque, such as income tax refunds, GST rebates, Child Tax Benefit and Old Age Security are in the process of being phased out and will soon be available only by Direct Deposit.</p>

		<h4>To set up Direct Deposit for Government of Canada payments:</h4>
		<ul style="padding-left: 40px;">
        <li>Download the Government of Canada Direct Deposit form,</li>
        <li>Visit your local branch, or</li>
        <li>Speak to a representative at our Customer Contact Centre.</li>      
      </ul>
	</div>

	<div class="each_bankn_serv">
		<h2>Bill Payments</h2>
		<h4>Pre-Authorized Payments</h4>
		<p>With Pre-Authorized Payments, you can set up your bills to be automatically paid from your United Overseas Corporation Bank bank accounts on their due dates. You'll never miss a payment – even when you go on vacation.</p>
		<p>To set up this service you'll need your bank account number, institution number and branch transit. You can contact the billing company and follow the instructions that they provide or download the Personal Pre-Authorized Debit Plan form and follow the instructions.</p>

		<h4>epost view bills</h4>
		<p>With epost, you can have your bills, statements and notices sent directly to your United Overseas Corporation Bank Online Banking account and set up automatic payments from your personal bank accounts.</p>
	</div>

	<div class="each_bankn_serv odd">
		<h2>PowerSwitch</h2>
		<p>United Overseas Corporation Bank PowerSwitch is a free service that helps you transfer your Pre-Authorized Payments from a different financial institution and set up new Pre-Authorized Payments from your new United Overseas Corporation Bank chequing account and credit card.</p>
		<h4>Let PowerSwitch do the work for you</h4>

		<ul class="powerswitch">
	        <li>Set up new Pre-Authorized Payments.</li>
	        <li>Transfer your current automatic Pre-Authorized Payments to your new United Overseas Corporation Bank account. This could include everything from utility bills and condominium fees to gym memberships and more.</li>
	        <li>Notifies your Pre-Authorized Billers of your switch so you don’t have to.</li>
	        <li>Make changes to your United Overseas Corporation Bank credit card Pre-Authorized Payments due to lost, stolen, or expired credit cards in one location.</li>
	     </ul>

	     <h4>How to make the switch?</h4>
	     <ul>
        <li>Simply use United Overseas Corporation Bank Online Banking and provide the details of your Pre-Authorized Payment. PowerSwitch will do the rest for you.</li>
      </ul>
	</div>

	<div class="each_bankn_serv">
		<h2>Overdraft Services</h2>
		<p>Overdraft protection is a simple way to cover unexpected shortfalls in your account and avoid the potential embarrassment of a declined transaction or the cost and inconvenience of a returned cheque.</p>
		<p>Standard Overdraft Protection is best suited for you if your bank accounts tend to go into overdraft once a month or more.</p>
		<ul>
          <li>Coverage available from $500 to $2,500</li>
          <li>Your account must have monthly deposits and a positive balance at least once every 90 days</li>
          <li>A $4.00 monthly fee applies</li>
        </ul>

        <p>Occasional Overdraft Protection offers peace of mind if your accounts do not regularly go into overdraft.</p>
        <ul>
          <li>Coverage available from $500 to $2,500</li>
          <li>Your account must have monthly deposits and a positive balance at least once every 90 days</li>
          <li>There is no monthly fee. A $5.00 fee per transaction applies</li>
        </ul>

        <p>With Overdraft Transfer Service you can pre-arrange to have available funds transferred to your United Overseas Corporation Bank account from one of your other United Overseas Corporation Bank accounts, your United Overseas Corporation Bank credit card or your United Overseas Corporation Bank line of credit to cover any accidental overdraft. A fee of $5 per transfer applies.</p>
	</div>

	<div class="each_bankn_serv odd">
		<h2>United Overseas Corporation Bank Debit Card</h2>
		<p>The United Overseas Corporation Bank Debit Card and United Overseas Corporation Bank Debit Card for Business allow you to make purchases directly from your bank account in more ways. Interac Flash lets you pay faster for small purchases. And with Debit MasterCard, you can shop online or at international retailers, and pay directly from your bank account.</p>
		<p>Debit MasterCard: wherever Debit MasterCard is accepted you can use your debit card to shop online or by telephone. You can also take your card with you when you travel abroad. The Debit MasterCard feature allows you to shop in-store outside of Canada, wherever MasterCard is accepted</p>
		<p>Interac Flash: Our debit cards are enabled with Interac Flash, allowing you to pay quickly and securely in-store for purchases under $100. Simply hold your card to the terminal, no need to insert your card or enter your PIN.</p>

		<h4>Security</h4>
		<p>You can confidently shop with your United Overseas Corporation Bank Debit Card knowing you are protected from the unlikely event of unauthorized activity on your account. Our debit cards are equipped with the following security features:</p>
		<ul>
                <li>Embedded microchip that stores your information in a secure, encrypted format</li>
                <li>A single <i>Interac</i> Flash purchase can’t exceed $100, and there is also a $300 cumulative spend limit. Once this limit is reached, you’ll be asked to insert your card and enter your PIN to complete the transaction.</li>
                <li>Debit MasterCard is protected with the same safety and security features we offer on all our United Overseas Corporation Bank MasterCard credit cards.</li>
            </ul>
	</div>

	<div class="each_bankn_serv">
		<h2>PlanShare</h2>
		<h4>Your account. My account. Our account. One fee. Save on banking fees by sharing one Bank Plan including your joint and individual bank accounts.</h4>
		<p>With our unique PlanShare feature, you and your partner or spouse can save on banking fees by sharing one Bank Plan that includes all your individual and joint bank accounts. And guess what? You only pay a single monthly Plan fee.</p>

		<h4>Benefits</h4>
		<ul>
        <li>Open up to 20 accounts (joint and/or individual) under one Bank Plan for one monthly Plan fee</li>
        <li>Bank together while maintaining confidentiality on your individual accounts</li>
        <li>Personalize your Plan by conveniently organizing your accounts in the way that best suits you and your partner’s needs, including nicknaming your accounts (like "trip" for that vacation to Florida you’re planning)</li>
        <li>Easily transfer funds between your joint and individual accounts</li>
        <li>Available with Premium, Performance, AIR MILE and Plus Plans</li>
      </ul>
	</div>

	<div class="each_bankn_serv odd">
		<h2>Security</h2>
		<p>You can confidently shop with your United Overseas Corporation Bank Debit Card knowing you are protected from the unlikely event of unauthorized activity on your account.</p>
		<h4>Chip Technology</h4>
		<p>United Overseas Corporation Bank debit cards are more secure than ever thanks to chip technology. Chip debit cards contain an encrypted microchip that is extremely difficult to counterfeit. Your personal identification number (PIN) provides even more protection.</p>

		<h2>Account Statements</h2>
		<p>Track your spending, saving, lending and investing with ease. All United Overseas Corporation Bank statements give you the detailed information you need to take charge of your money.</p>
		<h4>eStatements</h4>
		<p>Stay on top of your finances with United Overseas Corporation Bank eStatements. eStatements are an exact replica of your paper statements and are securely accessible through Online Banking from anywhere at any time. See your transactions in online banking without having to wait for your paper statements to arrive. Plus, sign up for United Overseas Corporation Bank Alerts to know when your statement is ready for viewing. </p>
		<p>Securely view and store your personal banking, credit card, line of credit, and mutual fund account statements online</p>

		<h4>Consolidated Paper Statements</h4>
		<ul>
	       <li>Get a consolidated summary of all your account balances, including a detailed list of your transaction activity, reported separately for each account</li>
	       <li>Includes banking news, information and tips to improve your banking efficiency</li>
	       <li>A paper statement fee may apply</li>
	     </ul>


	    <h1 id="account-services">Account Services</h1>
	    <h2>Transfer Money</h2>
	    <p>Whether you're sending money across Canada or overseas to family for personal or business reasons, money transfers are simple and convenient with United Overseas Corporation Bank Money Transfer Services. Our reliable technology means you can send money confidently almost anywhere.</p>

	    <h4>Now you can send FREE, unlimited Interac e-Transfer transactions!</h4>
	    <p>All United Overseas Corporation Bank Personal Everyday Bank Plans now include unlimited Interac e-Transfer transactions**. Easily split bills and pay back friends &amp; family without using cheques or cash.</p>

        <p>For example, you can:</p>
     	<ul>
	        <li>Split bills with your partner or roommates</li>
	        <li>Pay a business or contractor for work they have done</li>
	        <li>Pay friends for sports pools and fantasy sports groups</li>
	    </ul>

	    <p>You can send an Interac e-Transfer transaction to anyone with an email address and a bank account. All you need is their email address. Money is deposited as soon as the recipient accepts the Interac e-Transfer transaction. Get started by signing in to United Overseas Corporation Bank Mobile or Online Banking today.</p>

	    <p>Sending money with Interac e-Transfer is simple. Need a refresher?</p>

	    <ul>
	      <li>In United Overseas Corporation Bank Mobile banking find ‘Send Interac e-Transfer’ in the ‘Send Money’ section of the main menu. In United Overseas Corporation Bank Online Banking, find ‘Interac e-Transfer’ under the ‘Payments &amp; Transfers’ tab. </li>
	      <li>Select an existing recipient or enter the email address for a new one.</li>
	      <li>Enter in security information to make sure your money only goes to who you want.</li>
	      <li>The recipient receives the email notice and their identity is validated.</li>
	      <li>The recipient chooses the deposit account and the money is deposited. It’s that easy! </li>
	    </ul>

	    
	</div>

	<div class="each_bankn_serv">
		<h2>Wire Transfers</h2>
	    <p>Our wire payment service is a quick, convenient and secure way to send and receive money.</p>

	    <ul>
	      <li>To send money, visit a United Overseas Corporation Bank branch with the recipient's name, address and bank account number, along with the name and address of their financial institution.</li>
	      <li>To receive money, provide the sender with your United Overseas Corporation Bank customer information.</li>
	    </ul>

	    <h4>Western Union Money Transfer</h4>
	    <p>We offer Western Union Money Transfers via Interac e-Transfer, through United Overseas Corporation Bank Online Banking </p>
	    <p>Available to personal banking customers, the Western Union®# Money Transfer service allows you to send money within Canada and abroad to more than 200 countries and territories connected to the Western Union network.</p>

	</div>



	<div class="each_bankn_serv odd">
		<h2>United Overseas Corporation Bank Alerts</h2>
		<p>Keep you informed and up-to-date on your personal banking transactions. Simply sign up for United Overseas Corporation Bank Alerts and get the information you need, when you need it. Receive alerts by email or to your smartphone to find out when:</p>
		<ul>
	        <li>Your account balance falls below your specified amount</li>
	        <li>A withdrawal greater than your specified amount is made</li>
	        <li>Deposits greater than your specified amount are made</li>
	        <li>Unusual activity on your United Overseas Corporation Bank Debit Card is suspected</li>
	        <li>Your eStatement is ready to be viewed</li>
	      </ul>
	</div>

	<div class="each_bankn_serv">
		<h1 id="travel-services">Travel Services</h1>
		<h2>Travel Insurance</h2>
		<p>Protect yourself, your family, your trip and even your luggage against emergencies, cancellations, interruptions and delays.</p>

		<h2>United Overseas Corporation Bank Prepaid Travel MasterCard</h2>
		<p>Get the convenience of cash, without having to carry cash. You can safely access funds wherever you are without interest charges.</p>

		<h2>Foreign Currency</h2>
		<p>Purchase more than 100 different currencies through United Overseas Corporation Bank to save on fees and surcharges when travelling.</p>
		<ul>
		    <li>Take advantage of fair exchange rates that are often better than airport and foreign exchange outlets</li>
		    <li>Avoid searching for banks and currency exchanges while abroad</li>
		</ul>
		<p>You can order up to $2,000 (Canadian) in U.S. dollars, British pounds sterling or Euros and have the funds delivered to you within 7 business days (courier fees apply).</p>




	</div>



</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>