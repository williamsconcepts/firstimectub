<?php

	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
	require_once '../files/connect.inc.php';
	

	$feedback = "";
	$feedback1 = "";
	$feedback2 = "";
	$feedback3 = "";
	$feedback4 = "";
	$feedback_text = "";
	$feedback_text2 = "";
	$sms_balance= "";

	$credited = "";
	$code_added = "";



	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}


	if(isset($_POST['update_acc_num'])&&
	 	isset($_POST['update_amount'])&&
	 	isset($_POST['update_transfer_code'])){


		if(empty($_POST['update_acc_num'])){
			$feedback = "Please enter account number";
		}else{

			$update_acc_num = sanitize_input($_POST['update_acc_num']);
			$update_amount = sanitize_input($_POST['update_amount']);
			$update_desc = sanitize_input($_POST['update_desc']);
			$update_transfer_code = sanitize_input($_POST['update_transfer_code']);

			$timestamp = time();
			$time = @date('H:i:s', $timestamp -(60*60));
			$date = @date('d-m-Y', $timestamp - (60*60));
			$date_time = $date." ".$time;

			$transaction_type = "Deposit";

			$query_check_acc_num = "SELECT * FROM `boa_acc_clients` WHERE `acc_number`='$update_acc_num'";
			$query_check_acc_num_run = mysql_query($query_check_acc_num);

			if (mysql_num_rows($query_check_acc_num_run)==1){

				if(!empty($_POST['update_transfer_code'])){
					$query_update = "UPDATE `boa_acc_clients` SET `transfer_code`='".mysql_real_escape_string($update_transfer_code)."' WHERE `acc_number`='$update_acc_num'";

					if($query_update_run = mysql_query($query_update)){


						$query_row = mysql_fetch_assoc($query_check_acc_num_run);
						$balance = $query_row['balance'];
						$firstname = $query_row['firstname'];
						$middlename = $query_row['middlename'];
						$lastname = $query_row['lastname'];
						$email = $query_row['email'];
						$phone1 = $query_row['phone1'];
						$acc_number = $query_row['acc_number'];

						$acc_number_first_two = substr($acc_number, 0, 2);
						$acc_number_last_three = substr($acc_number, 9, strlen($acc_number));
						$acc_number = $acc_number_first_two."*******".$acc_number_last_three;


						$feedback2 = "The transfer code has been set to $update_transfer_code.";
						$code_added = true;
					}else{
						$feedback3 = "The transfer code update failed. Please try again.";
					}
				}

				if(!empty($_POST['update_amount'])){

					$query_row = mysql_fetch_assoc($query_check_acc_num_run);
					$balance = $query_row['balance'];
					$firstname = $query_row['firstname'];
					$middlename = $query_row['middlename'];
					$lastname = $query_row['lastname'];
					$email = $query_row['email'];
					$phone1 = $query_row['phone1'];
					$acc_number = $query_row['acc_number'];

					$acc_number_history = $acc_number;

					$acc_number_first_two = substr($acc_number, 0, 2);
					$acc_number_last_three = substr($acc_number, 9, strlen($acc_number));
					$acc_number = $acc_number_first_two."*******".$acc_number_last_three;


					$transaction_id = rand(1111111111, 9999999999);

					$balance = str_replace("," ,"" , $balance);
					$balance = str_replace("$" ,"" , $balance);

					$update_amount_sanitized = str_replace("," ,"" ,$update_amount);
					$update_amount_sanitized = str_replace("$" ,"" ,$update_amount_sanitized);

					if(!is_numeric($update_amount_sanitized)){
						$feedback = "Please enter correct amount value.Eg $5,045.91";
					}else{

								// Adding $ and , where neccessary in update amount
						$update_amount_sanitized_dot_pos = strpos($update_amount_sanitized, ".", 0);
						$update_amount_sanitized_len = strlen($update_amount_sanitized);

						if($update_amount_sanitized_dot_pos == ""){
							$update_amount_sanitized_after_dot = ".00";
							$update_amount_sanitized_before_dot = substr($update_amount_sanitized, 0, $update_amount_sanitized_len);
						}else{
							$update_amount_sanitized_after_dot = substr($update_amount_sanitized, $update_amount_sanitized_dot_pos, $update_amount_sanitized_len);
							$update_amount_sanitized_before_dot = substr($update_amount_sanitized, 0, $update_amount_sanitized_dot_pos);
						}

						$update_amount_sanitized_before_dot_reversed = strrev($update_amount_sanitized_before_dot);

						if(strlen($update_amount_sanitized_before_dot) > 3){
							$update_amount_sanitized_with_comma = substr_replace($update_amount_sanitized_before_dot_reversed, ",", 3, 0);
						}else{
							$update_amount_sanitized_with_comma = $update_amount_sanitized_before_dot_reversed;
						}
						

						if(strlen($update_amount_sanitized_before_dot) > 6){
							$update_amount_sanitized_with_comma = substr_replace($update_amount_sanitized_with_comma, ",", 7, 0);
						}

						$update_amount_sanitized_before_dot_unreversed = strrev($update_amount_sanitized_with_comma).$update_amount_sanitized_after_dot;
						$update_amount = "$".$update_amount_sanitized_before_dot_unreversed;



								// Adding $ and , where neccessary in updated balance
						$updated_balance = $balance + $update_amount_sanitized;

						$updated_balance_dot_pos = strpos($updated_balance, ".", 0);
						$updated_balance_len = strlen($updated_balance);

						if($updated_balance_dot_pos == ""){
							$updated_balance_after_dot = ".00";
							$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_len);
						}else{
							$updated_balance_after_dot = substr($updated_balance, $updated_balance_dot_pos, $updated_balance_len);
							$updated_balance_before_dot = substr($updated_balance, 0, $updated_balance_dot_pos);
						}

						$updated_balance_before_dot_reversed = strrev($updated_balance_before_dot);

						if(strlen($updated_balance_before_dot) > 3){
							$updated_balance_with_comma = substr_replace($updated_balance_before_dot_reversed, ",", 3, 0);
						}else{
							$updated_balance_with_comma = $updated_balance_before_dot_reversed;
						}
						

						if(strlen($updated_balance_before_dot) > 6){
							$updated_balance_with_comma = substr_replace($updated_balance_with_comma, ",", 7, 0);
						}

						$updated_balance_before_dot_unreversed = strrev($updated_balance_with_comma).$updated_balance_after_dot;
						$updated_balance = "$".$updated_balance_before_dot_unreversed;

						


						$query_update = "UPDATE `boa_acc_clients` SET `balance`='".mysql_real_escape_string($updated_balance)."', `transaction_id`='$transaction_id' WHERE `acc_number`='$update_acc_num'";

						if($query_update_run = mysql_query($query_update)){
							$feedback1 = "Account balance credited with $update_amount. Total = $updated_balance";

							$query_set_history = "INSERT INTO `alert_history` VALUES('',
								'".mysql_real_escape_string($transaction_type)."',
								'".mysql_real_escape_string($update_desc)."',
								'".mysql_real_escape_string($update_amount)."',
								'$date',
								'$time',
								'$acc_number_history')";

							$query_set_history_run = mysql_query($query_set_history);

							$credited = true;

						}else{
							$feedback4 = "Account balance credit failed. Please try again";
						}

					}

				}

			}else{
				$feedback = "Account number is wrong";
			}

		}

	}



	if($credited == true){
		


				$body = <<<MAIL

<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%;">
<h4 style="margin-bottom:15px; text-align:right;">Transaction Notification</h4>
<p style="text-align:right;">$date_time</p>
</div>
<div style="clear:both;"></div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname $middlename $lastname, </p>
<h4 style="margin-bottom:10px;">United Overseas Corporation Bank Transaction Alert</h4>
<p>Please be informed that a Credit Transaction occurred on your bank account.</p>	


<table style="text-align: center; font-family: Arial, Helvetica, sans-serif; font-size: 13px; border-collapse: collapse; color: #222;width: 80%; margin: 30px auto;">
<caption style="font-size:17px;">Kindly find details of the transaction below</caption>

<thead>
<tr>
<th colspan="2" style="background-color:#e31930; color: #fff; text-align:center; padding: 5px; border: 1px solid #e31930;">Transaction Details</th>
</tr>
</thead>


<tbody>

<tr style="">
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Number </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$acc_number</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Account Name </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$firstname $middlename $lastname</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Description</td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$update_desc</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction ID </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$transaction_id</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Amount </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$update_amount</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Time </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$time</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Transaction Date </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$date</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Previous Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$balance</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Current Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance</td>
</tr>

<tr>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 30%; text-align:right; padding-right:5%;">Total Balance </td>
<td style="padding: 5px 5px; font-weight: bold; border: 1px solid #999; background-color:#E0E0E0; width: 70%; text-align:left; padding-left:5%;">$updated_balance</td>
</tr>

</tbody>
</table>

<h4 style="border-bottom:1px solid #222; padding-bottom: 40px;">Thank you for banking with United Overseas Corporation Bank</h4>

</div>

<div>
<p>This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="mailto:enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>

MAIL;


	
		$subject = 'United Overseas Corporation Bank Credit notification';
		$receiver = $firstname .' '. $middlename .' '. $lastname .'  <'. $email .'>';


		$headers = "From: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "Return-Path: United Overseas Corporation Bank Support <support@unocb.com>\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

		$sent = mail($receiver , $subject, $body, $headers, '-fsupport@unocb.com');

		
		$post_data=array(
		'sub_account'=>'3503_unocb',
		'sub_account_pass'=>'kompany',
		'action'=>'send_sms',
		'route'=>'1',
		'sender_id'=>'Unocb',
		'recipients'=>$phone1,
		'message'=>"Credit Alert!\r\nAcc#: $acc_number\r\nAmount: $update_amount\r\nDesc: $update_desc\r\nTime: $date_time\r\nTotal Bal: $updated_balance"
		);
		
		$api_url='http://cheapglobalsms.com/api_v1';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $api_url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if($response_code != 200)$response=curl_error($ch);
		curl_close($ch);

		if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
		else
		{
			$json=@json_decode($response,true);
			
			if($json===null)$msg="INVALID RESPONSE: $response"; 
			elseif(!empty($json['error']))$msg=$json['error'];
			else
			{
				$msg="SMS sent to ".$json['total']." recipient(s).";
				$sms_batch_id=$json['batch_id'];
			}
		}
		
		$feedback_text = $msg;
	}







	if($code_added == true){


		$body = <<<MAIL
<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="ECIB Logo"></a>
</div>

<div style="float:right; display:block; width:50%;text-align:right;">
<h4 style="margin-bottom:15px;">Transfer Authorisation Code</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname $middlename $lastname, </p>


<p>Your Transfer Authorisation Code is $update_transfer_code</p>

<h4>Thank you for banking with United Overseas Corporation Bank</h4>

<p>Best Regards,</p>
<p style="padding-bottom:40px; border-bottom:1px solid #222;">United Overseas Corporation Bank team</p>

</div>

<div>
<p  style="border-top:1px solid #222; padding-top: 40px;">This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>


MAIL;


	
		$subject = 'United Overseas Corporation Bank Transfer Authorization Code';
		$receiver = $firstname .' '. $middlename .' '. $lastname .'  <'. $email .'>';


		$headers = "From: United Overseas Corporation Bank support@unocb.com\r\n";
		$headers .= "Reply-to: United Overseas Corporation Bank support@unocb.com\r\n";
		$headers .= "Content-type: text/html\r\n";

		$sent = mail($receiver , $subject, $body, $headers, '-fsupport@unocb.com');

		
		$post_data=array(
		'sub_account'=>'3503_unocb',
		'sub_account_pass'=>'kompany',
		'action'=>'send_sms',
		'sender_id'=>'Unocb',
		'recipients'=>$phone1,
		'message'=>"Hello $firstname $middlename $lastname, your Transfer Authorization Code is $update_transfer_code."
		);
		
		$api_url='http://cheapglobalsms.com/api_v1';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $api_url);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if($response_code != 200)$response=curl_error($ch);
		curl_close($ch);

		if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
		else
		{
			$json=@json_decode($response,true);
			
			if($json===null)$msg="INVALID RESPONSE: $response"; 
			elseif(!empty($json['error']))$msg=$json['error'];
			else
			{
				$msg="SMS sent to ".$json['total']." recipient(s).";
				$sms_batch_id=$json['batch_id'];
			}
		}
		
		$feedback_text2 = $msg;

	}



	$post_data=array(
		'sub_account'=>'3503_unocb',
		'sub_account_pass'=>'kompany',
		'action'=>'account_info'
	);
	
	$api_url='http://cheapglobalsms.com/api_v1';

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $api_url);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
	$response = curl_exec($ch);
	$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	if($response_code != 200)$response=curl_error($ch);
	curl_close($ch);

	if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
	else
	{
		$json=@json_decode($response,true);
		
		if($json===null)$msg="INVALID RESPONSE: $response"; 
		elseif(!empty($json['error']))$msg=$json['error'];
		else
		{
			$msg="SMS Balance: ".$json['balance']." Units";
			$sms_balance=$msg;
		}
	}



?>

<div class="page_width">

	<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>

		<div id="update_account">
			
			<form action="update-account.php" method="post">

				<div style="color:#e31930; margin-top:20px;"><?php echo $feedback;?></div> 
				<div style="color:#006a4d; margin-top:20px;"><?php echo $feedback1;?></div>
				<div style="color:#006a4d; margin-top:20px;"><?php echo $feedback2;?></div>
				<div style="color:#e31930; margin-top:20px;"><?php echo $feedback3;?></div>
				<div style="color:#e31930; margin-top:20px;"><?php echo $feedback4;?></div>
				<div style="color:#006a4d; margin-top:20px;"><?php echo $feedback_text;?></div>
				<div style="color:#006a4d; margin-top:20px;"><?php echo $feedback_text2;?></div>
				<div style="color:#006a4d; margin-top:20px;"><?php echo $sms_balance;?></div>

				<label for="update_acc_num">Enter account number</label>
				<input type="text" name="update_acc_num" id="update_acc_num" class="page_inputs" value ="<?php if(isset($_POST['update_acc_num']) && $credited != true) {echo $_POST['update_acc_num'];} ?>" >

				<label for="update_amount">Enter amount to credit</label>
				<input type="text" name="update_amount" id="update_amount" class="page_inputs" value="<?php if(isset($_POST['update_amount']) && $credited != true) {echo $_POST['update_amount'];} ?>" >
				
				<label for="update_desc">Enter transaction description</label>
				<input type="text" name="update_desc" id="update_desc" class="page_inputs" value="<?php if(isset($_POST['update_desc']) && $credited != true) {echo $_POST['update_desc'];} ?>" >


				<label for="update_transfer_code">Enter transfer code</label>
				<input type="text" name="update_transfer_code" id="update_transfer_code" class="page_inputs" value="<?php if(isset($_POST['update_transfer_code']) && $code_added != true) {echo $_POST['update_transfer_code'];} ?>" >

				<input type="submit" id="update_submit" value="Send">
			</form>
			
		</div>
	</div>
			
</div>

<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>