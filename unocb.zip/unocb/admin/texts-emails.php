<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';



	$feedback = "";
	$feedback2 = "";
	$feedback3 = "";
	$feedback4 = "";
	$feedback_text = "";


	if(isset($_POST['client_phone_number'])&&
	 	isset($_POST['client_email'])&&
	 	isset($_POST['client_name'])&&
	 	isset($_POST['client_message'])){

		$client_phone_number = $_POST['client_phone_number'];
		$client_email = $_POST['client_email'];
		$client_name = $_POST['client_name'];
		$client_message = $_POST['client_message'];

		$client_message = str_replace("\n", "<br>", $client_message);


		if(!empty($_POST['client_phone_number'])){
		 
		    $post_data=array(
			'sub_account'=>'3503_unocb',
			'sub_account_pass'=>'kompany',
			'action'=>'send_sms',
			'route'=>'1',
			'sender_id'=>'Unocb',
			'recipients'=>$client_phone_number,
			'message'=>"Hello $client_name, $client_message"
			);
			
			$api_url='http://cheapglobalsms.com/api_v1';

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $api_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			
			$response = curl_exec($ch);
			$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($response_code != 200)$response=curl_error($ch);
			curl_close($ch);

			if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
			else
			{
				$json=@json_decode($response,true);
				
				if($json===null)$msg="INVALID RESPONSE: $response"; 
				elseif(!empty($json['error']))$msg=$json['error'];
				else
				{
					$msg="SMS sent to ".$json['total']." recipient(s).";
					$sms_batch_id=$json['batch_id'];
				}
			}
			
				$feedback_text = $msg;


		}else{
			$feedback2 = "";
		}



		if(!empty($_POST['client_email'])){

			$regex = "/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i";
			$bool = preg_match($regex, $client_email);

			if($bool == false){
				$feedback = "Email is invalid. Please enter a valid email.";
				
			}else{


				
				$body = <<<MAIL
<div style="background:#f4f4f4;width:100%;min-height:100%;padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%;margin:0px auto;padding:20px;background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corporation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%; text-align:right;">
<h4 style="margin-bottom:15px;">Transaction Notification</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">
<br>
<p>Hello $client_name,</p> 
<div>$client_message</div>
<h4>Thank you for banking with United Overseas Corporation Bank</h4>

Best Regards, <br>
United Overseas Corporation Bank team<br>

</div>

<div>
<p style="border-top:1px solid #222; padding-top: 40px;">This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corporation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corporation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corporation Bank. All rights reserved.</p>
</div>



</div>
MAIL;
				$subject = 'United Overseas Corporation Bank Notification';
				$recieverEmail = $client_email;


				$headers = "From: United Overseas Corporation Bank support@unocb.com\r\n";
				$headers .= "Reply-to: United Overseas Corporation Bank support@unocb.com\r\n";
				$headers .= "Content-type: text/html\r\n";

				$sent = mail($recieverEmail, $subject, $body, $headers, '-fsupport@unocb.com');


				$feedback4 = "Email sent";

			}

		}


			
	}else{
		$feedback = "";
		$feedback2 = "";
	}



?>
<div class="page_width">
	<div id="page_header">
		<h3>Texts and emails</h3>
	</div>

	<div id="texts_emails"> 
		<form action="texts-emails.php" method="post">
			<div class="neg_feedbk"><?php echo $feedback; ?></div>
			<div class="neg_feedbk"><?php echo $feedback2; ?></div>
			<div class="pos_feedbk"><?php echo $feedback3; ?></div>
			<div class="pos_feedbk"><?php echo $feedback4; ?></div>
			<div class="pos_feedbk"><?php echo $feedback_text; ?></div>

			<label for="client_name"><p>Enter client name</p></label>
			<input type="text" name="client_name" id="client_name" class="page_inputs"><br>

			<label for="client_phone_number"><p>Enter client phone number</p></label>
			<input type="text" name="client_phone_number" id="client_phone_number" class="page_inputs"><br>

			<label for="client_email"><p>Enter client email</p></label>
			<input type="text" name="client_email" id="client_email" class="page_inputs"><br>

			<label for="client_message"><p>Enter the message</p></label>
			<textarea name="client_message" id="client_message" cols="30" rows="10" class="page_inputs page_textarea"></textarea>
			<p id="contact_warning"></p>
			<input type="submit" id="message_submit" value="Send"><br><br>
		</form>
	</div>

</div>
<br>
<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>