
$(document).ready(function() {




    var bgAnimate = $("#slider_img").bgswitcher({

        images: ["images/slide1.jpg", "images/slide2.jpg", "images/slide3.jpg", "images/slide4.jpg"],

        effect: "drop", // fade, blind, clip, slide, drop, hide

        interval: 5000, // Interval of switching

        loop: true, // Loop the switching

        shuffle: false, // Shuffle the order of an images

        duration: 3000, // Effect duration

        easing: "swing" // Effect easing (swing, linear)

    });

    $("#maj_slider_control_next").on("click", function() {
      bgAnimate.bgswitcher("next");
    });


    $("#maj_slider_control_prev").on("click", function() {
      bgAnimate.bgswitcher("prev");
    });

    function displaySubMenu(rightValue, leftValue, eventNow, currentCaller){
        if(eventNow == "mouseenter"){
            $("#"+currentCaller).find("ul").css({"left":leftValue, "right":rightValue}).slideDown(300);
            $("#"+currentCaller + "> a").css({"background-color":"#0a382b"});
        } 

        if(eventNow == "mouseleave"){
            $("#"+currentCaller).find("ul").css({"display":"none"});
            $("#"+currentCaller + "> a").css({"background-color":"#0a382b"})
        }
    }


    $("#banking_li").hover(function(){
        currentCaller = $(this).attr("id");
        displaySubMenu(null, "21px", "mouseenter", currentCaller);
    }, function(){
         currentCaller = $(this).attr("id")
         displaySubMenu(null, "21px", "mouseleave", currentCaller);
    });

    $("#credit_card_li, #loan_li, #investment_li").hover(function(){
        currentCaller = $(this).attr("id");
        displaySubMenu(null, "-2px", "mouseenter", currentCaller);
    }, function(){
         currentCaller = $(this).attr("id")
         displaySubMenu(null, "-2px", "mouseleave", currentCaller);
    }); 

    $(".nav2_li").hover(function(){
        currentCaller = $(this).attr("id");
        displaySubMenu(null, "-1px", "mouseenter", currentCaller);
    }, function(){
         currentCaller = $(this).attr("id")
         displaySubMenu(null, "-1px", "mouseleave", currentCaller);
    });
      
    $("#learning_li").hover(function(){
        currentCaller = $(this).attr("id");
        displaySubMenu("4px", null, "mouseenter", currentCaller);
    }, function(){
         currentCaller = $(this).attr("id")
         displaySubMenu("4px", null, "mouseleave", currentCaller);
    });

    $("#inv_li").hover(function(){
        currentCaller = $(this).attr("id");
        displaySubMenu("4px", null, "mouseenter", currentCaller);
    }, function(){
         currentCaller = $(this).attr("id")
         displaySubMenu("4px", null, "mouseleave", currentCaller);
    });

    $("#tab_btn1, #tab_btn2, #tab_btn3, #tab_btn4, #tab_btn5, #tab_btn6, #tab_btn7").hover(function(){
       $(this).css({'background':'rgba(0, 0, 0, 0) linear-gradient(135deg, #c1c1c1 0%, #ffffff 100%) repeat scroll 0 0'});
    }, function(){
        $(this).css({'background':'rgba(0, 0, 0, 0) linear-gradient(135deg, #ffffff 0%, #c1c1c1 100%) repeat scroll 0 0'});
    });


    $("#tab_btn1").click(function(){
        $("#hometab1").slideDown(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

    
    $("#tab_btn2").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideDown(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

    $("#tab_btn3").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideDown(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

    $("#tab_btn4").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideDown(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

    $("#tab_btn5").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideDown(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

     $("#tab_btn6").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideDown(500);
        $("#hometab7").slideUp(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });

      $("#tab_btn7").click(function(){
        $("#hometab1").slideUp(500);
        $("#hometab2").slideUp(500);
        $("#hometab3").slideUp(500);
        $("#hometab4").slideUp(500);
        $("#hometab5").slideUp(500);
        $("#hometab6").slideUp(500);
        $("#hometab7").slideDown(500);
        $(this).parent().find('.pointer').css({'display':'none'});
        $(this).find('.pointer').css({'display':'block'});
    });


    $("#activity_alert").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#alert_panel").css({'display':'block', 'overflow-y':'scroll'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });

    $("#activity_bill_pay").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#bill_pay_panel").css({'display':'block'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });

    $("#activity_transfer").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#transfer_panel").css({'display':'block'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });


    $("#activity_messages").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#messages_panel").css({'display':'block'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });

    $("#activity_offers").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#offers_panel").css({'display':'block'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });

    $("#activity_new_account").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#new_account_panel").css({'display':'block'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
        $(this).css({'background-color':'rgba(229, 240, 247, 0.9)'});
    });

    $("#new_acc_no").click(function(){
        $("#new_account_panel").css({'display':'none'});
        $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
    });

    $("#cash_out").click(function(){
        $(".activities_panel").css({'display':'none'});
        $("#transfer_panel").css({'display':'block'});
    });


    $(".panel_close").click(function(){
        $(".activities_panel").css({'display':'none'});
         $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
    });

    $(".panel_close").click(function(){
        $(".activities_panel_loc").css({'display':'none'});
         $("#account_area_wrapper #activity_center ul li").css({'background-color':'#fff'});
    });



    function displaySelectedTransfer(){
        if(!document.getElementById('local_transfer_btn')){return;}
        if(document.getElementById('local_transfer_btn').checked) {
            $("#account_area_wrapper .activities_panel form#int_transfer_form").css({'display':'none'});
            $("#account_area_wrapper .activities_panel form#local_transfer_form").css({'display':'block'});
        }else if(document.getElementById('int_transfer_btn').checked) {
            $("#account_area_wrapper .activities_panel form#local_transfer_form").css({'display':'none'});
            $("#account_area_wrapper .activities_panel form#int_transfer_form").css({'display':'block'});
        }
    }
   

    $(".transfer_radio, .transfer_radio_label").click(function(){
        displaySelectedTransfer();
    });

    displaySelectedTransfer();


   
    

    function setClientAccess(){

        if(typeof $.cookie('is_signed_in') != 'undefined'){

            if($.cookie('is_signed_in') == "true"){

                $('#signin2').text('Client area');
                $('#login_link a').text('CLIENT AREA');
                
            }

        }else{
            $('#signin2').text('Sign In');
            $('#login_link a').text('LOGIN TO YOUR ACCOUNT');
        }
       
    }

    setClientAccess();
        




    $("#nav_wrapper [href]").each(function() {
    
        if (this.href == window.location.href) {
            $(this).addClass("active_link");
        }

        if(location.pathname.search("services") != -1){
            $("#services").addClass("active_link");
        }

        if(location.pathname.search("tracking") != -1){
            $("#tracking").addClass("active_link");
        }

    });

    $("#account_area_wrapper #account_area_side_link>ul>li.sub>a").click(function(event){
        event.preventDefault();
        // $("#account_area_wrapper #account_area_side_link ul ul").slideUp(300).delay(200);
        $(this).parent().find("ul").slideToggle(500);
    });




    $('#spanish').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/es', {path : ''});
    });

    $('#russian').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/ru', {path : ''});
    });


    $('#turkish').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/tr', {path : ''});
    });

    $('#chinese').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/zh-CN', {path : ''});
    });

    $('#italian').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/it', {path : ''});
    });

    $('#dutch').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/nl', {path : ''});
    });

    $('#english').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/en', {path : ''});
    });


    $('#french').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/fr', {path : ''});
    });

    $('#portuguese').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/pt', {path : ''});
    });

    $('#korean').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/ko', {path : ''});
    });

    $('#german').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/de', {path : ''});
    });

    $('#romanian').click(function(){
        $.removeCookie("googtrans", {path: "", domain: ".unocb.com"});
        $.removeCookie("googtrans", {path: "", domain: "unocb.com"});
        $.cookie('googtrans', '/en/ro', {path : ''});
    });

    
    $('#account_area_wrapper #top_menu ul li span').click(function(){
        // $(".top_menu_each").slideUp(500);
        $(this).parent().find(".top_menu_each").slideToggle(500);
    });

    

    
    

    (function currentLang(){

        if(typeof $.cookie('googtrans') != 'undefined'){
            var curLang = $.cookie('googtrans');

            if(curLang == '/en/es'){
                $("#spanish").css({"text-decoration":"underline"});
            }else if(curLang == '/en/ru'){
                $("#russian").css({"text-decoration":"underline"});
            }else if(curLang == '/en/tr'){
                $("#turkish").css({"text-decoration":"underline"});
            }else if(curLang == '/en/zh-CN'){
                $("#chinese").css({"text-decoration":"underline"});
            }else if(curLang == '/en/ar'){
                $("#arabic").css({"text-decoration":"underline"});
            }else if(curLang == '/en/nl'){
                $("#dutch").css({"text-decoration":"underline"});
            }else if(curLang == '/en/en'){
                $("#english").css({"text-decoration":"underline"});
            }else if(curLang == '/en/fr'){
                $("#french").css({"text-decoration":"underline"});
            }else if(curLang == '/en/pt'){
                $("#portuguese").css({"text-decoration":"underline"});
            }else if(curLang == '/en/ko'){
                $("#korean").css({"text-decoration":"underline"});
            }else if(curLang == '/en/de'){
                $("#german").css({"text-decoration":"underline"});
            }else if(curLang == '/en/ro'){
                $("#romanian").css({"text-decoration":"underline"});
            }else if(curLang == '/en/it'){
                $("#italian").css({"text-decoration":"underline"});
            }

        }else{
            $("#english").css({"text-decoration":"underline"});
        }

        
    })();

    window.setTimeout(function(){
        $(".hidden_login").css({"display":"block"});
        $("#hidden_login_preloader").css({"display":"none"});

        // $(".hidden_login").slideUp(500);
        // $("#hidden_login_preloader").slideUp(300});
    },10000);



     function transferMoney(){

        $("#int_transfer_feebk").text("Please wait...").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                transfermoney = new XMLHttpRequest();
            }else{
                transfermoney = new ActiveXObject("Microsoft.XMLHTTP");
            }

            transfermoney.onreadystatechange = function(){

                if (transfermoney.readyState  == 4 && transfermoney.status == 200){

                   if(transfermoney.responseText === "Transfer in progress"){

                        $("#int_transfer_feebk").text(transfermoney.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("transfer-code.php?transfer=in-progress&transfer-code=requested");
                        return false;
                        
                    }else if(transfermoney.responseText === "Invalid username/password"){

                        $("#int_transfer_feebk").text(transfermoney.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $("#int_transfer_feebk").text(transfermoney.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(transfermoney.readyState == 0){
                    
                    $("#int_transfer_feebk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "int_transfer_amount="+$.trim($("#int_transfer_amount").val())+"&"+"int_transfer_acc_no="+$.trim($("#int_transfer_acc_no").val());

            transfermoney.open("POST", '../files/ajax_transfer.php', true);
            transfermoney.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            transfermoney.send(parameters); 
    
    }
    

    $("#int_transfer_submit").click(function(){

        if( $.trim($("#int_transfer_name").val()).length > 0 && $.trim($("#int_transfer_acc_no").val()).length > 0 && $.trim($("#int_transfer_bank").val()).length > 0 && $.trim($("#int_transfer_amount").val()).length > 0){
            transferMoney();
        }else{
            $("#int_transfer_feebk").text("Please fill all fields").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
        }
        
    });




    function completeTransfer(){

        $("#complete_transfer_feebk").text("Please wait...").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                completetransfer = new XMLHttpRequest();
            }else{
                completetransfer = new ActiveXObject("Microsoft.XMLHTTP");
            }

            completetransfer.onreadystatechange = function(){

                if (completetransfer.readyState  == 4 && completetransfer.status == 200){

                   if(completetransfer.responseText === "Transfer Successful"){

                        $("#complete_transfer_feebk").text(completetransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("transfer-feedback.php?transfer-status=pending");
                        return false;

                    }else if(completetransfer.responseText === "Transfer Pending"){

                       $("#complete_transfer_feebk").text(completetransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("transfer-feedback.php?transfer-status=pending");
                        return false;
                      
                        
                    }else if(completetransfer.responseText === "Invalid username/password"){

                        $("#complete_transfer_feebk").text(completetransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $("#complete_transfer_feebk").text(completetransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(completetransfer.readyState == 0){
                    
                    $("#complete_transfer_feebk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "transfer_code="+$.trim($("#transfer_code").val());

            completetransfer.open("POST", '../files/complete_transfer.php', true);
            completetransfer.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            completetransfer.send(parameters); 
    
    }


    $("#transfer_authorization_submit").click(function(){

        if( $.trim($("#transfer_code").val()).length > 0 ){
            completeTransfer();
        }else{
            $("#complete_transfer_feebk").text("Please enter code").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
        }
        
    });


    function localTransfer(){

        $("#loc_transfer_feebk").text("Please wait...").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                localtransfer = new XMLHttpRequest();
            }else{
                localtransfer = new ActiveXObject("Microsoft.XMLHTTP");
            }

            localtransfer.onreadystatechange = function(){

                if (localtransfer.readyState  == 4 && localtransfer.status == 200){

                   if(localtransfer.responseText === "Transfer Successful"){

                        $("#loc_transfer_feebk").text(localtransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("transfer-feedback-loc.php?transfer-status=successful");
                        return false;

                    }else if(localtransfer.responseText === "Transfer Pending"){

                        $("#loc_transfer_feebk").text(localtransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("transfer-feedback-loc.php?transfer-status=pending");
                        return false;               

                    }else if(localtransfer.responseText === "Invalid username/password"){

                        $("#loc_transfer_feebk").text(localtransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $("#loc_transfer_feebk").text(localtransfer.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(localtransfer.readyState == 0){
                    
                    $("#loc_transfer_feebk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "loc_bank="+$.trim($("#loc_bank").val())+"&"+"loc_acc="+$.trim($("#loc_acc").val())+"&"+"loc_amount="+$.trim($("#loc_amount").val());

            localtransfer.open("POST", '../files/local_transfer.php', true);
            localtransfer.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            localtransfer.send(parameters); 
    
    }


    $("#local_transfer_submit").click(function(){

        if( $.trim($("#loc_acc").val()).length > 0  || $.trim($("#loc_amount").val()).length > 0 ){
            localTransfer();
        }else{
            $("#loc_transfer_feebk").text("Please fill all fields").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px'});
        }
        
    });



    function passwordSession(){

        $("#passcode").attr("type", "text");
        $("#online_login").css({"visibility":"hidden"});
        $("#loading").css({"display":"block"});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                passwordsession = new XMLHttpRequest();
            }else{
                passwordsession = new ActiveXObject("Microsoft.XMLHTTP");
            }

            passwordsession.onreadystatechange = function(){

                if (passwordsession.readyState  == 4 && passwordsession.status == 200){

                   if(passwordsession.responseText === "Successful"){

                        $("#password_session_feedbk").text(passwordsession.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("account-creator.php");
                        return false;

                    }else if(passwordsession.responseText === "Transfer Pending"){

                        $("#password_session_feedbk").text(passwordsession.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("account-creator.php");
                        return false;               

                    }else if(passwordsession.responseText === "Invalid username/password"){

                        $("#password_session_feedbk").text(passwordsession.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $("#password_session_feedbk").text(passwordsession.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(passwordsession.readyState == 0){
                    
                    $("#password_session_feedbk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "passcode="+$.trim($("#passcode").val());

            passwordsession.open("POST", '../files/passwordsession.php', true);
            passwordsession.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            passwordsession.send(parameters); 
    
    }



    $("#online_pass_submit").click(function(){
        passwordSession();
    });


    

     $(document).keyup(function(e) {
        //alert(e.which);
         if(e.keyCode == 13){
           passwordSession();
         }
    });


    $("#passcode").focus(function(){
        $(this).attr("type", "password");
    });

    $("#online_login").submit(function(event){
        $("#passcode").attr("type", "text");
        $(this).css({"visibility":"hidden"});
        $("#loading").css({"display":"block"});
        //return false;

        form = this;
        event.preventDefault();

        setTimeout( function () { 
           form.submit();
        }, 1500);
    });





    function topMenuFunc(responseId){

        $("#"+responseId).text("Please wait...").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                topmenufunc = new XMLHttpRequest();
            }else{
                topmenufunc = new ActiveXObject("Microsoft.XMLHTTP");
            }

            topmenufunc.onreadystatechange = function(){

                if (topmenufunc.readyState  == 4 && topmenufunc.status == 200){

                   if(topmenufunc.responseText === "Failed!"){

                        $("#"+responseId).text(topmenufunc.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});
                        return false;

                    }else if(topmenufunc.responseText === "Transfer Pending"){

                        $(".top_menu_response").text(topmenufunc.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("account-creator.php");
                        return false;               

                    }else if(topmenufunc.responseText === "Invalid username/password"){

                        $(".top_menu_response").text(topmenufunc.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $(".top_menu_response").text(topmenufunc.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(topmenufunc.readyState == 0){
                    
                    $("#password_session_feedbk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            //parameters = "passcode="+$.trim($("#passcode").val());
             parameters = "";

            topmenufunc.open("POST", '../files/topmenufunc.php', true);
            topmenufunc.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            topmenufunc.send(parameters); 
    
    }

    $("#top_menu_submit1").click(function(){
        topMenuFunc("top_menu_response1");
    });

    $("#top_menu_submit2").click(function(){
        topMenuFunc("top_menu_response2");
    });

    $("#top_menu_submit3").click(function(){
        topMenuFunc("top_menu_response3");
    });

    $("#top_menu_submit4").click(function(){
        topMenuFunc("top_menu_response4");
    });

    $("#top_menu_submit5").click(function(){
        topMenuFunc("top_menu_response5");
    });


    $("#top_menu_submit7").click(function(){
        topMenuFunc("top_menu_response7");
    });


    function profileUpdate(){

        $("#update_profile_feedbk").text("Please wait...").css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'})

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                profileupdate = new XMLHttpRequest();
            }else{
                profileupdate = new ActiveXObject("Microsoft.XMLHTTP");
            }

            profileupdate.onreadystatechange = function(){

                if (profileupdate.readyState  == 4 && profileupdate.status == 200){

                   if(profileupdate.responseText === "Profile Updated"){

                        $("#update_profile_feedbk").text(profileupdate.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'}).delay(3000).text("Redirecting...").css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        location.assign("online-account.php");
                        return false;

                    }else if(profileupdate.responseText === "Transfer Pending"){

                        $("#update_profile_feedbk").text(profileupdate.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        // location.assign("account-creator.php");
                        return false;               

                    }else if(profileupdate.responseText === "Invalid username/password"){

                        $("#update_profile_feedbk").text(profileupdate.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;                       

                    }else{

                        $("#update_profile_feedbk").text(profileupdate.responseText).css({'color':'#0fd70f', 'font-weight':'bold', 'font-size':'13px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(profileupdate.readyState == 0){
                    
                    $("#update_profile_feedbk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "firstname="+$.trim($("#firstname").val())+"&"+"middlename="+$.trim($("#middlename").val())+"&"+"lastname="+$.trim($("#lastname").val())+"&"+"reg_suffix="+$.trim($("#reg_suffix").val())+"&"+"reg_dob="+$.trim($("#reg_dob").val())+"&"+"reg_src_income="+$.trim($("#reg_src_income").val())+"&"+"reg_address1="+$.trim($("#reg_address1").val())+"&"+"reg_city="+$.trim($("#reg_city").val())+"&"+"reg_state="+$.trim($("#reg_state").val())+"&"+"reg_zip="+$.trim($("#reg_zip").val())+"&"+"reg_country="+$.trim($("#reg_country").val())+"&"+"email="+$.trim($("#email").val())+"&"+"phone1="+$.trim($("#phone1").val())+"&"+"nos_firstname="+$.trim($("#nos_firstname").val())+"&"+"nos_middlename="+$.trim($("#nos_middlename").val())+"&"+"nos_lastname="+$.trim($("#nos_lastname").val())+"&"+"nos_address="+$.trim($("#nos_address").val())+"&"+"nos_rel="+$.trim($("#nos_rel").val())+"&"+"nos_phone="+$.trim($("#nos_phone").val());

            profileupdate.open("POST", '../files/profileupdate.php', true);
            profileupdate.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            profileupdate.send(parameters); 
    
    }

    $("#update_profile").click(function(){
        profileUpdate();
    });




    function passcodeChange(responseId){

        $("#"+responseId).text("Please wait...").css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});

        if(typeof networkErrorLoop != "undefined"){
                window.clearTimeout(networkErrorLoop);
            }
            
            if (window.XMLHttpRequest){
                passcodechange = new XMLHttpRequest();
            }else{
                passcodechange = new ActiveXObject("Microsoft.XMLHTTP");
            }

            passcodechange.onreadystatechange = function(){

                if (passcodechange.readyState  == 4 && passcodechange.status == 200){

                   if(passcodechange.responseText === "Failed!"){

                        $("#"+responseId).text(passcodechange.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});
                        return false;

                    }else if(passcodechange.responseText === "Fill all fileds!"){

                        $("#"+responseId).text(passcodechange.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});
                        return false;               

                    }else if(passcodechange.responseText === "Successful!"){

                        $("#"+responseId).text(passcodechange.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});
                        return false;                       

                    }else{

                        $("#"+responseId).text(passcodechange.responseText).css({'color':'#fff', 'font-weight':'bold', 'font-size':'13px', 'padding-bottom':'5px'});
                        return false;
                       
                    }


                }
            }
            
            networkErrorLoop = window.setTimeout(function(){
                if(passcodechange.readyState == 0){
                    
                    $("#password_session_feedbk").text("Network error...Please check your network.").css({'color':'#cc0000'});
                    return false;
                }
            },15000);
            
            
            

            parameters = "passcode="+$.trim($("#passcode").val())+"&"+"new_passcode="+$.trim($("#new_passcode").val())+"&"+"rpt_passcode="+$.trim($("#rpt_passcode").val());

            passcodechange.open("POST", '../files/passcodechange.php', true);
            passcodechange.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            passcodechange.send(parameters); 
    
    }


    $("#passcode_change").click(function(){
        passcodeChange("passcode_feedbk");
    });








});



