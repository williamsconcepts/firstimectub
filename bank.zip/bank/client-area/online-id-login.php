<?php
ob_start( );
session_start();
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
	require_once '../files/connect.inc.php';

	$feedback = "";
	$feedback1 = "";

	if (isset($_SESSION['online_id_session']) && isset($_SESSION['passcode_session'])) {
		header('location: online-account.php');
	}

	if (isset($_GET['identifier']) && $_GET['identifier'] == 'empty'){
		$feedback = "Online ID/Passcode empty";
	}else if(isset($_GET['identifier']) && $_GET['identifier'] == 'false'){
		$feedback = "Online ID/Passcode don't match";
	}else if(isset($_GET['session']) && $_GET['session'] == 'false'){
		$feedback = "You don't have an existing session";
	}else if(isset($_GET['email-status']) && $_GET['email-status'] == 'unverified'){
		$feedback = "Your email address is unverified. Please log into your email and verify your email.";
		$feedback1 = "Without verifying your email you cannot log into your account.";
	}



	if(isset($_POST['online_id'])){

		if(!empty($_POST['online_id'])){

			$online_id = $_POST['online_id'];

			$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`='$online_id' ";
				
				$query_run = mysql_query($query);
				if (mysql_num_rows($query_run)>=1) {
					$query_row = mysql_fetch_assoc($query_run);
					$firstname = $query_row['firstname'];

					$online_id = $_POST['online_id'];
					$_SESSION['online_id_session'] = $online_id;
					header('location: pass-creator.php');
					return false;
				}else{
					$feedback = "Online ID does not exist";
				}

			

		}else{
			$feedback = "Online ID is empty";
		}

			

	}else{

	}


?>
<div class="page_width">
	<div id="personal_sub" class="sub_pages">
		<div class="strip"></div>
		<h4 id="login_feedback"><?php echo $feedback;?></h4>
		<h4 id="login_feedback"><?php echo $feedback1;?></h4>

		<div id="loading"><img src="../images/loading.gif"></div>
		<br>
		<br>
		<form action="online-id-login.php" method="post" id="online_login" class="left_float">
			<label for="online_id">Online ID</label>
			<input type="text" name="online_id" class="sign_in_input" id="online_id" placeholder="Online ID"  value="<?php if(isset($_POST['online_id'])) {echo $_POST['online_id'];} ?>" >
			<br>
			<input type="checkbox" name="sign_in_checkbox" id="sign_in_checkbox" class="left_float">
			<label for="sign_in_checkbox" class="left_float" id="sign_in_checkbox_label">Save Online ID</label>
			<div class="clear"></div>
			
			<br>
			<!-- <label for="passcode">Passcode</label>
			<input type="text" name="passcode" class="sign_in_input left_float" id="passcode" placeholder="Passcode">
			<a href="#" id="forgot_passcode" class="sign_in_sfont left_float">Forgot Passcode</a> -->
			<div class="clear"></div>
			<input type="submit" value="Sign In" id="sign_in_submit">
			<br>
		</form>

		<div id="online_login_aside" class="left_float">
			<h3>Sign-in help</h3>
			<a href="#">Forgot your Online ID?</a>
			<a href="">Forgot your Passcode?</a>

			<h3>Not using Online Banking?</h3>
			<a href="online-account-opening.php" class="">Enroll now</a>
		</div>

		<div class="clear"></div>

	</div>
</div>
<br>
<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>