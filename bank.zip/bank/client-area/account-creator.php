<?php

	$timestamp = time();
	$page_name = "account-".md5($timestamp).".php";
	$page_cotent = '<?php
ob_start( );
session_start();
	require_once "../files/head_section2.php";
	require_once "../files/navigation2.php";
	require_once "../files/connect.inc.php";

	$feedback = "";
	$online_id = "";
	$passcode = "";
	$logged_in = "";

	$_SESSION["account_page"] = basename($_SERVER["PHP_SELF"]);

	if (isset($_SESSION["online_id_session"])) {
		$online_id = $_SESSION["online_id_session"];
	}

	if (isset($_SESSION["passcode_session"])) {
		$passcode = $_SESSION["passcode_session"];
	}


	function sanitize_input($data){
	   $data = trim($data);
	   $data = stripslashes($data);
	   $data = htmlspecialchars($data);
	   return $data;
	}



	if($online_id != "" && $passcode != "") {


		if($online_id == "" && $passcode == ""){

			header("location: creator.php?identifier=empty");
			return false;
		}else{

			if(isset($_POST["passcode"])){
				$online_id = sanitize_input($online_id);
				$passcode = sanitize_input($_POST["passcode"]);
			}

			

			$query = "SELECT *  FROM `boa_acc_clients` WHERE `online_id`=\"$online_id\" AND `passcode`=\"$passcode\"";
			
			$query_run = mysql_query($query);
			if (mysql_num_rows($query_run)>=1) {

				$query_row = mysql_fetch_assoc($query_run);
				$firstname = $query_row["firstname"];
				$middlename = $query_row["middlename"];
				$lastname = $query_row["lastname"];
				$acc_type = $query_row["acc_type"];
				$acc_number = $query_row["acc_number"];
				$balance = $query_row["balance"];
				$phone1 = $query_row["phone1"];
				$online_id = $query_row["online_id"];

				$nos_firstname = $query_row["reg_nos_firstname"];
				$nos_middlename = $query_row["reg_nos_middlename"];
				$nos_lastname = $query_row["reg_nos_lastname"];

				$passport_name = $query_row["passport_name"];
				$signature_name = $query_row["signature_name"];
				$email_status = $query_row["email_status"];

				$transfer_message = $query_row["transfer_message"];

				if($email_status == "Verified"){
					$_SESSION["online_id_session"] = $online_id;
					$_SESSION["passcode_session"] = $passcode;


					if (@file_exists($_SESSION["password_page"])) {
						unlink($_SESSION["password_page"]);
						unset($_SESSION["password_page"]);
					}

					if (@file_exists($_SESSION["login_page"])) {
						unlink($_SESSION["login_page"]);
						unset($_SESSION["login_page"]);
					}


					if(isset($_POST["sign_in_checkbox"])){
						$cookie_name = "keep_me_signed_in";
						$cookie_value = "true";
						setcookie($cookie_name, $cookie_value, time() + (86400 * 100), "/");
					}

					$cookie_name2 = "is_signed_in";
					$cookie_value2 = "true";
					setcookie($cookie_name2, $cookie_value2, time() + (86400 * 100), "/");

					$logged_in = true;
					header("location: online-account.php");
					
				}else{
					session_destroy();
					header("location: creator.php?email-status=unverified");
					return false;
				}

				

			}else{

				if (file_exists($_SESSION["password_page"])) {
					unlink($_SESSION["password_page"]);
					unset($_SESSION["password_page"]);
				}

				unset($_SESSION["online_id_session"]);
				unset($_SESSION["passcode_session"]);
				header("location: creator.php?identifier=false");
				return false;
			}

		}

	}else{

		if (file_exists($_SESSION["password_page"])) {
			unlink($_SESSION["password_page"]);
			unset($_SESSION["password_page"]);
		}

		unset($_SESSION["online_id_session"]);
		unset($_SESSION["passcode_session"]);
		header("location: creator.php?identifier=false");
		return false;

	}





?>

<?php
	if($logged_in == true){
?>
<div class="page_width account_area_wrap">
	<div id="personal_sub" class="sub_pages">

		<div id="account_area_wrapper">

			<div id="welcome" class="left_float">
				<form action="../files/sign_out.php" method="post"> <input type="submit" id="sign_out" name="sign_out" value="Sign out"></form>
				<p><strong>Hello,</strong> <?php echo "$firstname"?></p>

				<?php
					if (isset($_GET["transfer-status"]) && $_GET["transfer-status"] == "pending" ){

						echo \'<p style="color:#e31930; text-align: center; margin-top:40px;">Transfer incomplete - Money failed to reach destination account. Contact <a href="mailto:info@stalliontrustb.com" target="_blank" style="color: #005f8b;">info@stalliontrustb.com</a> for more details.</p>\';
					}
				?>


			</div>

			<div id="signature" class="left_float" style="background: transparent url(../acc-images/<?php echo "$signature_name" ?>) no-repeat center center/auto;">
				
			</div>

			<div id="passport" class="left_float" style="background: transparent url(../acc-images/<?php echo "$passport_name" ?>) no-repeat center top/auto;">
				
			</div>

			<div class="clear"></div>
			
			<div id="account_area" class="left_float">

				<table width="100%">
				
							<tr>
								<th colspan="2">Stated below are your account details.</th>
							</tr>

							
							<tr>
								<td>Name</td>
								<td><?php echo "$firstname $middlename $lastname";?></td>
							</tr>

							<tr>
								<td>Account Type</td>
								<td><?php echo "$acc_type";?></td>
							</tr>						

							<tr>
								<td>Account Number</td>
								<td><?php echo "$acc_number";?></td>
							</tr>

							<tr>
								<td>Account Balance</td>
								<td><?php echo "$balance";?></td>
							</tr>

							<tr>
								<td>Phone Number</td>
								<td><?php echo "$phone1";?></td>
							</tr>

							<tr>
								<td>Online ID</td>
								<td><?php echo "$online_id";?></td>
							</tr>

							<tr>
								<td>Next of Kin</td>
								<td><?php echo "$nos_firstname $nos_middlename $nos_lastname";?></td>
							</tr>
					</table>
				
			</div>

			<div id="activity_center" class="left_float">
				<h2>Activity center</h2>

				<ul>
					<li id="activity_alert"><p style="margin-left:-8px;">Alerts/History</p></li>
					<li id="activity_bill_pay" ><p>Bill pay</p></li>
					<li id="activity_transfer" ><p>Transfer</p></li>

					<br>
					<li id="activity_messages" ><p>Messages</p></li>
					<li id="activity_offers" ><p>Special Offers</p></li>
					<li id="activity_new_account" ><p>Open an account</p></li>
				</ul>

			</div>

			<div class="clear"></div>

			
			<div class="activities_panel" id="alert_panel">
				<h3>Alerts/History</h3>
				<div class="panel_close">Close</div>

				<table id="alerts_history_table" width="100%">
				
					<tr>
						<!-- <th>S/no</th> -->
						<th>Transaction Type</th>
						<th>Description</th>
						<th>Amount</th>
						<th>Date</th>
						<th>Time</th>
					</tr>

					<?php

						$num_rows = "SELECT COUNT(*) c FROM `alert_history`";
						$num_rows_run = mysql_query($num_rows);
						$rows = mysql_fetch_assoc($num_rows_run);
						$rows["c"];

						for ($id=$rows["c"]; $id > 0; $id--) {

							$query_alert_history = "SELECT *  FROM `alert_history` WHERE `id`=\"$id\" && `acc_number`=\"$acc_number\"";
							$query_alert_history_run = mysql_query($query_alert_history);

							if (mysql_num_rows($query_alert_history_run)==1) {

								$query_alert_history_row = mysql_fetch_assoc($query_alert_history_run);
								$id_row = $query_alert_history_row["id"];
								$transaction_type = $query_alert_history_row["transaction_type"];
								$description = $query_alert_history_row["description"];
								$amount = $query_alert_history_row["amount"];
								$date = $query_alert_history_row["date"];
								$time = $query_alert_history_row["time"];

								echo "<tr>
										<td style=\'width:10%;\'> $transaction_type </td>
										<td style=\'width:40%;\'> $description </td>
										<td style=\'width:25%;\'> $amount </td>
										<td style=\'width:10%;\'> $date </td>
										<td style=\'width:10%;\'> $time </td>

									 </tr>";


							}		
						}

					?>

				</table>

				<!-- <h4>Sorry, you have no alerts at the moment.</h4> -->
			</div>

			<div class="activities_panel" id="bill_pay_panel">
				<h3>Bill Pay</h3>
				<div class="panel_close">Close</div>
				<form action="" method="post">
					<label for="bill_name">Bill name</label>
					<input type="text" class="bill_pay_input" id="bill_name">

					<label for="bill_id">Bill ID</label>
					<input type="text" class="bill_pay_input" id="bill_id">

					<label for="bill_amount">Amount</label>
					<input type="text" class="bill_pay_input" id="bill_amount">

					<div id="bill_pay_submit">Pay now</div>
					<!-- <input type="submit" value="Pay now" id="bill_pay_submit"> -->
				</form>
			</div>


			
			<div class="activities_panel" id="transfer_panel">
				<h3>Transfer</h3>
				<div class="panel_close">Close</div>

				<div id="int_transfer_feebk" class="transfer_fdbk"></div>
				<div id="loc_transfer_feebk" class="transfer_fdbk"></div>
				
				<form id="transfer_type_selector">
					<p id="transfer_sub">Transfer type</p id="transfer_type">	
							
					<input type="radio" class="transfer_radio" name="transfer_type" id="local_transfer_btn">
					<label for="local_transfer_btn" class="transfer_radio_label">Local Transfer</label>

					<input type="radio" class="transfer_radio" name="transfer_type" id="int_transfer_btn">
					<label for="int_transfer_btn" class="transfer_radio_label">International Transfer</label>
				</form>




				<form action="" method="post" id="local_transfer_form">

					<div class="loc_input_section left_float">
						<label for="loc_bank">Beneficiary bank name</label>
						<input type="text" class="local_transfer_input" id="loc_bank">

						<!-- <select name="loc_bank" id="loc_bank" class="local_transfer_input">
							<option value="SCB">SCB</option>
								<option value="Other Banks">Other Banks</option>
						</select> -->

						<label for="loc_acc">Beneficiary account number</label>
						<input name="loc_acc" id="loc_acc" type="text" class="local_transfer_input">

						<label for="loc_name">Beneficiary account name</label>
						<input name="loc_name" id="loc_name" type="text" class="local_transfer_input">
					</div>

					<div class="loc_input_section left_float">
						<label for="loc_routing">Beneficiary routing number</label>
						<input name="loc_routing" id="loc_routing" type="text" class="local_transfer_input">

						<label for="loc_amount">Amount to be transfered</label>
						<input name="loc_amount" id="loc_amount" type="text" class="local_transfer_input">
					</div>

					<div id="local_transfer_submit">Transfer</div>
					<!-- <input type="submit" value="Pay now" id="transfer_submit"> -->
				</form>


				<form action="" method="post" id="int_transfer_form">

					<div class="int_input_section left_float">
						<label for="int_transfer_name">Beneficiary\'s name</label>
						<input type="text" class="int_transfer_input" id="int_transfer_name">

						<label for="int_transfer_acc_no">Account number</label>
						<input type="text" class="int_transfer_input" id="int_transfer_acc_no">

						<label for="int_transfer_bank">Bank name</label>
						<input type="text" class="int_transfer_input" id="int_transfer_bank">
					</div>
					
					
					<div class="int_input_section left_float">
						<label for="int_transfer_address">Bank address</label>
						<input type="text" class="int_transfer_input" id="int_transfer_address">

						<label for="int_transfer_city">Bank city</label>
						<input type="text" class="int_transfer_input" id="int_transfer_city">

						<label for="int_transfer_country">Bank country</label>
						<select name="" id="int_transfer_country" class="int_transfer_input">
							<?php require_once "../files/country_list.php";?>
						</select>
					</div>

						

					<div class="int_input_section left_float">
						<label for="int_transfer_postcode">Routing number</label>
						<input type="text" class="int_transfer_input" id="int_transfer_postcode">

						<label for="int_transfer_swift">Swift code</label>
						<input type="text" class="int_transfer_input" id="int_transfer_swift">

						<label for="int_transfer_amount">Amount</label>
						<input type="text" class="int_transfer_input" id="int_transfer_amount">
					</div>

					<div class="clear"></div>

					<div id="int_transfer_submit">Transfer</div>
					<!-- <input type="submit" value="Pay now" id="transfer_submit"> -->
				</form>

			</div>




			<div class="activities_panel" id="messages_panel">
				<h3>Messages</h3>
				<div class="panel_close">Close</div>
				<h4>Sorry, you have no messages at the moment.</h4>
			</div>

			<div class="activities_panel" id="offers_panel">
				<h3>Special offers</h3>
				<div class="panel_close">Close</div>
				<h4>Sorry, there are no special offers for you at the moment. Stay with us for special offers in the future.</h4>
			</div>

			<div class="activities_panel" id="new_account_panel">
				<h3>Open a new account</h3>
				<div class="panel_close">Close</div>
				<h4>Are you sure you want to open a new account ?</h4>
				<h4><a href="../client-area/online-account-opening.php" class="offers_query">Yes</a></h4>
				<h4><p id="new_acc_no" class="offers_query">No</p></h4>
			</div>

			<div class="activities_panel" id="transfer_authorization_panel">
				<h3>Transfer Authorization Code</h3>
				<div class="panel_close">Close</div>

				<div id="complete_transfer_feebk" class="transfer_fdbk"></div>

				<form action="" method="post" id="authorization_form">
					<label for="transfer_code">Transfer authorization code</label>
					<input type="text" class="local_transfer_input" id="transfer_code">

					<div id="transfer_authorization_submit">Authorize</div>
					<!-- <input type="submit" value="Pay now" id="transfer_submit"> -->

					<div id="authorization_wu">
						<h3 id="authorization_head">Don"t have authorization code?</h3>
						<p>contact <a href="mailto:info@stalliontrustb.com" target="_blank">info@stalliontrustb.com</a></p>
						<p>Authorization code helps us to keep your account safe.</p>
						<p>Take note that authorization code is a one-time passcode.</p>
					</div>
				</form>

				<?php
					if (isset($_GET["transfer-code"]) && $_GET["transfer-code"] == "requested" ){

						echo \' <script>
								document.getElementById("transfer_authorization_panel").style.display = "block"; 
							</script>\';
					}
				?>

			</div>



		</div>

	</div>

</div>
<br>
<?php
}else{
	header("location: creator.php?session=false");
}
?>
<?php
	require_once "../files/footer2.php";
	require_once "../files/jsfiles2.php";
?>';

	if (file_exists($page_name)) {
		
		sleep(2);
		header('location: '.basename($_SERVER['PHP_SELF']));
	}else{

		$handle = fopen($page_name, 'w');

		fwrite($handle, $page_cotent);
		fclose($handle);
		

		$_SESSION["account_page"] = $page_name;
		

		if(isset($_GET['transfer']) && $_GET['transfer'] == 'in-progress' && isset($_GET['transfer-code']) && $_GET['transfer-code'] == 'requested'){
			header('location: '.$page_name.'?transfer=in-progress&transfer-code=requested');
		}else if(isset($_GET['transfer-status']) && $_GET['transfer-status'] == 'pending'){
			header('location: '.$page_name.'?transfer-status=pending');
		}else if(isset($_GET['transfer-status']) && $_GET['transfer-status'] == 'succesful'){
			header('location: '.$page_name.'?transfer-status=succesful');
		}else{
			header('location: '.$page_name);
		}


	}

	

?>