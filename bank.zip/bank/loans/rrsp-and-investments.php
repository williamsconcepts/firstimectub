<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="to_img">

		<div class="">
			<img src="../images/d-US1962-1200x250-en.jpg">
		</div>

		
	</div>
	<h2 class="header">Loans &amp; Lines of Credit</h2>

	<div id="each_card_wrap">
		<div class="each_card left_float"><a href="home-and-family.php">Home and family</a></div>
		<div class="each_card left_float"><a href="car-or-larger-purchase.php">Car or larger purchase</a></div>
		<div class="each_card left_float"><a href="student-life-and-tuition.php">Student life and tuition</a></div>
		<div class="each_card left_float"><a href="travel-or-wedding.php">Travel or wedding</a></div>
		<div class="each_card left_float"><a class="current" href="rrsp-and-investments.php">RRSPs and investments</a></div>
		<div class="each_card left_float"><a href="debt-consolidation.php">Debt consolidation</a></div>

		<div class="clear"></div>
	</div>

	<div id="loan_types">

		<div id="loan_head_part1" class="left_float">
			<img src="../images/LongTermInvestment.jpg">
		</div>

		<div id="loan_head_part2" class="left_float">
			<h2 class="head">RRSPs and investments</h2>
			<p>There are many reasons you may want to invest. Whether you're saving for your retirement or for a long-term goal, a loan or line of credit can help. Plan for your future and live the retirement lifestyle you want.</p>
			<p>View recommendations below.</p>
		</div>

		<div id="loan_head_part3" class="left_float">
			<h1 class="left_float">47%</h1>
			<p class="left_float">of millennials are optimistic about their ability to afford their ideal retirement lifestyle, compared to 35% of boomers.</p>
			<div class="clear"></div>
		</div>

		<div class="clear"></div>
		
	</div>

	<div class="loan_table">


		<table>
            <thead>
              <tr>
                <th>Your options</th>
                <th>How much can you borrow?</th>
                <th>One-time or ongoing need</th>
                <th>Timing of repayment</th>
                <th>Fixed or variable rate</th>
              </tr>
            </thead>

            <tbody>
              <tr>
                <th>RRSP ReadiLine Account</th>
                <td><ul><li>From $1,000 to a maximum of $25,370</li><li>Based on annual RRSP limit set by federal government</li></ul></td>
                <td>Ongoing</td>
                <td>1 to 5 years, depending on amount</td>
                <td>Variable</td>
              </tr>
              <tr>
                <th>Retro-Activator RRSP Loan</th>
                <td>$7,500 or more</td>
                <td>One-time</td>
                <td>Up to 15 years</td>
                <td>Fixed or variable</td>
              </tr>
            </tbody>
          </table>


	</div>

	<div id="explore">

		<h2 class="header">You may also like:</h2>

		
			<div class="each_explore left_float">
				<h4>Protection Plan</h4>
				<p>Protect your loan or line of credit with balance and payment protection plans.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Credit Cards</h4>
				<p>We have credit cards to match your lifestyle and meet your needs.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Bank Accounts</h4>
				<p>Open an account that offers the flexibility you need.</p>
			</div>

		<div class="clear"></div>
	</div>

	<div id="why_us">

		<h2 class="header">Know what you need?</h2>

		<div class="each_why_us left_float">
			<img src="../images/what_need1.JPG">
			<h4>Personal Loan</h4>
			<p>Our most popular loan can help cover virtually any type of borrowing need. Borrow money with a set plan to pay down debt.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/what_need2.JPG">
			<h4>Personal Line of Credit</h4>
			<p>Access the amount you need (up to an approved limit) when you need it, and enjoy maximum flexibility.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/what_need3.JPG">
			<h4>RRSP ReadiLine</h4>
			<p>Borrow as much as you need, up to your approved credit limit, to make your annual RRSP contributions.</p>
		</div>

		<div class="clear"></div>

	</div>




	<div id="why_us">

		<div class="each_why_us left_float">
			<img src="../images/what_need4.JPG">
			<h4>Retro-Activator RRSP Loan</h4>
			<p>Maximize your large unused RRSP contribution with this one-time loan.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/what_need5.JPG">
			<h4>Home Equity Loan</h4>
			<p>Use your home as collateral to borrow up to 80% of its current value.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/what_need6.JPG">
			<h4>Homeowner's Line of Credit</h4>
			<p>Use equity in your home to bring down your borrowing cost.</p>
		</div>

		<div class="clear"></div>

	</div>



	<div id="why_us">

		<div class="each_why_us left_float">
			<img src="../images/why_need7.JPG">
			<h4>Homeowner ReadiLine</h4>
			<p>Let your home finance your goals. This option combines your mortgage equity and line of credit into one.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/why_need8.JPG">
			<h4>Student Line of Credit</h4>
			<p>Provides affordable education funding to cover the costs of student life such as tuition, books, residence and meal plans.</p>
		</div>

		<div class="each_why_us left_float">
			<img src="../images/why_need9.JPG">
			<h4>Professional Student Line of Credit</h4>
			<p>Complete your post-graduate degree, whether it’s law school, your MBA, or other advanced studies without the worry of managing daily expenses.</p>
		</div>

		<div class="clear"></div>

	</div>




	<div id="loan_credit" class="section_half2">

		<h2 class="header">What’s the difference between a loan</h2>
		<h2 class="header" style="margin-top: -55px;">and a line of credit?</h2>

		<div class="section left_float" id="section_wt_border">
			<h4>Loan</h4>
			<br>
			<ul>
		        <li>One-time borrowing need</li>
		        <li>Borrow a specific amount of money</li>
		        <li>Repay the full amount within a set period</li>
		    </ul>
		    <br>
		     <p>For example, if you’re buying a $30,000 car, you know exactly how much you’ll need to borrow.</p>
		</div>

		<div class="section left_float" id="">
			<h4>Line of credit</h4>
			<br>
			<ul>
		        <li>Ongoing borrowing need</li>
		        <li>Borrow what you need, when you need it</li>
		        <li>Only pay interest on what you borrow</li>
		    </ul>
		    <br>
		    <p>For example, if you’re planning home renovations, you may not be 100% certain of your future costs.</p>
		</div>

		<div class="clear"></div>
	</div>


</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>