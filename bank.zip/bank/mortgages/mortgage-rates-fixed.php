<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">

	<div id="mort_img">
		<img src="../images/banner-MortgageSpecialRate.jpg">
	</div>
	<h2 class="header">Fixed Mortgage Rates</h2>

		


		<div id="top_rate_section_half2" class="section_half2">

			<div id="top_rate" class="top_header">
				<h2 class="header">Residential Fixed Rate</h2>
				<p>Your payments stay the same over the course of your term so</p>
				<p>you can budget with predictability. Choose from an open, closed</p>
				<p>or convertible mortgage depending on your needs.</p>
			</div>

			<div class="section left_float" id="section_wt_border">
				<h4>Open Fixed Rate</h4>
				<p>Choose this mortgage if you believe interest rates will go down, if you plan to make prepayments of more than 20% of your original mortgage principal, or if you plan to sell your home in the near future.</p>

				<table>
	              <thead>
	                <tr class="tr-first">
	                  <td>Term</td>
	                  <td class="">Rate</td>
	                </tr>
	              </thead>

	              <tbody>
	                <tr>
	                	<td>6 month</td>
	                  	<td class="">6.950%</td>
	                </tr>
	                <tr>
	                  <td>1 year</td>
	                  <td class="">6.950%</td>
	                </tr>
	                <tr>
	                  <td>18 year</td>
	                  <td class="">8.500%</td>
	                </tr>
	              </tbody>
	            </table>


	            <h4>Convertible Fixed Rate</h4>
	            <p>Offers the same benefits of a closed mortgage with the flexibility of changing to a longer fixed rate term of 1 year or longer without a prepayment charge.</p>

	            <table>

	              <thead>
	                <tr class="tr-first">
	                  <td>Term</td>
	                  <td class="">Rate</td>
	                </tr>
	              </thead>

	              <tbody>
	                <tr>
	                  <td>6 month</td>
	                  <td class="">4.200%
	                  </td>
	                </tr>
	              </tbody>

	            </table>



			</div>

			<div class="section left_float" id="">
				<h4>Closed Fixed Rate</h4>
				<p>ake advantage of lower interest rates than an open mortgage when you lock-in your rate for the duration of the term.</p>


				<table>
		            <thead>
		              	<tr>
			                <td class="tr-first">Term</td>
			              	<td>Rate</td>
			              	<td>APR</td>
		            	</tr>
		          	</thead>

		          	<tbody>
		            	<tr>
		              		<td>1 year</td>
		              		<td>3.090%</td>
		              		<td></td>
		            	</tr>
		            	<tr>
		              		<td>2 year</td>
		              		<td>3.190%</td>
			              	<td></td>
		           		</tr>
			            <tr>
			              	<td>3 year</td>
			              	<td>3.590%</td>
			              	<td></td>
			            </tr>
			            <tr>
			              	<td>4 year</td>
			              	<td>4.090%</td>
			              	<td></td>
			            </tr>
			            <tr>
			              	<td>5 year</td>
			              	<td>4.840%</td>
			              	<td></td>
		            	</tr>
			            <tr>
			              	<td>5-year United Overseas Corperation Bank Smart Fixed Mortgage</td>
			              	<td>2.890</span> %</td>
			              	<td>2.91%</td>
			            </tr>
			            <tr>
			              	<td>5 year&nbsp;&nbsp;<br> United Overseas Corperation Bank Eco Smart &nbsp;&nbsp;<br> Mortgage</td>
			              	<td>4.840%</td>
			              	<td>Call for details</td>
			            </tr>
			            <tr>
				            <td>6 year</td>
				            <td>5.340%</td>
				            <td></td>
			            </tr>
			            <tr>
			              	<td>7 year</td>
			              	<td>5.500%</td>
			              	<td></td>
			            </tr>
			            <tr>
			              	<td>10 year</td>
			              	<td>6.300%</td>
			              	<td></td>
			            </tr>
			            <tr>
			              	<td>10-year United Overseas Corperation Bank Smart Fixed Mortgage</td>
			              	<td>3.940%</td>
			              	<td>3.95%</td>
			            </tr>
		          	</tbody>
	        	</table>


			</div>

			<div class="clear"></div>
		</div>





	<div id="explore">

		<h2 class="header">Ready to explore options?</h2>

		
			<div class="each_explore left_float">
				<h>Start Pre-approval</h4>
				<p>We'll respond within 24 hours of receiving your request to start your online mortgage pre-approval.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Make an Appointment</h4>
				<p>Choose the date, time and branch to book an appointment that works with your schedule.</p>
			</div>

		
			<div class="each_explore left_float">
				<h4>Apply Online</h4>
				<p>Complete your application online and we will contact you within two business days to follow-up.</p>
			</div>

		<div class="clear"></div>
	</div>

</div>





<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>