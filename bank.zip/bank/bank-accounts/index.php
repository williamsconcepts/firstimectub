<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">
	<h2 class="header">Let's find you the right bank account</h2>

	<div id="bnk_acc">

		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img1"></div>
				</div>
				
				<h4 class="bnk_acc_header">Practical</h4>

				<p class="desc">A low-cost option for limited banking needs</p>

				<div class="amount"> 
					<h3>$4.00</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$2,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>12</p>
					<h5>Transactions per month</h5>
				</div>

				<div class="other_wu">
					<h3>NEW</h3>
					<p>Send FREE Unlimited</p>
					<p>Interac e-transfer transactions </p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

				<div class="compare"><a href="compare-bank-plan.php">Compare</a></div>

			</div>	

		</div>




		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img2"></div>
				</div>
				<h4 class="bnk_acc_header">Plus</h4>

				<p class="desc">Great value for moderate banking needs</p>

				<div class="amount"> 
					<h3>Free</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>N/A</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>30</p>
					<h5>Transactions per month</h5>
				</div>

				<div class="other_wu">
					<h3>NEW</h3>
					<p>Send FREE Unlimited</p>
					<p>Interac e-transfer transactions </p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

				<div class="compare"><a href="compare-bank-plan.php">Compare</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img3"></div>
				</div>
				<h4 class="bnk_acc_header">Performance</h4>

				<p class="desc">The most popular and versatile option</p>

				<div class="amount"> 
					<h3>$4.00</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$4,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited</p>
					<h5>Transactions per month</h5>
				</div>

				<div class="other_wu">
					<h3>NEW</h3>
					<p>Send FREE Unlimited</p>
					<p>Interac e-transfer transactions </p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

				<div class="compare"><a href="compare-bank-plan.php">Compare</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">
				
				<div class="top_img_wrap">
					<div class="top_img" id="top_img4"></div>
				</div>
				<h4 class="bnk_acc_header">AIR MILES</h4>

				<p class="desc">Get rewarded on your everyday purchases</p>

				<div class="amount"> 
					<h3>$14.95</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>N/A</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited</p>
					<h5>Transactions per month</h5>
				</div>

				<div class="other_wu">
					<h3>NEW</h3>
					<p>Send FREE Unlimited</p>
					<p>Interac e-transfer transactions </p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

				<div class="compare"><a href="compare-bank-plan.php">Compare</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">
				
				<div class="top_img_wrap">
					<div class="top_img" id="top_img5"></div>
				</div>
				<h4 class="bnk_acc_header">Premium</h4>

				<p class="desc">Enjoy money-saving features and benefits</p>

				<div class="amount"> 
					<h3> $19.05</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$6,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited</p>
					<h5>Transactions per month</h5>
				</div>

				<div class="other_wu">
					<h3>NEW</h3>
					<p>Send FREE Unlimited</p>
					<p>Interac e-transfer transactions </p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

				<div class="compare"><a href="compare-bank-plan.php">Compare</a></div>

			</div>	

		</div>

		<div class="clear"></div>

	</div>

	<div class="section_half">
		<div class="section left_float" id="section1">
			<img src="../images/d-whyBMO.chequing.png">
		</div>

		<div class="section left_float" id="section2">
			<h2>Your Chequing Account</h2>
			<p>Your chequing account sees a lot of activity throughout the month, whether it's the bills you have to pay, your paycheque being deposited, or the weekly trips you make to the ATM.</p>
			<p>United Overseas Corperation Bank chequing accounts are a safe, convenient place to keep money that you use for day-to-day spending or to pay bills over the short term. Open a bank account online and see for yourself.</p>
			<p>We're invested in you, our customers, because you're invested in us, and we're committed to treating you like a human being. Because we're all human, right? </p>
		</div>

		<div class="clear"></div>
	</div>
</div>

<div id="blue_wrapper">
	<div id="blue_pre_footer" class="page_width">
		<h2>The United Overseas Corperation Bank difference</h2>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img1"></div>
				<p>Open multiple bank accounts for you and your spouse/partner for one monthly feeLink will open in new window with PlanShare</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img2"></div>
				<p>You can open a new United Overseas Corperation Bank chequing account on your smartphone from wherever you are. As long as we’re able to verify your ID with the info you provide, there’s no need to visit a branch!</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img3"></div>
				<p>Switch over all of your automatic bill payments in one quick step</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img4"></div>
				<p>Enjoy tailored banking advice that fits your unique life needs</p>
			</div>

			<div class="each_pre_f_sect left_float">
				<div class="pre_f_top_img" id="pre_f_top_img5"></div>
				<p>Get AIR MILES Reward Miles on your day-to-day purchases on both United Overseas Corperation Bank debit and credit cards</p>
			</div>

			<div class="clear"></div>

			<div class="white_bordered_btn">
				<a href="">Learn more about switching to us</a>
			</div>
	
	</div>
</div>


<div id="page_body" class="page_width">

	<div class="section_half2">

		<div class="section left_float" id="section_wt_border">
			<div id="section1"></div>
			<h2>Not sure which bank account is right for you?</h2>
			<div class="bordered_btn">
				<a href="">Compare bank accounts</a>
			</div>
		</div>

		<div class="section left_float" id="">
			<div id="section2"></div>
			<h2>Have questions?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="clear"></div>
	</div>

</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>