<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">
	<h2 class="header">Let's find you the right bank account</h2>

	<div id="bnk_acc" class="compare_acc">

		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img1"></div>
				</div>
				
				<h4 class="bnk_acc_header">Practical</h4>

				<p class="desc">A low-cost option for limited banking needs</p>

				<div class="amount"> 
					<h3>$4.00</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$2,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Add up to 2 accounts for one monthly fee</p>
				</div>

				<div class="tra_per_mth">
					<p>12 Transactions per month; $1.25 per for each additional transaction</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of non-United Overseas Corperation Bank ATM withdrawals included per month</p>
					<p>0</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of Interac eTransfer transactions per month</p>
					<p>0</p>
				</div>

				<div class="tra_per_mth">
					<p>Annual fee waived on United Overseas Corperation Bank World Elite MasterCard cards</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Standard Overdraft Protection</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>AIR MILES Reward Miles</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Monthly Statements</p>
					<p>One paper statement included</p>
				</div>

				<div class="tra_per_mth">
					<p>Additional features included</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Travel Services included</p>
					<p>N/A</p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>




		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img2"></div>
				</div>
				<h4 class="bnk_acc_header">Plus</h4>

				<p class="desc">Great value for moderate banking needs</p>

				<div class="amount"> 
					<h3>Free</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>N/A</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Add up to 20 accounts for one monthly fee</p>
				</div>

				<div class="tra_per_mth">
					<p>30 Transactions per month; $1.25 per for each additional transaction</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of non-United Overseas Corperation Bank ATM withdrawals included per month</p>
					<p>0</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of Interac eTransfer transactions per month</p>
					<p>2</p>
				</div>

				<div class="tra_per_mth">
					<p>Annual fee waived on United Overseas Corperation Bank World Elite MasterCard cards</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Standard Overdraft Protection</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>AIR MILES Reward Miles</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Monthly Statements</p>
					<p>Free eStatement; $2 for paper statement</p>
				</div>

				<div class="tra_per_mth">
					<p>Additional features included</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Travel Services included</p>
					<p>N/A</p>
				</div>


				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">

				<div class="top_img_wrap">
					<div class="top_img" id="top_img3"></div>
				</div>
				<h4 class="bnk_acc_header">Performance</h4>

				<p class="desc">The most popular and versatile option</p>

				<div class="amount"> 
					<h3>$4.00</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$4,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Add up to 20 accounts for one monthly fee</p>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited Transactions per month</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of non-United Overseas Corperation Bank ATM withdrawals included per month</p>
					<p>1</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of Interac eTransfer transactions per month</p>
					<p>2</p>
				</div>

				<div class="tra_per_mth">
					<p>Annual fee waived on United Overseas Corperation Bank World Elite MasterCard cards</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Standard Overdraft Protection</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>AIR MILES Reward Miles</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Monthly Statements</p>
					<p>Free eStatement; $2 for paper statement</p>
				</div>

				<div class="tra_per_mth">
					<p>Additional features included</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Travel Services included</p>
					<p>N/A</p>
				</div>

				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">
				
				<div class="top_img_wrap">
					<div class="top_img" id="top_img4"></div>
				</div>
				<h4 class="bnk_acc_header">AIR MILES</h4>

				<p class="desc">Get rewarded on your everyday purchases</p>

				<div class="amount"> 
					<h3>$14.95</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>N/A</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Add up to 20 accounts for one monthly fee</p>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited Transactions per month</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of non-United Overseas Corperation Bank ATM withdrawals included per month</p>
					<p>0</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of Interac eTransfer transactions per month</p>
					<p>0</p>
				</div>

				<div class="tra_per_mth">
					<p>Annual fee waived on United Overseas Corperation Bank World Elite MasterCard cards</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Standard Overdraft Protection</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>AIR MILES Reward Miles</p>
					<p>Get 1 Mile for every $30 spent using your United Overseas Corperation Bank Debit Card</p>
				</div>

				<div class="tra_per_mth">
					<p>Monthly Statements</p>
					<p>Free eStatement; $2 for paper statement</p>
				</div>

				<div class="tra_per_mth">
					<p>Additional features included</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Travel Services included</p>
					<p>N/A</p>
				</div>


				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>



		<div class="each_bnk_acc left_float">
			<div class="each_bnk_acc_wrap">
				
				<div class="top_img_wrap">
					<div class="top_img" id="top_img5"></div>
				</div>
				<h4 class="bnk_acc_header">Premium</h4>

				<p class="desc">Enjoy money-saving features and benefits</p>

				<div class="amount"> 
					<h3> $19.05</h3>
					<h5>Monthly Fee</h5>
				</div>

				<div class="min_bal">
					<p>$6,000</p>
					<h5>Minimum balance to waive fee</h5>
				</div>

				<div class="tra_per_mth">
					<p>Add up to 20 accounts for one monthly fee</p>
				</div>

				<div class="tra_per_mth">
					<p>Unlimited Transactions per month</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of non-United Overseas Corperation Bank ATM withdrawals included per month</p>
					<p>10</p>
				</div>

				<div class="tra_per_mth">
					<p>Number of Interac eTransfer transactions per month</p>
					<p>Unlimited</p>
				</div>

				<div class="tra_per_mth">
					<p>Annual fee waived on United Overseas Corperation Bank World Elite MasterCard cards</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>Standard Overdraft Protection</p>
					<p>N/A</p>
				</div>

				<div class="tra_per_mth">
					<p>AIR MILES Reward Miles</p>
					<p>Get 1 Mile for every $40 spent using your United Overseas Corperation Bank Debit Card</p>
				</div>

				<div class="tra_per_mth">
					<p>Monthly Statements</p>
					<p>Free eStatement; $2 for paper statement</p>
				</div>

				<div class="tra_per_mth">
					<p>Additional features included</p>
					<p>Cheques, Money Orders, &amp; Drafts</p>
					<p>Safety Deposit Box discount</p>
				</div>

				<div class="tra_per_mth">
					<p>Travel Services included</p>
					<p>5 withdrawals from ATMs outside of Canada</p>
					<p>Travellers cheques</p>
					<p>Preferred exchange rate on U.S. cash</p>
					<p>U.S. dollar bill payments</p>
				</div>


				<div class="open_now"><a href="../client-area/online-account-opening.php">Open now</a></div>

			</div>	

		</div>

		<div class="clear"></div>

	</div>

</div>

<div id="page_body" class="page_width">

	<div class="section_half2">

		<div class="section left_float" id="section_wt_border">
			<div id="section1"></div>
			<h2>Not sure which bank account is right for you?</h2>
			<div class="bordered_btn">
				<a href="">Compare bank accounts</a>
			</div>
		</div>

		<div class="section left_float" id="">
			<div id="section2"></div>
			<h2>Have questions?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="clear"></div>
	</div>

</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>