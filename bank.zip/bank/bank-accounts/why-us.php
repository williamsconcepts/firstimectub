<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
?>

<div id="page_body" class="page_width">
	<h2 class="header">Banking with a human touch</h2>

	<div id="why_bnk_with_us">

		<div class="each_why_bnk_with_us">

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_1">

				</div>
			</div>
			

			<div class="section2 left_float">
				<h2>Switching to United Overseas Corperation Bank: How we're different</h2>
				<div class="thick_red_li"></div>
				<p>Our PlanShare feature lets you and your spouse or partner set up multiple separate accounts without paying additional monthly fees; or create joint accounts to handle housing costs, groceries, and shared living expenses.</p>
				<p>Use individual accounts to budget for personal expenses: clothing, lunch, or maybe a surprise birthday gift.</p>
			</div>

			<div class="clear"></div>
		</div>


		<div class="each_why_bnk_with_us">

			<div class="section2 left_float">
				<h2>Award-winning mobile banking</h2>
				<div class="thick_red_li"></div>
				<p>United Overseas Corperation Bank has been recognized as a Model Bank for Excellence in Digital Banking by Celent, a global financial services research firm.</p>
				<p>Enjoy fast, easy, secure banking with our mobile app. Transfer funds, pay bills and view transactions online from your smartphone, tablet, or computer—24 hours a day, seven days a week.</p>
			</div>

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_2">

				</div>
			</div>
			

			<div class="clear"></div>
		</div>



		<div class="each_why_bnk_with_us">

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_3">
					<div class="white_bg"></div>
				</div>
			</div>
			

			<div class="section2 left_float">
				<h2>Switch banks, seamlessly</h2>
				<div class="thick_red_li"></div>
				<p>Transfer your pre-authorized payments and deposits to your new United Overseas Corperation Bank® account at no cost in a few easy steps, online with PowerSwitch.</p>
				<p>Prefer us to make the switch for you? Feel free to visit one of our branches. Set up direct payments from your credit card while we notify all pre-authorized billers of your switch.</p>
			</div>

			<div class="clear"></div>
		</div>


		<div class="each_why_bnk_with_us">

			<div class="section2 left_float">
				<h2>Get rewards faster. Fly sooner.</h2>
				<div class="thick_red_li"></div>
				<p>Get 1 AIR MILES Reward Mile for every $30 you spend using your United Overseas Corperation Bank Debit Card with your United Overseas Corperation Bank AIR MILES Chequing Plan.</p>
				<p>In addition to earning Miles on your everyday United Overseas Corperation Bank Debit Card purchases, you can earn Miles with United Overseas Corperation Bank AIR MILES MasterCard cards as well.</p>
			</div>

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_4">

				</div>
			</div>
			

			<div class="clear"></div>
		</div>



		<div class="each_why_bnk_with_us">

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_5">

				</div>
			</div>

			<div class="section2 left_float">
				<h2>In-person advice, tailored to you</h2>
				<div class="thick_red_li"></div>
				<p>Meet with us in the branch and we’ll work with you to understand your unique situation and help you achieve the financial goals that are most important to you.</p>
				<p>We’d love to talk with you.</p>
			</div>

			<div class="clear"></div>
		</div>



		<div class="each_why_bnk_with_us">

			<div class="section2 left_float">
				<h2>Accomplishments</h2>
				<div class="thick_red_li"></div>
				<p>Recognized for Excellence in Digital Banking for third year in a row <br>- Celent</p>
				<p>Live Agent &amp; Automated Telephone Banking (Big Five Banks) award winner <br>- Ipsos Best Banking Awards</p>
				<p>United Overseas Corperation Bank Named to the Global 100 Most Sustainable Corporations in the World for Third Straight Year <br>- World Economic Forum</p>
			</div>

			<div class="section1_wrap left_float">
				<div class="section1" id="section_img_6">

				</div>
			</div>

			<div class="clear"></div>
		</div>
	
	
	

	</div>

	
</div>

<div id="blue_wrapper" class="three_items">
	<div id="blue_pre_footer" class="page_width">
		<h2>Get started today</h2>

			<div class="clear"></div>

			<div class="white_bordered_btn">
				<a href="../client-area/online-account-opening.php">Open a new account</a>
			</div>
	
	</div>
</div>


<div id="page_body" class="page_width">

	<div class="section_half2">

		<div class="section left_float" id="section_wt_border">
			<div id="section1"></div>
			<h2>Not sure which bank account is right for you?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="section left_float" id="">
			<div id="section2"></div>
			<h2>Have questions?</h2>
			<div class="bordered_btn">
				<a href="">Contact us</a>
			</div>
		</div>

		<div class="clear"></div>
	</div>

</div>




<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>