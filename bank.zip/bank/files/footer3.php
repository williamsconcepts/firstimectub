
	<div id="footer_top_wrapper">



		<div id="footer_top" class="page_width">

			

			<ul class="left_float">
				<li><a href="/bank-accounts/index.php">Bank Accounts</a></li>
				<li><a href="/bank-accounts/savings.php">Savings Account</a></li>
				<li><a href="/bank-accounts/index.php">Chequing Account</a></li>
				<li><a href="/bank-accounts/compare-bank-plan.php">Compare Plans</a></li>
				<li><a href="/bank-accounts/why-us.php">Why Chose Us</a></li>
				<li><a href="/bank-accounts/banking-services.php">Banking Services</a></li>
			</ul>

			<ul class="left_float">
				<li><a href="/credit-cards/premium-credit-cards.php">Credit Cards</a></li>
				<li><a href="/credit-cards/premium-credit-cards.php">Premium</a></li>
				<li><a href="/credit-cards/cashback-credit-cards.php">Cashback</a></li>
				<li><a href="/credit-cards/bmo-rewards-travel-credit-cards.php">Rewards/Travel</a></li>
				<li><a href="/credit-cards/air-miles-credit-cards.php">Air Miles</a></li>
				<li><a href="/credit-cards/no-annual-fee-credit-cards.php">No Annual Fee</a></li>
				<li><a href="/credit-cards/special-offers-credit-cards.php">Special Offers</a></li>
			</ul>

			<ul class="left_float">
				<li><a href="/mortgages/mortgage-rates-fixed.php">Mortgages</a></li>
				<li><a href="/mortgages/mortgage-rates-fixed.php">Fixed Mortgage</a></li>
				<li><a href="/mortgages/mortgage-rates-variable.php">Variable Mortgage</a></li>
				<li><a href="/mortgages/smart-fixed.php">Smart Fixed</a></li>
				<li><a href="/mortgages/special-offers.php">Special Offers</a></li>
				<li><a href="/mortgages/insuring-your-mortgage.php">Mortgage Insurance</a></li>
			</ul>

			<ul class="left_float">
				<li><a href="/loans/home-and-family.php">Loans</a></li>
				<li><a href="/loans/home-and-family.php">Home and Family</a></li>
				<li><a href="/loans/car-or-larger-purchase.php">Car or Larger Purchase</a></li>
				<li><a href="/loans/student-life-and-tuition.php">Student Life and Tuition</a></li>
				<li><a href="/loans/travel-or-wedding.php">Travel or wedding</a></li>
				<li><a href="/loans/rrsp-and-investments.php">RRSPs and investments</a></li>
				<li><a href="/loans/debt-consolidation.php">Debt consolidation</a></li>
			</ul>

			<div class="clear"></div>

		</div>

	</div>


	<div id="footer_bottom_wrapper">

		<div id="footer_contact_socials" class="page_width">
			<!-- <h2 class="left_float"><a href="/">Contact Us</a></h2> -->

			<ul class="right_float">
				<!-- <li>Follow BMO</li>
				<li><a href="/"><img src="/images/icon_fb.png"></a></li>
				<li><a href="/"><img src="/images/icon_twitter.png"></a></li>
				<li><a href="/"><img src="/images/icon_yt.png"></a></li>
				<li><a href="/"><img src="/images/icon_rss.png"></a></li>
				<li><a href="/"><img src="/images/icon_ln.png"></a></li> -->
			</ul>
			<div class="clear"></div>

		</div>	

		<div id="footer_bottom" class="page_width">
			<!-- <ul>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
				<li><a href="/">Link</a></li>
			</ul> -->
		</div>
		
	</div>

	</body>
</html>