<?php
	
	echo "Failed!";
	
?>