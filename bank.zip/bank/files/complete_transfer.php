<?php
session_start();

	$sign_in_email = "";
	$sign_in_password = "";
	$feedback_text = "";

	require_once 'connect.inc.php';
	

	if (isset($_SESSION['online_id_session']) && isset($_SESSION['passcode_session'])) {
		$online_id = $_SESSION['online_id_session'];
		$passcode = $_SESSION['passcode_session'];
	}

	$transfer_code = $_POST['transfer_code'];

	$query = "SELECT *  FROM `boa_acc_clients` WHERE `transfer_code`='$transfer_code' AND `online_id`='$online_id' AND `passcode`='$passcode'";
	$query_run = mysql_query($query);

	if (mysql_num_rows($query_run)==1) {

		$query_row = mysql_fetch_assoc($query_run);
		$firstname = $query_row['firstname'];
		$middlename = $query_row['middlename'];
		$lastname = $query_row['lastname'];
		$phone1 = $query_row['phone1'];
		$email = $query_row['email'];
		$acc_number = $query_row['acc_number'];
		$balance = $query_row['balance'];
		$int_transfer_acc_no = $query_row['transfer_acc_no'];
		$int_transfer_amount = $query_row['transfer_amount'];
		$transfer_message = $query_row['transfer_message'];

		$acc_number_history = $acc_number;

		$acc_number_first_two = substr($acc_number, 0, 2);
		$acc_number_last_three = substr($acc_number, 9, strlen($acc_number));
		$acc_number = $acc_number_first_two."*******".$acc_number_last_three;


		$balance = str_replace(",", "" ,$balance);
		$balance = str_replace("$", "" ,$balance);

		$timestamp = time();
		$time= @date('H:i:s', $timestamp -(60*60));
		$date = @date('d-m-Y', $timestamp - (60*60));
		$date_time = $date." ".$time;

		$transaction_type = "International transfer";

		$transaction_id = rand(1111111111, 9999999999);


		$int_transfer_amount_sanitized = str_replace("," ,"" ,$int_transfer_amount);
		$int_transfer_amount_sanitized = str_replace("$","" ,$int_transfer_amount_sanitized);


		if(!is_numeric($int_transfer_amount_sanitized)){
			echo "Please enter correct amount value.Eg $5,045.91";
			return false;
		}

		$transfer_balance = $balance - $int_transfer_amount_sanitized;


		if($transfer_balance < 0){
			echo "Amount too large. Please try a lesser amount.";
			return false;
		}

		 		// Adding $ and , where neccessary in international transfer amount
		$int_transfer_amount_sanitized_dot_pos = strpos($int_transfer_amount_sanitized, ".", 0);
		$int_transfer_amount_sanitized_len = strlen($int_transfer_amount_sanitized);

		if($int_transfer_amount_sanitized_dot_pos == ""){
			$int_transfer_amount_sanitized_after_dot = ".00";
			$int_transfer_amount_sanitized_before_dot = substr($int_transfer_amount_sanitized, 0, $int_transfer_amount_sanitized_len);
		}else{
			$int_transfer_amount_sanitized_after_dot = substr($int_transfer_amount_sanitized, $int_transfer_amount_sanitized_dot_pos, $int_transfer_amount_sanitized_len);
			$int_transfer_amount_sanitized_before_dot = substr($int_transfer_amount_sanitized, 0, $int_transfer_amount_sanitized_dot_pos);
		}

		$int_transfer_amount_sanitized_before_dot_reversed = strrev($int_transfer_amount_sanitized_before_dot);

		if(strlen($int_transfer_amount_sanitized_before_dot) > 3){
			$int_transfer_amount_sanitized_with_comma = substr_replace($int_transfer_amount_sanitized_before_dot_reversed, ",", 3, 0);
		}else{
			$int_transfer_amount_sanitized_with_comma = $int_transfer_amount_sanitized_before_dot_reversed;
		}
		

		if(strlen($int_transfer_amount_sanitized_before_dot) > 6){
			$int_transfer_amount_sanitized_with_comma = substr_replace($int_transfer_amount_sanitized_with_comma, ",", 7, 0);
		}

		$int_transfer_amount_sanitized_before_dot_unreversed = strrev($int_transfer_amount_sanitized_with_comma).$int_transfer_amount_sanitized_after_dot;
		$int_transfer_amount = "$".$int_transfer_amount_sanitized_before_dot_unreversed;







				// Adding $ and , where neccessary in transfer balance
		$transfer_balance_dot_pos = strpos($transfer_balance, ".", 0);
		$transfer_balance_len = strlen($transfer_balance);

		if($transfer_balance_dot_pos == ""){
			$transfer_balance_after_dot = ".00";
			$transfer_balance_before_dot = substr($transfer_balance, 0, $transfer_balance_len);
		}else{
			$transfer_balance_after_dot = substr($transfer_balance, $transfer_balance_dot_pos, $transfer_balance_len);
			$transfer_balance_before_dot = substr($transfer_balance, 0, $transfer_balance_dot_pos);
		}

		$transfer_balance_before_dot_reversed = strrev($transfer_balance_before_dot);

		if(strlen($transfer_balance_before_dot) > 3){
			$transfer_balance_with_comma = substr_replace($transfer_balance_before_dot_reversed, ",", 3, 0);
		}else{
			$transfer_balance_with_comma = $transfer_balance_before_dot_reversed;
		}
		

		if(strlen($transfer_balance_before_dot) > 6){
			$transfer_balance_with_comma = substr_replace($transfer_balance_with_comma, ",", 7, 0);
		}

		$transfer_balance_before_dot_unreversed = strrev($transfer_balance_with_comma).$transfer_balance_after_dot;
		$transfer_balance = "$".$transfer_balance_before_dot_unreversed;

		


		$query_update = "UPDATE `boa_acc_clients` SET `transfer_code`='', `balance`='".mysql_real_escape_string($transfer_balance)."' WHERE `online_id`='$online_id' AND `passcode`='$passcode'";
		$query_run = mysql_query($query_update);



		$history_desc = "International transfer to " .$acc_number;

		$query_set_history = "INSERT INTO `alert_history` VALUES('',
			'".mysql_real_escape_string($transaction_type)."',
			'".mysql_real_escape_string($history_desc)."',
			'".mysql_real_escape_string($int_transfer_amount)."',
			'$date',
			'$time',
			'$acc_number_history')";

		$query_set_history_run = mysql_query($query_set_history);






		$body = <<<MAIL

<div style="background:#f4f4f4; width:100%; min-height:100%; padding:100px 20px 20px 20px; font-family:arial, sanserif; color:#333;">
<div style="width:80%; margin:0px auto; padding:20px; background:#fff">

<div style="margin-top:20px; border-bottom:1px solid #222; height:100px;">
<div style="float:left; display:block; width:50%;">
<a href="http://www.unocb.com" style="display:block;padding-left:10%;"><img src="http://www.unocb.com/images/uno.png" alt="United Overseas Corperation Bank Logo"></a>
</div>

<div style="float:right; display:block; width:50%; text-align:right;">
<h4 style="margin-bottom:15px;">Transaction Notification</h4>
<p>$date_time</p>
</div>	
</div>


<div style="margin-top:20px">
<br>
<p style="font-size: 17px; margin-bottom: 20px;">Dear $firstname $middlename $lastname, </p>
<h4 style="margin-bottom:10px;">United Overseas Corperation Bank Transaction Alert</h4>
<p>$transfer_message</p>	




<h4 style="border-bottom:1px solid #222; padding-bottom: 40px;">Thank you for banking with United Overseas Corperation Bank</h4>

</div>

<div>
<p>This is an automated Transaction Alert Service. You are getting this email because a transaction just occurred on your account that met the threshold you set.</p>
<p>Please DO NOT reply this mail. For further enquire email us at <a href="enquire@unocb.com" style="color:#36c; text-decoration:none;">enquire@unocb.com</a> . </p>
</div>



</div>

<div style="margin-top:50px; border-top:1px solid #eee;">
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto; margin-top:30px;">The Information contained and transmitted by this E-MAIL is proprietary to United Overseas Corperation Bank and/or its Customer and is intended for use only by the individual or entity to which it is addressed, and may contain information that is privileged, confidential or exempt from a disclosure under applicable law.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If this is a forwarded message, the content of this E-MAIL may not have been sent with the authority of the Bank. United Overseas Corperation Bank shall not be liable for any mails sent without due authorisation or through unauthorised access.</p>
<p style="margin-bottom: 15px; color: #9e9e9e; line-height:20px; font-size:10px; width:80%; margin:0px auto;">If you are not the intended recipient, an agent of the intended recipient or a person responsible for delivering the information to the named recipient, you are notified that any use, distribution, transmission, printing, copying or dissemination of this information in any way or in any manner is strictly prohibited.</p>
<p style="margin:50px auto; color: #9e9e9e; line-height:20px; font-size:10px; text-align:center;">Copyright &copy; United Overseas Corperation Bank. All rights reserved.</p>
</div>



</div>
MAIL;


	
		$subject = 'United Overseas Corperation Bank notification';


		$headers = "From: United Overseas Corperation Bank Support <support@unocb.com>\r\n";
		$headers .= "Reply-to: United Overseas Corperation Bank Support <support@unocb.com>\r\n";
		$headers .= "Return-Path: United Overseas Corperation Bank Support <support@unocb.com>\r\n";
		$headers .= "X-Priority: 3\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "X-Mailer: PHP". phpversion() ."\r\n";
		$headers .= "Content-type: text/html; charset=ISO-8859-1\r\n";

		$sent = mail($email, $subject, $body, $headers, '-fsupport@unocb.com');

			
			$post_data=array(
			'sub_account'=>'3503_unocb',
			'sub_account_pass'=>'kompany',
			'action'=>'send_sms',
			'route'=>'1',
			'sender_id'=>'unocb',
			'recipients'=>$phone1,
			'message'=>"Debit Alert!\r\n Acc#: $acc_number\r\nAmount: $int_transfer_amount\r\nDesc: International transfer to $int_transfer_acc_no\r\nTime: $date_time\r\nTotal Bal: $transfer_balance"
			);
			
			$api_url='http://cheapglobalsms.com/api_v1';

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $api_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			
			$response = curl_exec($ch);
			$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($response_code != 200)$response=curl_error($ch);
			curl_close($ch);

			if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
			else
			{
				$json=@json_decode($response,true);
				
				if($json===null)$msg="INVALID RESPONSE: $response"; 
				elseif(!empty($json['error']))$msg=$json['error'];
				else
				{
					$msg="SMS sent to ".$json['total']." recipient(s).";
					$sms_batch_id=$json['batch_id'];
				}
			}
			
			$feedback_text = $msg;


			$post_data=array(
			'sub_account'=>'3503_unocb',
			'sub_account_pass'=>'kompany',
			'action'=>'send_sms',
			'sender_id'=>'unocb',
			'recipients'=>$phone1,
			'message'=>"Notification!\r\nTransfer complete -  account. Contact info@unocb.com for more details."
			);
			
			$api_url='http://cheapglobalsms.com/api_v1';

			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $api_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			
			$response = curl_exec($ch);
			$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			if($response_code != 200)$response=curl_error($ch);
			curl_close($ch);

			if($response_code != 200)$msg="HTTP ERROR $response_code: $response";
			else
			{
				$json=@json_decode($response,true);
				
				if($json===null)$msg="INVALID RESPONSE: $response"; 
				elseif(!empty($json['error']))$msg=$json['error'];
				else
				{
					$msg="SMS sent to ".$json['total']." recipient(s).";
					$sms_batch_id=$json['batch_id'];
				}
			}


		echo "Transfer Pending";
	}else{
		echo "Code is wrong";
	}

?>