<!doctype html>
<!--[if lt 9]>
		<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->

<html>
	<head>
		 <title>United Overseas Corporation Bank || Home</title>
		<link rel="stylesheet" type="text/css" href="/css/style.css">
		<!-- <link rel="stylesheet" type="text/css" href="css/jquery-ui.css"> -->
		
		<!--<script src="https://maps.googleapis.com/maps/api/js"></script>-->

		<link rel="shortcut icon" type="image/x-icon" href="/images/uno.png" />
        

		<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
		<meta name="viewport" content="width=device-width, maximum-scale=1.0, minimum-scale=1.0, initial-scale=1.0">

		
	</head>