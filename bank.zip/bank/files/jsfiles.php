<script type="text/javascript" src="js/jquery-2.1.3.min.js"></script>
<script type="text/javascript" src="js/cycle2.js"></script>
<script type="text/javascript" src="js/cycle2.tile.min.js"></script>
<script type="text/javascript" src="js/cycle2.shuffle.min.js"></script>
<script type="text/javascript" src="js/cycle2.scrollVert.min.js"></script>


<script type="text/javascript" src="js/cycle2.caption2.min.js"></script>
<script type="text/javascript" src="js/cycle2.carousel.min.js"></script>
<script type="text/javascript" src="js/cycle2.center.min.js"></script>
<script type="text/javascript" src="js/cycle2.flip.min.js"></script>

<script type="text/javascript" src="js/jquery.cookie.js"></script>
<script type="text/javascript" src="js/jquery-ui.js"></script>
<script type="text/javascript" src="js/source-jquery.crs.js"></script>
<script type="text/javascript" src="js/data.js"></script>
<script type="text/javascript" src="js/jquery.bgswitcher.js"></script>
<script type="text/javascript" src="js/script.js"></script>
