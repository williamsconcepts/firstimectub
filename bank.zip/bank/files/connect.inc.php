<?php
	$mysql_host ='localhost';
	$mysql_username = 'unoccykg_bank';
	$mysql_password = 'kompany123';
	$connection_error = "Could not connect please try again";
	$mysql_database = 'unoccykg_bank';   
	if(@mysql_connect($mysql_host, $mysql_username, $mysql_password)){
		//echo "connected to server!..... ";
		if(mysql_select_db($mysql_database)){
			//echo" connected to database!";
			
		}else{
			die($connection_error);
		}
	}else{
		die($connection_error);
	} 

	
 ?>
