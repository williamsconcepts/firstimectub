						


						<option value="" selected="selected">Select Country</option>
						<option value="Afghanistan [93]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Afghanistan [93]') {echo 'selected';} ?> >Afghanistan [93]</option>
						<option value="Albania [355]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Albania [355]') {echo 'selected';} ?> >Albania [355]</option>
						<option value="Algeria [213]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Algeria [213]') {echo 'selected';} ?> >Algeria [213]</option>
						<option value="American Samoa [1684]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'American Samoa [1684]') {echo 'selected';} ?> >American Samoa [1684]</option>
						<option value="Andorra [376]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Andorra [376]') {echo 'selected';} ?> >Andorra [376]</option>
						<option value="Angola [244]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Angola [244]') {echo 'selected';} ?> >Angola [244]</option>
						<option value="Anguilla [1264]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Anguilla [1264]') {echo 'selected';} ?> >Anguilla [1264]</option>
						<option value="Antarctica [672]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Antarctica [672]') {echo 'selected';} ?> >Antarctica [672]</option>
						<option value="Antigua [1268]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Antigua [1268]') {echo 'selected';} ?> >Antigua [1268]</option>
						<option value="Argentina [54]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Argentina [54]') {echo 'selected';} ?> >Argentina [54]</option>
						<option value="Armenia [374]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Armenia [374]') {echo 'selected';} ?> >Armenia [374]</option>
						<option value="Aruba [297]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Aruba [297]') {echo 'selected';} ?> >Aruba [297]</option>
						<option value="Ascension [247]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ascension [247]') {echo 'selected';} ?> >Ascension [247]</option>
						<option value="Australia [61]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Australia [61]') {echo 'selected';} ?> >Australia [61]</option>
						<option value="Australian External Territories [672]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Australian External Territories [672]') {echo 'selected';} ?> >Australian External Territories [672]</option>
						<option value="Austria [43]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Austria [43]') {echo 'selected';} ?> >Austria [43]</option>
						<option value="Azerbaijan [994]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Azerbaijan [994]') {echo 'selected';} ?> >Azerbaijan [994]</option>
						<option value="Bahamas [1242]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bahamas [1242]') {echo 'selected';} ?> >Bahamas [1242]</option>
						<option value="Bahrain [973]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bahrain [973]') {echo 'selected';} ?> >Bahrain [973]</option>
						<option value="Bangladesh [880]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bangladesh [880]') {echo 'selected';} ?> >Bangladesh [880]</option>
						<option value="Barbados [1246]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Barbados [1246]') {echo 'selected';} ?> >Barbados [1246]</option>
						<option value="Barbuda [1268]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Barbuda [1268]') {echo 'selected';} ?> >Barbuda [1268]</option>
						<option value="Belarus [375]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Belarus [375]') {echo 'selected';} ?> >Belarus [375]</option>
						<option value="Belgium [32]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Belgium [32]') {echo 'selected';} ?> >Belgium [32]</option>
						<option value="Belize [501]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Belize [501]') {echo 'selected';} ?> >Belize [501]</option>
						<option value="Benin [229]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Benin [229]') {echo 'selected';} ?> >Benin [229]</option>
						<option value="Bermuda [1441]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bermuda [1441]') {echo 'selected';} ?> >Bermuda [1441]</option>
						<option value="Bhutan [975]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bhutan [975]') {echo 'selected';} ?> >Bhutan [975]</option>
						<option value="Bolivia [591]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bolivia [591]') {echo 'selected';} ?> >Bolivia [591]</option>
						<option value="Bosnia and Herzegovina [387]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bosnia and Herzegovina [387]') {echo 'selected';} ?> >Bosnia &amp; Herzegovina [387]</option>
						<option value="Botswana [267]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Botswana [267]') {echo 'selected';} ?> >Botswana [267]</option>
						<option value="Brazil [55]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Brazil [55]') {echo 'selected';} ?> >Brazil [55]</option>
						<option value="British Virgin Islands [1284]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'British Virgin Islands [1284]') {echo 'selected';} ?> >British Virgin Islands [1284]</option>
						<option value="Brunei Darussalam [673]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Brunei Darussalam [673]') {echo 'selected';} ?> >Brunei Darussalam [673]</option>
						<option value="Bulgaria [359]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Bulgaria [359]') {echo 'selected';} ?> >Bulgaria [359]</option>
						<option value="Burkina Faso [226]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Burkina Faso [226]') {echo 'selected';} ?> >Burkina Faso [226]</option>
						<option value="Burundi [257]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Burundi [257]') {echo 'selected';} ?> >Burundi [257]</option>
						<option value="Cambodia [855]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cambodia [855]') {echo 'selected';} ?> >Cambodia [855]</option>
						<option value="Cameroon [237]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cameroon [237]') {echo 'selected';} ?> >Cameroon [237]</option>
						<option value="Canada [1]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Canada [1]') {echo 'selected';} ?> >Canada [1]</option>
						<option value="Cape Verde Islands [238]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cape Verde Islands [238]') {echo 'selected';} ?> >Cape Verde Islands [238]</option>
						<option value="Cayman Islands [1345]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cayman Islands [1345]') {echo 'selected';} ?> >Cayman Islands [1345]</option>
						<option value="Central African Republic [236]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Central African Republic [236]') {echo 'selected';} ?> >Central African Republic [236]</option>
						<option value="Chad [235]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Chad [235]') {echo 'selected';} ?> >Chad [235]</option>
						<option value="Chatham Island (New Zealand) [64]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Chatham Island (New Zealand) [64]') {echo 'selected';} ?> >Chatham Island (New Zealand) [64]</option>
						<option value="Chile [56]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Chile [56]') {echo 'selected';} ?> >Chile [56]</option>
						<option value="China (PRC) [86]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'China (PRC) [86]') {echo 'selected';} ?> >China (PRC) [86]</option>
						<option value="Christmas Island [61]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Christmas Island [61]') {echo 'selected';} ?> >Christmas Island [61]</option>
						<option value="CocosKeeling Islands [61]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'CocosKeeling Islands [61]') {echo 'selected';} ?> >CocosKeeling Islands [61]</option>
						<option value="Colombia [57]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Colombia [57]') {echo 'selected';} ?> >Colombia [57]</option>
						<option value="Comoros [269]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Comoros [269]') {echo 'selected';} ?> >Comoros [269]</option>
						<option value="Congo [242]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Congo [242]') {echo 'selected';} ?> >Congo [242]</option>
						<option value="Congo, Dem. Rep. of (Zaire) [243]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Congo, Dem. Rep. of (Zaire) [243]') {echo 'selected';} ?> >Congo, Dem. Rep. of (Zaire) [243]</option>
						<option value="Cook Islands [682]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cook Islands [682]') {echo 'selected';} ?> >Cook Islands [682]</option>
						<option value="Costa Rica [506]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Costa Rica [506]') {echo 'selected';} ?> >Costa Rica [506]</option>
						<option value="Cote d'Ivoire (Ivory Coast) [225]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cote d\'Ivoire (Ivory Coast) [225]') {echo 'selected';} ?> >Cote d&#039;Ivoire (Ivory Coast) [225]</option>
						<option value="Croatia [385]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Croatia [385]') {echo 'selected';} ?> >Croatia [385]</option>
						<option value="Cuba [53]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cuba [53]') {echo 'selected';} ?> >Cuba [53]</option>
						<option value="Cuba (Guantanamo Bay) [5399]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cuba (Guantanamo Bay) [5399]') {echo 'selected';} ?> >Cuba (Guantanamo Bay) [5399]</option>
						<option value="Curacao [599]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Curacao [599]') {echo 'selected';} ?> >Curacao [599]</option>
						<option value="Cyprus [357]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Cyprus [357]') {echo 'selected';} ?> >Cyprus [357]</option>
						<option value="Czech Republic [420]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Czech Republic [420]') {echo 'selected';} ?> >Czech Republic [420]</option>
						<option value="Denmark [45]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Denmark [45]') {echo 'selected';} ?> >Denmark [45]</option>
						<option value="Diego Garcia [246]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Diego Garcia [246]') {echo 'selected';} ?> >Diego Garcia [246]</option>
						<option value="Djibouti [253]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Djibouti [253]') {echo 'selected';} ?> >Djibouti [253]</option>
						<option value="Dominica [1767]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Dominica [1767]') {echo 'selected';} ?> >Dominica [1767]</option>
						<option value="Dominican Republic [1809]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Dominican Republic [1809]') {echo 'selected';} ?> >Dominican Republic [1809]</option>
						<option value="East Timor [670]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'East Timor [670]') {echo 'selected';} ?> >East Timor [670]</option>
						<option value="Easter Island [56]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Easter Island [56]') {echo 'selected';} ?> >Easter Island [56]</option>
						<option value="Ecuador [593]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ecuador [593]') {echo 'selected';} ?> >Ecuador [593]</option>
						<option value="Egypt [20]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Egypt [20]') {echo 'selected';} ?> >Egypt [20]</option>
						<option value="El Salvador [503]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'El Salvador [503]') {echo 'selected';} ?> >El Salvador [503]</option>
						<option value="Ellipso (Mobile Satellite service) [17625]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ellipso (Mobile Satellite service) [17625]') {echo 'selected';} ?> >Ellipso (Mobile Satellite service) [17625]</option>
						<option value="Equatorial Guinea [240]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Equatorial Guinea [240]') {echo 'selected';} ?> >Equatorial Guinea [240]</option>
						<option value="Eritrea [291]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Eritrea [291]') {echo 'selected';} ?> >Eritrea [291]</option>
						<option value="Estonia [372]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Estonia [372]') {echo 'selected';} ?> >Estonia [372]</option>
						<option value="Ethiopia [251]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ethiopia [251]') {echo 'selected';} ?> >Ethiopia [251]</option>
						<option value="Falkland Islands (Malvinas) [500]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Falkland Islands (Malvinas) [500]') {echo 'selected';} ?> >Falkland Islands (Malvinas) [500]</option>
						<option value="Faroe Islands [298]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Faroe Islands [298]') {echo 'selected';} ?> >Faroe Islands [298]</option>
						<option value="Fiji Islands [679]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Fiji Islands [679]') {echo 'selected';} ?> >Fiji Islands [679]</option>
						<option value="Finland [358]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Finland [358]') {echo 'selected';} ?> >Finland [358]</option>
						<option value="France [33]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'France [33]') {echo 'selected';} ?> >France [33]</option>
						<option value="French Antilles [596]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'French Antilles [596]') {echo 'selected';} ?> >French Antilles [596]</option>
						<option value="French Guiana [594]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'French Guiana [594]') {echo 'selected';} ?> >French Guiana [594]</option>
						<option value="French Polynesia [689]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'French Polynesia [689]') {echo 'selected';} ?> >French Polynesia [689]</option>
						<option value="Gabonese Republic [241]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Gabonese Republic [241]') {echo 'selected';} ?> >Gabonese Republic [241]</option>
						<option value="Gambia [220]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Gambia [220]') {echo 'selected';} ?> >Gambia [220]</option>
						<option value="Georgia [995]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Georgia [995]') {echo 'selected';} ?> >Georgia [995]</option>
						<option value="Germany [49]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Germany [49]') {echo 'selected';} ?> >Germany [49]</option>
						<option value="Ghana [233]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ghana [233]') {echo 'selected';} ?> >Ghana [233]</option>
						<option value="Gibraltar [350]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Gibraltar [350]') {echo 'selected';} ?> >Gibraltar [350]</option>
						<option value="Greece [30]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Greece [30]') {echo 'selected';} ?> >Greece [30]</option>
						<option value="Greenland [299]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Greenland [299]') {echo 'selected';} ?> >Greenland [299]</option>
						<option value="Grenada [1473]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Grenada [1473]') {echo 'selected';} ?> >Grenada [1473]</option>
						<option value="Guadeloupe [590]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guadeloupe [590]') {echo 'selected';} ?> >Guadeloupe [590]</option>
						<option value="Guam [1671]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guam [1671]') {echo 'selected';} ?> >Guam [1671]</option>
						<option value="Guantanamo Bay [5399]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guantanamo Bay [5399]') {echo 'selected';} ?> >Guantanamo Bay [5399]</option>
						<option value="Guatemala [502]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guatemala [502]') {echo 'selected';} ?> >Guatemala [502]</option>
						<option value="Guinea Bissau [245]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guinea Bissau [245]') {echo 'selected';} ?> >GuineaBissau [245]</option>
						<option value="Guinea [224]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guinea [224]') {echo 'selected';} ?> >Guinea [224]</option>
						<option value="Guyana [592]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Guyana [592]') {echo 'selected';} ?> >Guyana [592]</option>
						<option value="Haiti [509]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Haiti [509]') {echo 'selected';} ?> >Haiti [509]</option>
						<option value="Honduras [504]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Honduras [504]') {echo 'selected';} ?> >Honduras [504]</option>
						<option value="Hong Kong [852]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Hong Kong [852]') {echo 'selected';} ?> >Hong Kong [852]</option>
						<option value="Hungary [36]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Hungary [36]') {echo 'selected';} ?> >Hungary [36]</option>
						<option value="Iceland [354]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Iceland [354]') {echo 'selected';} ?> >Iceland [354]</option>
						<option value="India [91]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'India [91]') {echo 'selected';} ?> >India [91]</option>
						<option value="Indonesia [62]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Indonesia [62]') {echo 'selected';} ?> >Indonesia [62]</option>
						<option value="Iran [98]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Iran [98]') {echo 'selected';} ?> >Iran [98]</option>
						<option value="Iraq [964]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Iraq [964]') {echo 'selected';} ?> >Iraq [964]</option>
						<option value="Ireland [353]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ireland [353]') {echo 'selected';} ?> >Ireland [353]</option>
						<option value="Israel [972]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Israel [972]') {echo 'selected';} ?> >Israel [972]</option>
						<option value="Italy [39]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Italy [39]') {echo 'selected';} ?> >Italy [39]</option>
						<option value="Jamaica [1876]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Jamaica [1876]') {echo 'selected';} ?> >Jamaica [1876]</option>
						<option value="Japan [81]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Japan [81]') {echo 'selected';} ?> >Japan [81]</option>
						<option value="Jordan [962]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Jordan [962]') {echo 'selected';} ?> >Jordan [962]</option>
						<option value="Kazakhstan [7]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kazakhstan [7]') {echo 'selected';} ?> >Kazakhstan [7]</option>
						<option value="Kenya [254]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kenya [254]') {echo 'selected';} ?> >Kenya [254]</option>
						<option value="Kiribati [686]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kiribati [686]') {echo 'selected';} ?> >Kiribati [686]</option>
						<option value="Korea (North) [850]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Korea (North) [850]') {echo 'selected';} ?> >Korea (North) [850]</option>
						<option value="Korea (South) [82]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Korea (South) [82]') {echo 'selected';} ?> >Korea (South) [82]</option>
						<option value="Kosovo [381]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kosovo [381]') {echo 'selected';} ?> >Kosovo [381]</option>
						<option value="Kuwait [965]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kuwait [965]') {echo 'selected';} ?> >Kuwait [965]</option>
						<option value="Kyrgyz Republic [996]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Kyrgyz Republic [996]') {echo 'selected';} ?> >Kyrgyz Republic [996]</option>
						<option value="Laos [856]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Laos [856]') {echo 'selected';} ?> >Laos [856]</option>
						<option value="Latvia [371]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Latvia [371]') {echo 'selected';} ?> >Latvia [371]</option>
						<option value="Lebanon [961]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Lebanon [961]') {echo 'selected';} ?> >Lebanon [961]</option>
						<option value="Lesotho [266]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Lesotho [266]') {echo 'selected';} ?> >Lesotho [266]</option>
						<option value="Liberia [231]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Liberia [231]') {echo 'selected';} ?> >Liberia [231]</option>
						<option value="Libya [218]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Libya [218]') {echo 'selected';} ?> >Libya [218]</option>
						<option value="Liechtenstein [423]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Liechtenstein [423]') {echo 'selected';} ?> >Liechtenstein [423]</option>
						<option value="Lithuania [370]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Lithuania [370]') {echo 'selected';} ?> >Lithuania [370]</option>
						<option value="Luxembourg [352]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Luxembourg [352]') {echo 'selected';} ?> >Luxembourg [352]</option>
						<option value="Macao [853]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Macao [853]') {echo 'selected';} ?> >Macao [853]</option>
						<option value="Macedonia (Former Yugoslav Rep of.) [389]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Macedonia (Former Yugoslav Rep of.) [389]') {echo 'selected';} ?> >Macedonia (Former Yugoslav Rep of.) [389]</option>
						<option value="Madagascar [261]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Madagascar [261]') {echo 'selected';} ?> >Madagascar [261]</option>
						<option value="Malawi [265]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Malawi [265]') {echo 'selected';} ?> >Malawi [265]</option>
						<option value="Malaysia [60]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Malaysia [60]') {echo 'selected';} ?> >Malaysia [60]</option>
						<option value="Maldives [960]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Maldives [960]') {echo 'selected';} ?> >Maldives [960]</option>
						<option value="Mali Republic [223]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mali Republic [223]') {echo 'selected';} ?> >Mali Republic [223]</option>
						<option value="Malta [356]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Malta [356]') {echo 'selected';} ?> >Malta [356]</option>
						<option value="Marshall Islands [692]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Marshall Islands [692]') {echo 'selected';} ?> >Marshall Islands [692]</option>
						<option value="Martinique [596]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Martinique [596]') {echo 'selected';} ?> >Martinique [596]</option>
						<option value="Mauritania [222]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mauritania [222]') {echo 'selected';} ?> >Mauritania [222]</option>
						<option value="Mauritius [230]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mauritius [230]') {echo 'selected';} ?> >Mauritius [230]</option>
						<option value="Mayotte Island [269]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mayotte Island [269]') {echo 'selected';} ?> >Mayotte Island [269]</option>
						<option value="Mexico [52]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mexico [52]') {echo 'selected';} ?> >Mexico [52]</option>
						<option value="Micronesia [691]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Micronesia [691]') {echo 'selected';} ?> >Micronesia [691]</option>
						<option value="Midway Island [1808]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Midway Island [1808]') {echo 'selected';} ?> >Midway Island [1808]</option>
						<option value="Moldova [373]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Moldova [373]') {echo 'selected';} ?> >Moldova [373]</option>
						<option value="Monaco [377]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Monaco [377]') {echo 'selected';} ?> >Monaco [377]</option>
						<option value="Mongolia [976]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mongolia [976]') {echo 'selected';} ?> >Mongolia [976]</option>
						<option value="Montenegro [382]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Montenegro [382]') {echo 'selected';} ?> >Montenegro [382]</option>
						<option value="Montserrat [1664]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Montserrat [1664') {echo 'selected';} ?> >Montserrat [1664]</option>
						<option value="Morocco [212]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Morocco [212]') {echo 'selected';} ?> >Morocco [212]</option>
						<option value="Mozambique [258]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Mozambique [258]') {echo 'selected';} ?> >Mozambique [258]</option>
						<option value="Myanmar [95]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Myanmar [95]') {echo 'selected';} ?> >Myanmar [95]</option>
						<option value="Namibia [264]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Namibia [264]') {echo 'selected';} ?> >Namibia [264]</option>
						<option value="Nauru [674]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Nauru [674]') {echo 'selected';} ?> >Nauru [674]</option>
						<option value="Nepal [977]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Nepal [977]') {echo 'selected';} ?> >Nepal [977]</option>
						<option value="Netherlands [31]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Netherlands [31]') {echo 'selected';} ?> >Netherlands [31]</option>
						<option value="Netherlands Antilles [599]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Netherlands Antilles [599]') {echo 'selected';} ?> >Netherlands Antilles [599]</option>
						<option value="Nevis [1869]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Nevis [1869]') {echo 'selected';} ?> >Nevis [1869]</option>
						<option value="New Caledonia [687]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'New Caledonia [687]') {echo 'selected';} ?> >New Caledonia [687]</option>
						<option value="New Zealand [64]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'New Zealand [64]') {echo 'selected';} ?> >New Zealand [64]</option>
						<option value="Nicaragua [505]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Nicaragua [505') {echo 'selected';} ?> >Nicaragua [505]</option>
						<option value="Niger [227]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Niger [227]') {echo 'selected';} ?> >Niger [227]</option>
						<option value="Nigeria [234]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Nigeria [234]') {echo 'selected';} ?> >Nigeria [234]</option>
						<option value="Niue [683]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Niue [683]') {echo 'selected';} ?> >Niue [683]</option>
						<option value="Norfolk Island [672]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Norfolk Island [672]') {echo 'selected';} ?> >Norfolk Island [672]</option>
						<option value="Northern Marianas Islands [1670]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Northern Marianas Islands [1670]') {echo 'selected';} ?> >Northern Marianas Islands [1670]</option>
						<option value="Norway [47]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Norway [47]') {echo 'selected';} ?> >Norway [47]</option>
						<option value="Oman [968]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Oman [968]') {echo 'selected';} ?> >Oman [968]</option>
						<option value="Pakistan [92]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Pakistan [92]') {echo 'selected';} ?> >Pakistan [92]</option>
						<option value="Palau [680]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Palau [680]') {echo 'selected';} ?> >Palau [680]</option>
						<option value="Palestinian Settlements [970]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Palestinian Settlements [970]') {echo 'selected';} ?> >Palestinian Settlements [970]</option>
						<option value="Panama [507]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Panama [507]') {echo 'selected';} ?> >Panama [507]</option>
						<option value="Papua New Guinea [675]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Papua New Guinea [675]') {echo 'selected';} ?> >Papua New Guinea [675]</option>
						<option value="Paraguay [595]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Paraguay [595]') {echo 'selected';} ?> >Paraguay [595]</option>
						<option value="Peru [51]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Peru [51]') {echo 'selected';} ?> >Peru [51]</option>
						<option value="Philippines [63]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Philippines [63]') {echo 'selected';} ?> >Philippines [63]</option>
						<option value="Poland [48]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Poland [48]') {echo 'selected';} ?> >Poland [48]</option>
						<option value="Portugal [351]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Portugal [351]') {echo 'selected';} ?> >Portugal [351]</option>
						<option value="Puerto Rico [1787]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Puerto Rico [1787]') {echo 'selected';} ?> >Puerto Rico [1787]</option>
						<option value="Qatar [974]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Qatar [974]') {echo 'selected';} ?> >Qatar [974]</option>
						<option value="Reunion Island [262]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Reunion Island [262]') {echo 'selected';} ?> >Reunion Island [262]</option>
						<option value="Romania [40]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Romania [40]') {echo 'selected';} ?> >Romania [40]</option>
						<option value="Russia [7]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Russia [7]') {echo 'selected';} ?> >Russia [7]</option>
						<option value="Rwandese Republic [250]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Rwandese Republic [250]') {echo 'selected';} ?> >Rwandese Republic [250]</option>
						<option value="St. Helena [290]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'St. Helena [290]') {echo 'selected';} ?> >St. Helena [290]</option>
						<option value="St. Kitts/Nevis [1869]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'St. Kitts/Nevis [1869]') {echo 'selected';} ?> >St. Kitts/Nevis [1869]</option>
						<option value="St. Lucia [1758]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'St. Lucia [1758]') {echo 'selected';} ?> >St. Lucia [1758]</option>
						<option value="St. Pierre and Miquelon [508]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'St. Pierre and Miquelon [508]') {echo 'selected';} ?> >St. Pierre &amp; Miquelon [508]</option>
						<option value="St. Vincent and Grenadines [1784]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'St. Vincent and Grenadines [1784]') {echo 'selected';} ?> >St. Vincent &amp; Grenadines [1784]</option>
						<option value="Samoa [685]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Samoa [685]') {echo 'selected';} ?> >Samoa [685]</option>
						<option value="San Marino [378]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'San Marino [378]') {echo 'selected';} ?> >San Marino [378]</option>
						<option value="Sao Tome and Principe [239]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Sao Tome and Principe [239]') {echo 'selected';} ?> >Sao Tome and Principe [239]</option>
						<option value="Saudi Arabia [966]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Saudi Arabia [966]') {echo 'selected';} ?> >Saudi Arabia [966]</option>
						<option value="Senegal [221]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Senegal [221]') {echo 'selected';} ?> >Senegal [221]</option>
						<option value="Serbia [381]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Serbia [381]') {echo 'selected';} ?> >Serbia [381]</option>
						<option value="Seychelles Republic [248]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Seychelles Republic [248]') {echo 'selected';} ?> >Seychelles Republic [248]</option>
						<option value="Sierra Leone [232]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Sierra Leone [232]') {echo 'selected';} ?> >Sierra Leone [232]</option>
						<option value="Singapore [65]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Singapore [65]') {echo 'selected';} ?> >Singapore [65]</option>
						<option value="Slovak Republic [421]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Slovak Republic [421]') {echo 'selected';} ?> >Slovak Republic [421]</option>
						<option value="Slovenia [386]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Slovenia [386]') {echo 'selected';} ?> >Slovenia [386]</option>
						<option value="Solomon Islands [677]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Solomon Islands [677]') {echo 'selected';} ?> >Solomon Islands [677]</option>
						<option value="Somali Democratic Republic [252]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Somali Democratic Republic [252]') {echo 'selected';} ?> >Somali Democratic Republic [252]</option>
						<option value="South Africa [27]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'South Africa [27]') {echo 'selected';} ?> >South Africa [27]</option>
						<option value="Spain [34]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Spain [34]') {echo 'selected';} ?> >Spain [34]</option>
						<option value="Sri Lanka [94]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Sri Lanka [94]') {echo 'selected';} ?> >Sri Lanka [94]</option>
						<option value="Sudan [249]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Sudan [249]') {echo 'selected';} ?> >Sudan [249]</option>
						<option value="Suriname [597]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Suriname [597]') {echo 'selected';} ?> >Suriname [597]</option>
						<option value="Swaziland [268]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Swaziland [268]') {echo 'selected';} ?> >Swaziland [268]</option>
						<option value="Sweden [46]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Sweden [46]') {echo 'selected';} ?> >Sweden [46]</option>
						<option value="Switzerland [41]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Switzerland [41]') {echo 'selected';} ?> >Switzerland [41]</option>
						<option value="Syria [963]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Syria [963]') {echo 'selected';} ?> >Syria [963]</option>
						<option value="Taiwan [886]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Taiwan [886]') {echo 'selected';} ?> >Taiwan [886]</option>
						<option value="Tajikistan [992]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tajikistan [992]') {echo 'selected';} ?> >Tajikistan [992]</option>
						<option value="Tanzania [255]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tanzania [255]') {echo 'selected';} ?> >Tanzania [255]</option>
						<option value="Thailand [66]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Thailand [66]') {echo 'selected';} ?> >Thailand [66]</option>
						<option value="Timor Leste [670]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Timor Leste [670]') {echo 'selected';} ?> >Timor Leste [670]</option>
						<option value="Togolese Republic [228]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Togolese Republic [228]') {echo 'selected';} ?> >Togolese Republic [228]</option>
						<option value="Tokelau [690]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tokelau [690]') {echo 'selected';} ?> >Tokelau [690]</option>
						<option value="Tonga Islands [676]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tonga Islands [676]') {echo 'selected';} ?> >Tonga Islands [676]</option>
						<option value="Trinidad and Tobago [1868]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Trinidad and Tobago [1868]') {echo 'selected';} ?> >Trinidad &amp; Tobago [1868]</option>
						<option value="Tunisia [216]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tunisia [216]') {echo 'selected';} ?> >Tunisia [216]</option>
						<option value="Turkey [90]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Turkey [90]') {echo 'selected';} ?> >Turkey [90]</option>
						<option value="Turkmenistan [993]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Turkmenistan [993]') {echo 'selected';} ?> >Turkmenistan [993]</option>
						<option value="Turks and Caicos Islands [1649]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Turks and Caicos Islands [1649]') {echo 'selected';} ?> >Turks and Caicos Islands [1649]</option>
						<option value="Tuvalu [688]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Tuvalu [688]') {echo 'selected';} ?> >Tuvalu [688]</option>
						<option value="Uganda [256]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Uganda [256]') {echo 'selected';} ?> >Uganda [256]</option>
						<option value="Ukraine [380]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Ukraine [380]') {echo 'selected';} ?> >Ukraine [380]</option>
						<option value="United Arab Emirates [971]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'United Arab Emirates [971]') {echo 'selected';} ?> >United Arab Emirates [971]</option>
						<option value="United Kingdom [44]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'United Kingdom [44]') {echo 'selected';} ?> >United Kingdom [44]</option>
						<option value="United States of America [1]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'United States of America [1]') {echo 'selected';} ?> >United States of America [1]</option>
						<option value="US Virgin Islands [1340]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'US Virgin Islands [1340]') {echo 'selected';} ?> >US Virgin Islands [1340]</option>
						<option value="Uruguay [598]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Uruguay [598]') {echo 'selected';} ?> >Uruguay [598]</option>
						<option value="Uzbekistan [998]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Uzbekistan [998]') {echo 'selected';} ?> >Uzbekistan [998]</option>
						<option value="Vanuatu [678]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Vanuatu [678]') {echo 'selected';} ?> >Vanuatu [678]</option>
						<option value="Vatican City [39]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Vatican City [39]') {echo 'selected';} ?> >Vatican City [39]</option>
						<option value="Venezuela [58]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Venezuela [58]') {echo 'selected';} ?> >Venezuela [58]</option>
						<option value="Vietnam [84]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Vietnam [84]') {echo 'selected';} ?> >Vietnam [84]</option>
						<option value="Wake Island [808]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Wake Island [808]') {echo 'selected';} ?> >Wake Island [808]</option>
						<option value="Wallis and Futuna Islands [681]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Wallis and Futuna Islands [681]') {echo 'selected';} ?> >Wallis and Futuna Islands [681]</option>
						<option value="Yemen [967]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Yemen [967]') {echo 'selected';} ?> >Yemen [967]</option>
						<option value="Zambia [260]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Zambia [260]') {echo 'selected';} ?> >Zambia [260]</option>
						<option value="Zanzibar [255]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Zanzibar [255]') {echo 'selected';} ?> >Zanzibar [255]</option>
						<option value="Zimbabwe [263]" <?php if(isset($_POST['reg_country']) && $_POST['reg_country'] == 'Zimbabwe [263]') {echo 'selected';} ?> >Zimbabwe [263]</option>
					</select>