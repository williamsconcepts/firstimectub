<?php
	require_once '../files/head_section2.php';
	require_once '../files/navigation2.php';
	require_once '../files/connect.inc.php';

	$feedback = "";
	$feedback1 = "";

	if(isset($_GET['email-token'])){
		$email_token = $_GET['email-token'];
		$query_check_token = "SELECT `email_status` FROM `boa_acc_clients` WHERE `email_token`='$email_token'";
		$query_check_token_run = mysql_query($query_check_token);

		if (mysql_num_rows($query_check_token_run)==1){

			$query_update = "UPDATE `boa_acc_clients` SET 
			`email_status`= 'Verified',
			`email_token`= ''
			WHERE `email_token`='$email_token'";

			if($query_update_run = mysql_query($query_update)){
				$feedback1 = "Your email has been successfully verified. You can now log into your account";
			}else{
				$feedback = "Email verification faled. Please try again.";
			}


		}else{
			$feedback = "Email verification faled. You probably may have verified your email in the past";
		}

	}

?>


<div class="page_width">
	<div id="personal_sub" class="sub_pages">
			<div class="strip"></div>

		<div id="email_verify">
			<div style="color:#e31930; text-align:center; margin-top:30px;"><?php echo $feedback; ?></div>
			<div style="color:#006a4d; text-align:center; margin-top:30px;"><?php echo $feedback1; ?></div>
		</div>
	</div>
</div>	

<?php
	require_once '../files/footer2.php';
	require_once '../files/jsfiles2.php';
?>